/**
 * AI Chatbot Frontend Application Script
 * Communicates with the Java backend via REST API.
 */
document.addEventListener('DOMContentLoaded', () => {
  // Elements
  const chatForm = document.getElementById('chatForm');
  const messageInput = document.getElementById('messageInput');
  const messagesContainer = document.getElementById('messagesContainer');
  const typingIndicator = document.getElementById('typingIndicator');
  const nlpToggleBtn = document.getElementById('nlpToggleBtn');
  const closeInspectorBtn = document.getElementById('closeInspectorBtn');
  const inspectorPanel = document.getElementById('inspectorPanel');
  const themeToggleBtn = document.getElementById('themeToggleBtn');
  const themeIcon = document.getElementById('themeIcon');
  const clearChatBtn = document.getElementById('clearChatBtn');
  const micBtn = document.getElementById('micBtn');
  const sidebarToggle = document.getElementById('sidebarToggle');
  const sidebar = document.getElementById('sidebar');
  const quickQuestions = document.getElementById('quickQuestions');
  const categoryList = document.getElementById('categoryList');
  const suggestionBar = document.getElementById('suggestionBar');
  const statsText = document.getElementById('statsText');

  // Modal elements
  const openAddFaqBtn = document.getElementById('openAddFaqBtn');
  const faqModal = document.getElementById('faqModal');
  const closeModalBtn = document.getElementById('closeModalBtn');
  const cancelModalBtn = document.getElementById('cancelModalBtn');
  const addFaqForm = document.getElementById('addFaqForm');

  // Inspector fields
  const diagMatchType = document.getElementById('diagMatchType');
  const diagIntent = document.getElementById('diagIntent');
  const diagConfidence = document.getElementById('diagConfidence');
  const diagConfidenceBar = document.getElementById('diagConfidenceBar');
  const diagCategory = document.getElementById('diagCategory');
  const diagMatchedQ = document.getElementById('diagMatchedQ');
  const diagLatency = document.getElementById('diagLatency');
  const diagTokens = document.getElementById('diagTokens');
  const diagStems = document.getElementById('diagStems');
  const diagSuggestions = document.getElementById('diagSuggestions');

  let allFaqs = [];
  let currentCategory = 'all';

  // 1. Initial Greeting
  addBotMessage(
    "Hello! I am your AI Chatbot assistant powered by Java, NLP, and Machine Learning. " +
    "Feel free to ask me questions on admissions, tech support, Wi-Fi, passwords, or try calculating something like `calculate 25 * 16`!",
    {
      matchType: 'RULE_BASED',
      detectedIntent: 'greeting',
      confidence: 1.0,
      processingTimeMs: 1
    }
  );

  // 2. Fetch Server Stats & FAQs
  loadServerStats();
  loadFaqs();

  // 3. Theme Toggle
  const savedTheme = localStorage.getItem('chatbot_theme') || 'dark';
  if (savedTheme === 'light') {
    document.body.classList.replace('dark-theme', 'light-theme');
    themeIcon.textContent = '☀️';
  }

  themeToggleBtn.addEventListener('click', () => {
    if (document.body.classList.contains('dark-theme')) {
      document.body.classList.replace('dark-theme', 'light-theme');
      themeIcon.textContent = '☀️';
      localStorage.setItem('chatbot_theme', 'light');
    } else {
      document.body.classList.replace('light-theme', 'dark-theme');
      themeIcon.textContent = '🌙';
      localStorage.setItem('chatbot_theme', 'dark');
    }
  });

  // 4. Sidebar & Inspector Toggles
  nlpToggleBtn.addEventListener('click', () => {
    inspectorPanel.classList.toggle('open');
  });

  closeInspectorBtn.addEventListener('click', () => {
    inspectorPanel.classList.remove('open');
  });

  sidebarToggle.addEventListener('click', () => {
    sidebar.classList.toggle('mobile-open');
  });

  clearChatBtn.addEventListener('click', () => {
    messagesContainer.innerHTML = '';
    addBotMessage("Conversation cleared. How can I help you next?", null);
  });

  // 5. Input Textarea Auto-expand & Enter to Submit
  messageInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      chatForm.dispatchEvent(new Event('submit'));
    }
  });

  messageInput.addEventListener('input', () => {
    messageInput.style.height = 'auto';
    messageInput.style.height = Math.min(messageInput.scrollHeight, 120) + 'px';
  });

  // 6. Handle Chat Submission
  chatForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const query = messageInput.value.trim();
    if (!query) return;

    messageInput.value = '';
    messageInput.style.height = 'auto';
    addUserMessage(query);

    // Show typing
    typingIndicator.classList.add('active');
    messagesContainer.scrollTop = messagesContainer.scrollHeight;

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: query })
      });

      if (!response.ok) {
        throw new Error('Server returned ' + response.status);
      }

      const data = await response.json();
      typingIndicator.classList.remove('active');
      addBotMessage(data.reply, data);
      updateInspector(data);
    } catch (err) {
      console.error('Chat error:', err);
      typingIndicator.classList.remove('active');
      addBotMessage("⚠️ Failed to reach the chatbot server. Please ensure the Java server is running.", null);
    }
  });

  // 7. Suggested Chips and Questions Click Handlers
  suggestionBar.addEventListener('click', (e) => {
    const chip = e.target.closest('.chip');
    if (chip && chip.dataset.query) {
      messageInput.value = chip.dataset.query;
      chatForm.dispatchEvent(new Event('submit'));
    }
  });

  quickQuestions.addEventListener('click', (e) => {
    const item = e.target.closest('.question-chip');
    if (item && item.dataset.query) {
      messageInput.value = item.dataset.query;
      chatForm.dispatchEvent(new Event('submit'));
      if (window.innerWidth <= 768) {
        sidebar.classList.remove('mobile-open');
      }
    }
  });

  // Category filter
  categoryList.addEventListener('click', (e) => {
    const btn = e.target.closest('.cat-btn');
    if (!btn) return;

    document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentCategory = btn.dataset.cat;
    renderQuickQuestions();
  });

  // 8. Add FAQ Modal Handlers
  openAddFaqBtn.addEventListener('click', () => {
    faqModal.classList.add('open');
  });

  const closeModal = () => faqModal.classList.remove('open');
  closeModalBtn.addEventListener('click', closeModal);
  cancelModalBtn.addEventListener('click', closeModal);

  addFaqForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const category = document.getElementById('newCategory').value;
    const question = document.getElementById('newQuestion').value.trim();
    const answer = document.getElementById('newAnswer').value.trim();

    if (!question || !answer) return;

    try {
      const resp = await fetch('/api/faqs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ category, question, answer })
      });

      if (resp.ok) {
        alert('FAQ successfully added and model reindexed!');
        addFaqForm.reset();
        closeModal();
        loadFaqs();
        loadServerStats();
      } else {
        alert('Failed to add FAQ.');
      }
    } catch (err) {
      alert('Error communicating with server.');
    }
  });

  // 9. Speech Recognition (Microphone)
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (SpeechRecognition) {
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    micBtn.addEventListener('click', () => {
      if (micBtn.classList.contains('recording')) {
        recognition.stop();
        micBtn.classList.remove('recording');
      } else {
        recognition.start();
        micBtn.classList.add('recording');
      }
    });

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      messageInput.value = transcript;
      micBtn.classList.remove('recording');
      chatForm.dispatchEvent(new Event('submit'));
    };

    recognition.onerror = () => {
      micBtn.classList.remove('recording');
    };

    recognition.onend = () => {
      micBtn.classList.remove('recording');
    };
  } else {
    micBtn.style.display = 'none';
  }

  // Helper Functions
  function addUserMessage(text) {
    const wrapper = document.createElement('div');
    wrapper.className = 'msg-wrapper user';
    wrapper.innerHTML = `
      <div class="msg-avatar">👤</div>
      <div class="msg-bubble">
        ${escapeHtml(text)}
      </div>
    `;
    messagesContainer.appendChild(wrapper);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }

  function addBotMessage(text, meta) {
    const wrapper = document.createElement('div');
    wrapper.className = 'msg-wrapper bot';

    let metaHtml = '';
    if (meta) {
      const confPercent = Math.round((meta.confidence || 0) * 100);
      metaHtml = `
        <div class="msg-meta">
          <div class="meta-tags">
            <span class="tag-badge">${meta.matchType || 'BOT'}</span>
            ${meta.confidence !== undefined ? `<span class="tag-badge">${confPercent}% Conf</span>` : ''}
            ${meta.processingTimeMs ? `<span class="tag-badge">${meta.processingTimeMs}ms</span>` : ''}
          </div>
          <button class="speak-btn" title="Read Aloud">🔊</button>
        </div>
      `;
    }

    // Format markdown bold & bullet lists
    let formatted = escapeHtml(text)
      .replace(/\*\*(.*?)\*\*/g, '<b>$1</b>')
      .replace(/`([^`]+)`/g, '<code>$1</code>')
      .replace(/\n/g, '<br>');

    wrapper.innerHTML = `
      <div class="msg-avatar">🤖</div>
      <div class="msg-bubble">
        ${formatted}
        ${metaHtml}
      </div>
    `;

    // Audio TTS listener
    const speakBtn = wrapper.querySelector('.speak-btn');
    if (speakBtn && 'speechSynthesis' in window) {
      speakBtn.addEventListener('click', () => {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text.replace(/[*`•]/g, ''));
        utterance.rate = 1.0;
        window.speechSynthesis.speak(utterance);
      });
    }

    messagesContainer.appendChild(wrapper);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }

  function updateInspector(data) {
    if (!data) return;

    diagMatchType.textContent = data.matchType || '-';
    diagIntent.textContent = data.detectedIntent || '-';

    const confVal = Math.round((data.confidence || 0) * 100);
    diagConfidence.textContent = `${confVal}%`;
    diagConfidenceBar.style.width = `${confVal}%`;
    if (confVal > 70) {
      diagConfidenceBar.style.backgroundColor = '#10b981';
    } else if (confVal > 40) {
      diagConfidenceBar.style.backgroundColor = '#f59e0b';
    } else {
      diagConfidenceBar.style.backgroundColor = '#ef4444';
    }

    diagCategory.textContent = data.category || '-';
    diagMatchedQ.textContent = data.matchedQuestion || '-';
    diagLatency.textContent = `${data.processingTimeMs || 0} ms`;

    // Tokens
    diagTokens.innerHTML = '';
    if (data.tokens && data.tokens.length > 0) {
      data.tokens.forEach(t => {
        const span = document.createElement('span');
        span.className = 'token-chip';
        span.textContent = t;
        diagTokens.appendChild(span);
      });
    } else {
      diagTokens.innerHTML = '<span class="empty-hint">None</span>';
    }

    // Stems
    diagStems.innerHTML = '';
    if (data.stems && data.stems.length > 0) {
      data.stems.forEach(s => {
        const span = document.createElement('span');
        span.className = 'token-chip';
        span.textContent = s;
        diagStems.appendChild(span);
      });
    } else {
      diagStems.innerHTML = '<span class="empty-hint">None</span>';
    }

    // Suggestions
    diagSuggestions.innerHTML = '';
    if (data.suggestions && data.suggestions.length > 0) {
      data.suggestions.forEach(sug => {
        const btn = document.createElement('button');
        btn.className = 'chip';
        btn.style.display = 'block';
        btn.style.width = '100%';
        btn.style.marginBottom = '6px';
        btn.textContent = sug;
        btn.addEventListener('click', () => {
          messageInput.value = sug;
          chatForm.dispatchEvent(new Event('submit'));
        });
        diagSuggestions.appendChild(btn);
      });
    } else {
      diagSuggestions.innerHTML = '<span class="empty-hint">None</span>';
    }
  }

  async function loadServerStats() {
    try {
      const res = await fetch('/api/stats');
      if (res.ok) {
        const stats = await res.json();
        statsText.textContent = `${stats.totalFaqs} FAQs • ${stats.totalIntents} Intents • Java ${stats.javaVersion}`;
      }
    } catch (e) {
      statsText.textContent = 'Server Online';
    }
  }

  async function loadFaqs() {
    try {
      const res = await fetch('/api/faqs');
      if (res.ok) {
        const data = await res.json();
        allFaqs = data.faqs || [];
        renderQuickQuestions();
      }
    } catch (e) {
      console.warn('Could not load FAQs:', e);
    }
  }

  function renderQuickQuestions() {
    quickQuestions.innerHTML = '';
    const filtered = currentCategory === 'all'
      ? allFaqs
      : allFaqs.filter(f => f.category === currentCategory);

    filtered.forEach(faq => {
      const chip = document.createElement('div');
      chip.className = 'question-chip';
      chip.dataset.query = faq.question;
      chip.innerHTML = `<strong>${escapeHtml(faq.question)}</strong>`;
      quickQuestions.appendChild(chip);
    });
  }

  function escapeHtml(str) {
    if (!str) return '';
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }
});
