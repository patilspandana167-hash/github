$endpoints = @(
    @{ name = "Password Reset FAQ"; body = @{ message = "How do I reset my password?" } },
    @{ name = "Admissions Criteria"; body = @{ message = "What are the eligibility requirements for admission?" } },
    @{ name = "NLP Inquiry"; body = @{ message = "What is Natural Language Processing?" } },
    @{ name = "Math Calculation"; body = @{ message = "calculate 45 * 12" } },
    @{ name = "Time Inquiry"; body = @{ message = "what time is it" } },
    @{ name = "Typo Resilience"; body = @{ message = "How to resset passwrd?" } }
)

Write-Host "=================================================" -ForegroundColor Cyan
Write-Host " Testing Chatbot Live HTTP API (http://localhost:8080)" -ForegroundColor Cyan
Write-Host "=================================================" -ForegroundColor Cyan

foreach ($test in $endpoints) {
    Write-Host "`n>>> Testing: $($test.name)" -ForegroundColor Yellow
    Write-Host "Query: '$($test.body.message)'"
    $json = $test.body | ConvertTo-Json
    $res = Invoke-RestMethod -Uri "http://localhost:8080/api/chat" -Method Post -ContentType "application/json" -Body $json
    Write-Host "Bot Reply: $($res.reply)" -ForegroundColor Green
    Write-Host "Match Type: $($res.matchType) | Intent: $($res.detectedIntent) | Conf: $($res.confidence) | Latency: $($res.processingTimeMs)ms" -ForegroundColor Gray
}

Write-Host "`n>>> Testing: Static Web UI (http://localhost:8080/)" -ForegroundColor Yellow
$web = Invoke-WebRequest -Uri "http://localhost:8080/" -UseBasicParsing
Write-Host "Status Code: $($web.StatusCode) | Content Length: $($web.Content.Length) bytes" -ForegroundColor Green

Write-Host "`n=================================================" -ForegroundColor Cyan
Write-Host " Live API Verification Complete!" -ForegroundColor Cyan
Write-Host "=================================================" -ForegroundColor Cyan
