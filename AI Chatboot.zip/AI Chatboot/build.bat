@echo off
setlocal
echo ========================================================
echo   Compiling Java AI Chatbot System
echo ========================================================

if not exist bin mkdir bin

powershell -NoProfile -Command "$files = Get-ChildItem -Recurse src -Filter *.java | ForEach-Object { '\"' + $_.FullName.Replace('\', '\\') + '\"' }; [System.IO.File]::WriteAllLines('sources.txt', $files, [System.Text.Encoding]::ASCII)"

javac -encoding UTF-8 -d bin @sources.txt
set BUILD_STATUS=%ERRORLEVEL%

if exist sources.txt del sources.txt

if %BUILD_STATUS% equ 0 (
    echo [SUCCESS] Compilation finished without errors!
    echo Output class files are in the "bin" directory.
) else (
    echo [ERROR] Compilation failed.
)
exit /b %BUILD_STATUS%
