@echo off
if not exist bin\com\chatbot\test\ChatbotTest.class (
    call build.bat
)
echo ========================================================
echo   Running Chatbot Automated Test Suite...
echo ========================================================
java -cp bin com.chatbot.test.ChatbotTest
