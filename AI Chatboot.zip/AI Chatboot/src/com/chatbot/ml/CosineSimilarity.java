package com.chatbot.ml;

import java.util.Map;

/**
 * Computes cosine similarity between two sparse vector representations.
 */
public class CosineSimilarity {

    /**
     * Calculates cosine similarity between vector A and vector B.
     * Value is in the range [0.0, 1.0].
     */
    public static double compute(Map<String, Double> vecA, Map<String, Double> vecB) {
        if (vecA == null || vecB == null || vecA.isEmpty() || vecB.isEmpty()) {
            return 0.0;
        }

        // To optimize loop, iterate over smaller map
        Map<String, Double> smaller = vecA.size() < vecB.size() ? vecA : vecB;
        Map<String, Double> larger = vecA.size() < vecB.size() ? vecB : vecA;

        double dotProduct = 0.0;
        for (Map.Entry<String, Double> entry : smaller.entrySet()) {
            Double valB = larger.get(entry.getKey());
            if (valB != null) {
                dotProduct += entry.getValue() * valB;
            }
        }

        double normA = computeNorm(vecA);
        double normB = computeNorm(vecB);

        if (normA == 0.0 || normB == 0.0) {
            return 0.0;
        }

        double sim = dotProduct / (normA * normB);
        // Clamp to [0.0, 1.0] to guard against floating point inaccuracies
        return Math.max(0.0, Math.min(1.0, sim));
    }

    private static double computeNorm(Map<String, Double> vec) {
        double sumSquares = 0.0;
        for (double val : vec.values()) {
            sumSquares += val * val;
        }
        return Math.sqrt(sumSquares);
    }
}
