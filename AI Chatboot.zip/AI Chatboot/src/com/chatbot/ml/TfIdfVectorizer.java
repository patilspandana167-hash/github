package com.chatbot.ml;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Computes TF-IDF (Term Frequency - Inverse Document Frequency) feature vectors
 * for document collections and queries.
 */
public class TfIdfVectorizer {

    private final Map<String, Integer> vocabulary = new HashMap<>();
    private final Map<String, Double> idfWeights = new HashMap<>();
    private int totalDocuments = 0;

    /**
     * Fits the vectorizer on a corpus of tokenized documents.
     * Each document is represented by a list of stemmed tokens or n-grams.
     */
    public synchronized void fit(List<List<String>> tokenizedCorpus) {
        vocabulary.clear();
        idfWeights.clear();
        totalDocuments = tokenizedCorpus.size();

        if (totalDocuments == 0) return;

        // Count document frequencies (DF)
        Map<String, Integer> docFrequencies = new HashMap<>();
        int termIndex = 0;

        for (List<String> docTokens : tokenizedCorpus) {
            Set<String> uniqueTerms = new HashSet<>(docTokens);
            for (String term : uniqueTerms) {
                docFrequencies.put(term, docFrequencies.getOrDefault(term, 0) + 1);
                if (!vocabulary.containsKey(term)) {
                    vocabulary.put(term, termIndex++);
                }
            }
        }

        // Calculate smoothed IDF: log((1 + N) / (1 + df)) + 1
        for (Map.Entry<String, Integer> entry : docFrequencies.entrySet()) {
            String term = entry.getKey();
            int df = entry.getValue();
            double idf = Math.log((1.0 + totalDocuments) / (1.0 + df)) + 1.0;
            idfWeights.put(term, idf);
        }
    }

    /**
     * Transforms a tokenized document/query into a sparse TF-IDF vector (Map of term -> tf-idf weight).
     * The resulting vector is L2 normalized.
     */
    public Map<String, Double> transform(List<String> tokens) {
        if (tokens == null || tokens.isEmpty() || vocabulary.isEmpty()) {
            return Collections.emptyMap();
        }

        // Calculate term frequencies (TF)
        Map<String, Integer> tf = new HashMap<>();
        for (String token : tokens) {
            if (vocabulary.containsKey(token)) {
                tf.put(token, tf.getOrDefault(token, 0) + 1);
            }
        }

        if (tf.isEmpty()) {
            return Collections.emptyMap();
        }

        // Calculate TF-IDF: (1 + log(tf)) * idf
        Map<String, Double> tfidfVector = new HashMap<>();
        double sumSquares = 0.0;

        for (Map.Entry<String, Integer> entry : tf.entrySet()) {
            String term = entry.getKey();
            int count = entry.getValue();
            double termFreq = 1.0 + Math.log(count);
            double idf = idfWeights.getOrDefault(term, 1.0);
            double weight = termFreq * idf;
            tfidfVector.put(term, weight);
            sumSquares += weight * weight;
        }

        // L2 Normalization
        double norm = Math.sqrt(sumSquares);
        if (norm > 0.0) {
            for (Map.Entry<String, Double> entry : tfidfVector.entrySet()) {
                entry.setValue(entry.getValue() / norm);
            }
        }

        return tfidfVector;
    }

    public Map<String, Integer> getVocabulary() {
        return Collections.unmodifiableMap(vocabulary);
    }

    public Map<String, Double> getIdfWeights() {
        return Collections.unmodifiableMap(idfWeights);
    }

    public int getVocabularySize() {
        return vocabulary.size();
    }
}
