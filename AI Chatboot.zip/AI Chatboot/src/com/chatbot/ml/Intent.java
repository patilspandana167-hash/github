package com.chatbot.ml;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a recognized conversational intent with its name, training phrases,
 * and candidate responses.
 */
public class Intent {
    private String name;
    private String description;
    private List<String> patterns;
    private List<String> responses;

    public Intent() {
        this.patterns = new ArrayList<>();
        this.responses = new ArrayList<>();
    }

    public Intent(String name, String description) {
        this.name = name;
        this.description = description;
        this.patterns = new ArrayList<>();
        this.responses = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<String> getPatterns() {
        return patterns;
    }

    public void setPatterns(List<String> patterns) {
        this.patterns = patterns;
    }

    public void addPattern(String pattern) {
        this.patterns.add(pattern);
    }

    public List<String> getResponses() {
        return responses;
    }

    public void setResponses(List<String> responses) {
        this.responses = responses;
    }

    public void addResponse(String response) {
        this.responses.add(response);
    }

    public String getRandomResponse() {
        if (responses == null || responses.isEmpty()) {
            return null;
        }
        int idx = (int) (Math.random() * responses.size());
        return responses.get(idx);
    }

    @Override
    public String toString() {
        return "Intent{" +
                "name='" + name + '\'' +
                ", patternsCount=" + (patterns != null ? patterns.size() : 0) +
                ", responsesCount=" + (responses != null ? responses.size() : 0) +
                '}';
    }
}
