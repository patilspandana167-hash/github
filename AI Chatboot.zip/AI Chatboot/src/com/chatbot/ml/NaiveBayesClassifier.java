package com.chatbot.ml;

import com.chatbot.nlp.TextPreprocessor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Multinomial Naive Bayes Classifier for Intent Recognition.
 * Utilizes log-space computations and Laplace add-1 smoothing.
 */
public class NaiveBayesClassifier {

    public static class ClassificationResult {
        private final String intent;
        private final double confidence;
        private final Map<String, Double> allProbabilities;

        public ClassificationResult(String intent, double confidence, Map<String, Double> allProbabilities) {
            this.intent = intent;
            this.confidence = confidence;
            this.allProbabilities = allProbabilities;
        }

        public String getIntent() {
            return intent;
        }

        public double getConfidence() {
            return confidence;
        }

        public Map<String, Double> getAllProbabilities() {
            return allProbabilities;
        }

        @Override
        public String toString() {
            return String.format("Result[intent=%s, conf=%.2f%%]", intent, confidence * 100);
        }
    }

    private final Set<String> vocabulary = new HashSet<>();
    private final Map<String, Double> logClassPriors = new HashMap<>();
    private final Map<String, Map<String, Double>> logWordLikelihoods = new HashMap<>();
    private final List<String> classes = new ArrayList<>();
    private boolean isTrained = false;

    /**
     * Trains the Naive Bayes model using labeled intent examples.
     */
    public synchronized void train(List<Intent> intents, TextPreprocessor preprocessor) {
        vocabulary.clear();
        logClassPriors.clear();
        logWordLikelihoods.clear();
        classes.clear();

        if (intents == null || intents.isEmpty()) {
            isTrained = false;
            return;
        }

        int totalDocs = 0;
        Map<String, Integer> classDocCounts = new HashMap<>();
        Map<String, Map<String, Integer>> classWordCounts = new HashMap<>();
        Map<String, Integer> classTotalWords = new HashMap<>();

        // 1. Gather counts
        for (Intent intent : intents) {
            String className = intent.getName();
            classes.add(className);
            classDocCounts.put(className, intent.getPatterns().size());
            totalDocs += intent.getPatterns().size();

            Map<String, Integer> wordCounts = new HashMap<>();
            int totalWords = 0;

            for (String pattern : intent.getPatterns()) {
                List<String> tokens = preprocessor.processToStems(pattern);
                for (String token : tokens) {
                    vocabulary.add(token);
                    wordCounts.put(token, wordCounts.getOrDefault(token, 0) + 1);
                    totalWords++;
                }
            }

            classWordCounts.put(className, wordCounts);
            classTotalWords.put(className, totalWords);
        }

        int vocabSize = vocabulary.size();

        // 2. Compute priors and likelihoods with Laplace smoothing
        for (String className : classes) {
            int docCount = classDocCounts.getOrDefault(className, 0);
            double prior = totalDocs > 0 ? (double) (docCount + 1) / (totalDocs + classes.size()) : 1.0 / classes.size();
            logClassPriors.put(className, Math.log(prior));

            Map<String, Double> wordLikelihood = new HashMap<>();
            Map<String, Integer> counts = classWordCounts.get(className);
            int totalWordsInClass = classTotalWords.getOrDefault(className, 0);
            double denominator = totalWordsInClass + vocabSize + 1.0;

            for (String word : vocabulary) {
                int count = counts.getOrDefault(word, 0);
                double p = (count + 1.0) / denominator;
                wordLikelihood.put(word, Math.log(p));
            }

            // Default log likelihood for unseen words in this class
            wordLikelihood.put("__UNSEEN__", Math.log(1.0 / denominator));
            logWordLikelihoods.put(className, wordLikelihood);
        }

        isTrained = true;
    }

    /**
     * Classifies a list of processed tokens into the most probable intent.
     */
    public ClassificationResult classify(List<String> tokens) {
        if (!isTrained || classes.isEmpty()) {
            return new ClassificationResult("unknown", 0.0, Collections.emptyMap());
        }

        Map<String, Double> logScores = new HashMap<>();
        double maxLogScore = -Double.MAX_VALUE;

        for (String className : classes) {
            double score = logClassPriors.getOrDefault(className, 0.0);
            Map<String, Double> likelihoods = logWordLikelihoods.get(className);

            if (tokens != null && !tokens.isEmpty()) {
                for (String token : tokens) {
                    if (likelihoods.containsKey(token)) {
                        score += likelihoods.get(token);
                    } else {
                        score += likelihoods.getOrDefault("__UNSEEN__", -10.0);
                    }
                }
            }

            logScores.put(className, score);
            if (score > maxLogScore) {
                maxLogScore = score;
            }
        }

        // Softmax computation for normalized probabilities
        Map<String, Double> probabilities = new HashMap<>();
        double sumExp = 0.0;
        for (double score : logScores.values()) {
            sumExp += Math.exp(score - maxLogScore); // Shift by max for numerical stability
        }

        String bestClass = classes.get(0);
        double highestProb = 0.0;

        for (Map.Entry<String, Double> entry : logScores.entrySet()) {
            double prob = Math.exp(entry.getValue() - maxLogScore) / sumExp;
            probabilities.put(entry.getKey(), prob);
            if (prob > highestProb) {
                highestProb = prob;
                bestClass = entry.getKey();
            }
        }

        return new ClassificationResult(bestClass, highestProb, probabilities);
    }

    public boolean isTrained() {
        return isTrained;
    }

    public List<String> getClasses() {
        return Collections.unmodifiableList(classes);
    }

    public int getVocabularySize() {
        return vocabulary.size();
    }
}
