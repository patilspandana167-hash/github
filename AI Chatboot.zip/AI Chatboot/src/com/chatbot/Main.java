package com.chatbot;

import com.chatbot.engine.ChatEngine;
import com.chatbot.engine.DataLoader;
import com.chatbot.engine.FaqKnowledgeBase;
import com.chatbot.gui.ChatbotGUI;
import com.chatbot.ml.Intent;
import com.chatbot.server.WebChatServer;

import javax.swing.SwingUtilities;
import java.awt.Desktop;
import java.io.File;
import java.net.URI;
import java.util.List;
import java.util.Scanner;

/**
 * Main application entry point for the Java AI Chatbot.
 */
public class Main {

    private static final int DEFAULT_PORT = 8080;

    public static void main(String[] args) {
        System.out.println("===============================================================");
        System.out.println("    Java AI Chatbot • Natural Language Processing & ML");
        System.out.println("===============================================================");

        // 1. Initialize Engine
        ChatEngine engine = new ChatEngine();

        // 2. Discover and Load Datasets
        String dataDir = findDataDirectory();
        String faqsPath = dataDir + File.separator + "faqs.json";
        String intentsPath = dataDir + File.separator + "intents.json";

        System.out.println("[Init] Loading FAQ Knowledge Base from: " + faqsPath);
        List<FaqKnowledgeBase.FaqItem> faqs = DataLoader.loadFaqs(faqsPath);
        for (FaqKnowledgeBase.FaqItem item : faqs) {
            engine.getKnowledgeBase().addFaq(item);
        }

        System.out.println("[Init] Loading Intent Training Data from: " + intentsPath);
        List<Intent> intents = DataLoader.loadIntents(intentsPath);

        System.out.println("[Init] Training Naive Bayes Classifier and Reindexing TF-IDF...");
        engine.train(intents);

        System.out.println(String.format("[Ready] Indexed %d FAQs | %d ML Intents | Vocab Size: %d",
                engine.getKnowledgeBase().size(),
                engine.getIntentClassifier().getClasses().size(),
                engine.getKnowledgeBase().getVectorizer().getVocabularySize()));
        System.out.println("===============================================================");

        // 3. Parse command line arguments
        boolean runGui = false;
        boolean runCli = false;
        boolean runWeb = true; // default
        int port = DEFAULT_PORT;

        for (int i = 0; i < args.length; i++) {
            String arg = args[i].toLowerCase();
            if (arg.equals("--gui") || arg.equals("-gui")) {
                runGui = true;
                runWeb = false;
            } else if (arg.equals("--cli") || arg.equals("-cli")) {
                runCli = true;
                runWeb = false;
            } else if (arg.equals("--all") || arg.equals("-all")) {
                runGui = true;
                runWeb = true;
            } else if ((arg.equals("--port") || arg.equals("-p")) && i + 1 < args.length) {
                try {
                    port = Integer.parseInt(args[++i]);
                } catch (NumberFormatException ignored) {}
            }
        }

        // 4. Launch requested interfaces
        if (runWeb) {
            String webDir = findWebDirectory();
            try {
                WebChatServer server = new WebChatServer(port, engine, webDir);
                server.start();

                // Open browser if desktop supported
                tryOpenBrowser("http://localhost:" + port);
            } catch (Exception e) {
                System.err.println("Error starting Web Server: " + e.getMessage());
            }
        }

        if (runGui) {
            System.out.println("[Interface] Launching Java Swing Desktop GUI...");
            SwingUtilities.invokeLater(() -> {
                ChatbotGUI gui = new ChatbotGUI(engine);
                gui.setVisible(true);
            });
        }

        if (runCli) {
            runCliInterface(engine);
        }
    }

    private static void runCliInterface(ChatEngine engine) {
        System.out.println("\n--- Interactive Terminal Mode (Type 'exit' to quit) ---");
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print("\nYou: ");
            if (!scanner.hasNextLine()) break;
            String line = scanner.nextLine().trim();
            if (line.equalsIgnoreCase("exit") || line.equalsIgnoreCase("quit")) {
                System.out.println("Bot: Goodbye!");
                break;
            }
            if (line.isEmpty()) continue;

            var resp = engine.processMessage(line);
            System.out.println("Bot: " + resp.getReply());
            System.out.println(String.format("     [Engine: %s | Intent: %s | Conf: %.2f | %dms]",
                    resp.getMatchType(), resp.getDetectedIntent(), resp.getConfidence(), resp.getProcessingTimeMs()));
        }
    }

    private static String findDataDirectory() {
        String[] candidates = {"data", "../data", "./data", "src/../data"};
        for (String c : candidates) {
            File f = new File(c);
            if (f.exists() && f.isDirectory()) {
                return f.getAbsolutePath();
            }
        }
        return new File("data").getAbsolutePath();
    }

    private static String findWebDirectory() {
        String[] candidates = {"web", "../web", "./web", "src/../web"};
        for (String c : candidates) {
            File f = new File(c);
            if (f.exists() && f.isDirectory()) {
                return f.getAbsolutePath();
            }
        }
        return new File("web").getAbsolutePath();
    }

    private static void tryOpenBrowser(String url) {
        try {
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                Desktop.getDesktop().browse(new URI(url));
            }
        } catch (Exception ignored) {
            // Headless or browse unsupported
        }
    }
}
