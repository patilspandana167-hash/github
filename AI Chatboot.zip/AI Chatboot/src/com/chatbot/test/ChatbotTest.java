package com.chatbot.test;

import com.chatbot.engine.ChatEngine;
import com.chatbot.engine.ChatResponse;
import com.chatbot.engine.DataLoader;
import com.chatbot.engine.FaqKnowledgeBase;
import com.chatbot.engine.RuleBasedMatcher;
import com.chatbot.ml.CosineSimilarity;
import com.chatbot.ml.Intent;
import com.chatbot.ml.NaiveBayesClassifier;
import com.chatbot.ml.TfIdfVectorizer;
import com.chatbot.nlp.LevenshteinDistance;
import com.chatbot.nlp.PorterStemmer;
import com.chatbot.nlp.StopWords;
import com.chatbot.nlp.TextPreprocessor;
import com.chatbot.nlp.Tokenizer;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * Automated test suite for NLP Pipeline, Machine Learning, Rule Engine, and FAQ Matching.
 */
public class ChatbotTest {

    private static int testsPassed = 0;
    private static int testsFailed = 0;

    public static void main(String[] args) {
        System.out.println("=================================================");
        System.out.println(" Running Java AI Chatbot Automated Test Suite");
        System.out.println("=================================================");

        testTokenizer();
        testStopWords();
        testPorterStemmer();
        testLevenshteinDistance();
        testTfIdfAndCosineSimilarity();
        testNaiveBayesClassifier();
        testRuleBasedMatcher();
        testEndToEndChatEngine();

        System.out.println("=================================================");
        System.out.println(String.format(" Test Results: %d PASSED, %d FAILED", testsPassed, testsFailed));
        System.out.println("=================================================");

        if (testsFailed > 0) {
            System.exit(1);
        }
    }

    private static void assertTrue(String testName, boolean condition) {
        if (condition) {
            System.out.println("  [PASS] " + testName);
            testsPassed++;
        } else {
            System.err.println("  [FAIL] " + testName);
            testsFailed++;
        }
    }

    private static void assertEquals(String testName, Object expected, Object actual) {
        if (expected == null && actual == null) {
            assertTrue(testName, true);
        } else if (expected != null && expected.equals(actual)) {
            assertTrue(testName, true);
        } else {
            System.err.println(String.format("  [FAIL] %s - Expected: '%s', Actual: '%s'", testName, expected, actual));
            testsFailed++;
        }
    }

    private static void testTokenizer() {
        System.out.println("\n[Suite 1] Tokenizer Tests");
        List<String> tokens = Tokenizer.tokenize("Hello, how do I apply for university admission?");
        assertTrue("Tokens not empty", !tokens.isEmpty());
        assertEquals("Token count", 8, tokens.size());
        assertEquals("First token", "hello", tokens.get(0));
        assertEquals("Last token", "admission", tokens.get(tokens.size() - 1));
    }

    private static void testStopWords() {
        System.out.println("\n[Suite 2] Stop Words Filter Tests");
        assertTrue("'the' is stopword", StopWords.isStopWord("the"));
        assertTrue("'admission' is NOT stopword", !StopWords.isStopWord("admission"));

        List<String> tokens = Arrays.asList("how", "do", "i", "reset", "password");
        List<String> filtered = StopWords.filter(tokens);
        assertEquals("Filtered size", 2, filtered.size());
        assertTrue("Contains 'reset'", filtered.contains("reset"));
        assertTrue("Contains 'password'", filtered.contains("password"));
    }

    private static void testPorterStemmer() {
        System.out.println("\n[Suite 3] Porter Stemmer Tests");
        PorterStemmer stemmer = new PorterStemmer();

        assertEquals("Stem 'connected'", "connect", stemmer.stem("connected"));
        assertEquals("Stem 'connecting'", "connect", stemmer.stem("connecting"));
        assertEquals("Stem 'connections'", "connect", stemmer.stem("connections"));
        assertEquals("Stem 'programming'", "program", stemmer.stem("programming"));
        assertEquals("Stem 'universities'", "univers", stemmer.stem("universities"));
    }

    private static void testLevenshteinDistance() {
        System.out.println("\n[Suite 4] Levenshtein Distance & Fuzzy Match Tests");
        int dist1 = LevenshteinDistance.compute("password", "passwrd");
        assertEquals("Distance password vs passwrd", 1, dist1);

        double sim = LevenshteinDistance.similarity("admission", "admissin");
        assertTrue("Similarity > 0.85", sim > 0.85);

        List<String> candidates = Arrays.asList(
                "What is the admission deadline?",
                "How to reset password?",
                "How to connect to wifi?"
        );
        String match = LevenshteinDistance.findClosestMatch("How to resset passwrd?", candidates, 0.5);
        assertEquals("Closest match found", "How to reset password?", match);
    }

    private static void testTfIdfAndCosineSimilarity() {
        System.out.println("\n[Suite 5] TF-IDF & Cosine Similarity Tests");
        TfIdfVectorizer vectorizer = new TfIdfVectorizer();

        List<List<String>> corpus = Arrays.asList(
                Arrays.asList("reset", "password", "portal", "account"),
                Arrays.asList("connect", "campus", "wifi", "network"),
                Arrays.asList("admiss", "deadlin", "semest", "date")
        );
        vectorizer.fit(corpus);

        assertTrue("Vocabulary populated", vectorizer.getVocabularySize() > 0);

        Map<String, Double> vecDoc1 = vectorizer.transform(corpus.get(0));
        Map<String, Double> vecQuery = vectorizer.transform(Arrays.asList("password", "reset"));
        Map<String, Double> vecUnrelated = vectorizer.transform(Arrays.asList("wifi", "network"));

        double simMatch = CosineSimilarity.compute(vecDoc1, vecQuery);
        double simUnrelated = CosineSimilarity.compute(vecDoc1, vecUnrelated);

        assertTrue("Matching query similarity high (> 0.5)", simMatch > 0.5);
        assertEquals("Unrelated query similarity is 0", 0.0, simUnrelated);
    }

    private static void testNaiveBayesClassifier() {
        System.out.println("\n[Suite 6] Naive Bayes Classifier Tests");
        TextPreprocessor preprocessor = new TextPreprocessor();
        NaiveBayesClassifier nb = new NaiveBayesClassifier();

        Intent greet = new Intent("greeting", "Greeting");
        greet.addPattern("hello"); greet.addPattern("hi"); greet.addPattern("hey there");

        Intent bye = new Intent("goodbye", "Goodbye");
        bye.addPattern("bye"); bye.addPattern("goodbye"); bye.addPattern("see you later");

        nb.train(Arrays.asList(greet, bye), preprocessor);
        assertTrue("Classifier trained", nb.isTrained());

        var resGreet = nb.classify(preprocessor.processToStems("hello there"));
        assertEquals("Classify greeting", "greeting", resGreet.getIntent());
        assertTrue("Greeting confidence > 0.6", resGreet.getConfidence() > 0.6);

        var resBye = nb.classify(preprocessor.processToStems("goodbye friend"));
        assertEquals("Classify goodbye", "goodbye", resBye.getIntent());
    }

    private static void testRuleBasedMatcher() {
        System.out.println("\n[Suite 7] Rule-Based Matcher Tests");
        RuleBasedMatcher matcher = new RuleBasedMatcher();

        var mathRes = matcher.match("calculate 25 * 4");
        assertTrue("Math rule matched", mathRes != null);
        assertTrue("Math contains 100", mathRes.getReply().contains("100"));

        var timeRes = matcher.match("what time is it?");
        assertTrue("Time rule matched", timeRes != null);
        assertTrue("Time rule contains 'time'", timeRes.getReply().toLowerCase().contains("time"));

        var greetRes = matcher.match("hello!");
        assertTrue("Greeting rule matched", greetRes != null);
    }

    private static void testEndToEndChatEngine() {
        System.out.println("\n[Suite 8] End-to-End Chat Engine Tests");
        ChatEngine engine = new ChatEngine();

        String dataDir = new File("data").exists() ? "data" : "../data";
        List<FaqKnowledgeBase.FaqItem> faqs = DataLoader.loadFaqs(dataDir + "/faqs.json");
        for (var f : faqs) {
            engine.getKnowledgeBase().addFaq(f);
        }
        List<Intent> intents = DataLoader.loadIntents(dataDir + "/intents.json");
        engine.train(intents);

        // Test 1: Exact / Paraphrased FAQ
        ChatResponse respFaq = engine.processMessage("How can I reset my account password?");
        assertTrue("FAQ Match Type is SEMANTIC_FAQ", respFaq.getMatchType() == ChatResponse.MatchType.SEMANTIC_FAQ);
        assertTrue("Contains 'password'", respFaq.getReply().toLowerCase().contains("password"));
        assertTrue("Confidence > 0.3", respFaq.getConfidence() > 0.3);

        // Test 2: Arithmetic expression
        ChatResponse respMath = engine.processMessage("calculate 500 / 20");
        assertEquals("Math Match Type", ChatResponse.MatchType.RULE_BASED, respMath.getMatchType());
        assertTrue("Math result 25", respMath.getReply().contains("25"));

        // Test 3: Typo / Fuzzy Suggestion
        ChatResponse respTypo = engine.processMessage("How to resset passwrd?");
        assertTrue("Typo handled with FAQ or Suggestion",
                respFaq.getMatchType() == ChatResponse.MatchType.SEMANTIC_FAQ ||
                respTypo.getMatchType() == ChatResponse.MatchType.FALLBACK_SUGGESTION);

        // Test 4: Latency check
        assertTrue("Processing time < 100ms", respFaq.getProcessingTimeMs() < 100);
    }
}
