package com.chatbot.server;

import com.chatbot.engine.ChatEngine;
import com.chatbot.engine.ChatResponse;
import com.chatbot.engine.FaqKnowledgeBase;
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Embedded HTTP Server hosting the REST API and serving the interactive Web Interface.
 */
public class WebChatServer {

    private final int port;
    private final ChatEngine chatEngine;
    private final String webRoot;
    private HttpServer server;
    private final AtomicLong totalMessagesProcessed = new AtomicLong(0);

    public WebChatServer(int port, ChatEngine chatEngine, String webRoot) {
        this.port = port;
        this.chatEngine = chatEngine;
        this.webRoot = webRoot;
    }

    public synchronized void start() throws IOException {
        // Listen on every local network interface so another browser/device can connect.
        server = HttpServer.create(new InetSocketAddress("0.0.0.0", port), 0);
        server.setExecutor(Executors.newFixedThreadPool(8));

        // API Endpoints
        server.createContext("/api/chat", new ChatHandler());
        server.createContext("/api/faqs", new FaqHandler());
        server.createContext("/api/stats", new StatsHandler());

        // Static Web UI Handler
        server.createContext("/", new StaticFileHandler());

        server.start();
        System.out.println("=================================================");
        System.out.println(" AI Chatbot Server is running!");
        System.out.println(" Web Interface: http://localhost:" + port);
        System.out.println(" External Access: http://" + getLocalAddress() + ":" + port);
        System.out.println(" REST API:      http://localhost:" + port + "/api/chat");
        System.out.println("=================================================");
    }

    private String getLocalAddress() {
        try {
            return InetAddress.getLocalHost().getHostAddress();
        } catch (IOException ignored) {
            return "<this-computer-ip>";
        }
    }

    public synchronized void stop() {
        if (server != null) {
            server.stop(1);
            System.out.println("Chatbot server stopped.");
        }
    }

    private class ChatHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            addCorsHeaders(exchange);
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(204, -1);
                return;
            }

            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendJsonResponse(exchange, 405, Map.of("error", "Only POST method supported"));
                return;
            }

            String body = readRequestBody(exchange).trim();
            Map<String, Object> req = JsonHelper.parseObject(body);
            String message = "";
            if (req.containsKey("message") && req.get("message") != null) {
                message = req.get("message").toString();
            } else if (req.containsKey("query") && req.get("query") != null) {
                message = req.get("query").toString();
            } else if (req.containsKey("text") && req.get("text") != null) {
                message = req.get("text").toString();
            } else if (req.containsKey("msg") && req.get("msg") != null) {
                message = req.get("msg").toString();
            } else if (!body.startsWith("{") && !body.isEmpty()) {
                message = body;
            }

            totalMessagesProcessed.incrementAndGet();
            ChatResponse resp = chatEngine.processMessage(message);

            Map<String, Object> jsonResp = new LinkedHashMap<>();
            jsonResp.put("status", "success");
            jsonResp.put("reply", resp.getReply());
            jsonResp.put("matchType", resp.getMatchType().name());
            jsonResp.put("detectedIntent", resp.getDetectedIntent());
            jsonResp.put("confidence", Math.round(resp.getConfidence() * 100.0) / 100.0);
            jsonResp.put("matchedQuestion", resp.getMatchedQuestion());
            jsonResp.put("category", resp.getCategory());
            jsonResp.put("tokens", resp.getTokens());
            jsonResp.put("stems", resp.getStems());
            jsonResp.put("suggestions", resp.getSuggestions());
            jsonResp.put("processingTimeMs", resp.getProcessingTimeMs());

            sendJsonResponse(exchange, 200, jsonResp);
        }
    }

    private class FaqHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            addCorsHeaders(exchange);
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(204, -1);
                return;
            }

            if ("GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                List<FaqKnowledgeBase.FaqItem> items = chatEngine.getKnowledgeBase().getItems();
                List<Map<String, Object>> faqList = new ArrayList<>();

                for (FaqKnowledgeBase.FaqItem item : items) {
                    Map<String, Object> m = new LinkedHashMap<>();
                    m.put("id", item.getId());
                    m.put("category", item.getCategory());
                    m.put("question", item.getQuestion());
                    m.put("answer", item.getAnswer());
                    m.put("alternativeQuestions", item.getAlternativeQuestions());
                    faqList.add(m);
                }

                sendJsonResponse(exchange, 200, Map.of("faqs", faqList, "total", faqList.size()));
                return;
            }

            if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                String body = readRequestBody(exchange);
                Map<String, Object> req = JsonHelper.parseObject(body);

                String question = (String) req.get("question");
                String answer = (String) req.get("answer");
                String category = (String) req.getOrDefault("category", "Custom");

                if (question == null || answer == null || question.trim().isEmpty() || answer.trim().isEmpty()) {
                    sendJsonResponse(exchange, 400, Map.of("error", "question and answer are required"));
                    return;
                }

                FaqKnowledgeBase.FaqItem newItem = new FaqKnowledgeBase.FaqItem(
                        "custom-" + UUID.randomUUID().toString().substring(0, 6),
                        category,
                        question.trim(),
                        answer.trim()
                );
                chatEngine.getKnowledgeBase().addFaq(newItem);
                chatEngine.getKnowledgeBase().reindex(chatEngine.getPreprocessor());

                sendJsonResponse(exchange, 201, Map.of(
                        "status", "created",
                        "id", newItem.getId(),
                        "message", "FAQ added and model reindexed successfully!"
                ));
                return;
            }

            sendJsonResponse(exchange, 405, Map.of("error", "Method not supported"));
        }
    }

    private class StatsHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            addCorsHeaders(exchange);
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(204, -1);
                return;
            }

            Map<String, Object> stats = new LinkedHashMap<>();
            stats.put("totalFaqs", chatEngine.getKnowledgeBase().size());
            stats.put("totalIntents", chatEngine.getIntentClassifier().getClasses().size());
            stats.put("vocabularySize", chatEngine.getKnowledgeBase().getVectorizer().getVocabularySize());
            stats.put("messagesProcessed", totalMessagesProcessed.get());
            stats.put("javaVersion", System.getProperty("java.version"));
            stats.put("osName", System.getProperty("os.name"));

            sendJsonResponse(exchange, 200, stats);
        }
    }

    private class StaticFileHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String path = exchange.getRequestURI().getPath();
            if (path == null || path.equals("/") || path.isEmpty()) {
                path = "/index.html";
            }

            // Security: Prevent path traversal
            if (path.contains("..")) {
                sendTextResponse(exchange, 403, "Forbidden");
                return;
            }

            File file = new File(webRoot, path);
            if (!file.exists() || file.isDirectory()) {
                sendTextResponse(exchange, 404, "File Not Found: " + path);
                return;
            }

            String contentType = getMimeType(file.getName());
            exchange.getResponseHeaders().set("Content-Type", contentType);
            byte[] fileBytes = Files.readAllBytes(file.toPath());
            exchange.sendResponseHeaders(200, fileBytes.length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(fileBytes);
            }
        }
    }

    private void addCorsHeaders(HttpExchange exchange) {
        Headers h = exchange.getResponseHeaders();
        h.set("Access-Control-Allow-Origin", "*");
        h.set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        h.set("Access-Control-Allow-Headers", "Content-Type, Authorization");
    }

    private String readRequestBody(HttpExchange exchange) throws IOException {
        try (InputStream is = exchange.getRequestBody()) {
            return new String(is.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    private void sendJsonResponse(HttpExchange exchange, int statusCode, Object data) throws IOException {
        String json = JsonHelper.toJson(data);
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        exchange.sendResponseHeaders(statusCode, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private void sendTextResponse(HttpExchange exchange, int statusCode, String text) throws IOException {
        byte[] bytes = text.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "text/plain; charset=UTF-8");
        exchange.sendResponseHeaders(statusCode, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private String getMimeType(String filename) {
        String lower = filename.toLowerCase();
        if (lower.endsWith(".html") || lower.endsWith(".htm")) return "text/html; charset=UTF-8";
        if (lower.endsWith(".css")) return "text/css; charset=UTF-8";
        if (lower.endsWith(".js")) return "application/javascript; charset=UTF-8";
        if (lower.endsWith(".json")) return "application/json; charset=UTF-8";
        if (lower.endsWith(".svg")) return "image/svg+xml";
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
        if (lower.endsWith(".ico")) return "image/x-icon";
        return "application/octet-stream";
    }
}
