package com.chatbot.gui;

import com.chatbot.engine.ChatEngine;
import com.chatbot.engine.ChatResponse;
import com.chatbot.engine.FaqKnowledgeBase;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLEditorKit;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.List;

/**
 * Modern Java Swing Desktop GUI for the AI Chatbot.
 */
public class ChatbotGUI extends JFrame {

    private final ChatEngine chatEngine;
    private JEditorPane chatPane;
    private JTextField inputField;
    private JButton sendButton;
    private JLabel statusLabel;
    private JLabel confidenceLabel;
    private JProgressBar confidenceBar;
    private JLabel intentLabel;
    private JLabel stemsLabel;
    private StringBuilder chatHtml;

    public ChatbotGUI(ChatEngine chatEngine) {
        this.chatEngine = chatEngine;
        initUI();
    }

    private void initUI() {
        setTitle("AI Chatbot - Java NLP & Machine Learning");
        setSize(1000, 680);
        setMinimumSize(new Dimension(800, 550));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Styling palette
        Color bgDark = new Color(24, 24, 27);
        Color sidebarBg = new Color(30, 31, 38);
        Color accentColor = new Color(79, 70, 229);
        Color textWhite = new Color(243, 244, 246);

        getContentPane().setBackground(bgDark);
        setLayout(new BorderLayout());

        // Header Panel
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(sidebarBg);
        headerPanel.setBorder(new EmptyBorder(14, 20, 14, 20));

        JLabel titleLabel = new JLabel("🤖 AI Intelligent Assistant");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(textWhite);

        JLabel subtitleLabel = new JLabel("NLP Pipeline • Multinomial Naive Bayes • TF-IDF FAQ Matcher");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subtitleLabel.setForeground(new Color(156, 163, 175));

        JPanel headerTextPanel = new JPanel(new GridLayout(2, 1));
        headerTextPanel.setOpaque(false);
        headerTextPanel.add(titleLabel);
        headerTextPanel.add(subtitleLabel);
        headerPanel.add(headerTextPanel, BorderLayout.WEST);

        JButton clearBtn = new JButton("Clear Chat");
        clearBtn.setFocusPainted(false);
        clearBtn.setBackground(new Color(55, 65, 81));
        clearBtn.setForeground(Color.WHITE);
        clearBtn.addActionListener(e -> clearChat());
        headerPanel.add(clearBtn, BorderLayout.EAST);

        add(headerPanel, BorderLayout.NORTH);

        // Center Chat Area
        chatHtml = new StringBuilder();
        chatHtml.append("<html><head><style>")
                .append("body { font-family: 'Segoe UI', sans-serif; background-color: #18181b; color: #f3f4f6; margin: 10px; }")
                .append(".msg-row { margin-bottom: 12px; }")
                .append(".user-bubble { background-color: #4f46e5; color: #ffffff; padding: 10px 14px; border-radius: 12px; display: inline-block; max-width: 80%; }")
                .append(".bot-bubble { background-color: #27272a; color: #f3f4f6; border: 1px solid #3f3f46; padding: 10px 14px; border-radius: 12px; display: inline-block; max-width: 80%; }")
                .append(".meta { font-size: 9px; color: #9ca3af; margin-top: 4px; }")
                .append("b { color: #818cf8; }")
                .append("</style></head><body>");

        chatPane = new JEditorPane();
        chatPane.setEditable(false);
        chatPane.setContentType("text/html");
        chatPane.setBackground(bgDark);
        updateChatView();

        JScrollPane scrollPane = new JScrollPane(chatPane);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);

        // Left Sidebar with Quick FAQ Chips
        JPanel sidebarPanel = createSidebar();

        // Right Diagnostic Panel
        JPanel diagPanel = createDiagnosticsPanel();

        JPanel centerSplit = new JPanel(new BorderLayout());
        centerSplit.add(sidebarPanel, BorderLayout.WEST);
        centerSplit.add(scrollPane, BorderLayout.CENTER);
        centerSplit.add(diagPanel, BorderLayout.EAST);

        add(centerSplit, BorderLayout.CENTER);

        // Bottom Input Area
        JPanel bottomPanel = new JPanel(new BorderLayout(10, 0));
        bottomPanel.setBackground(sidebarBg);
        bottomPanel.setBorder(new EmptyBorder(12, 16, 14, 16));

        inputField = new JTextField();
        inputField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        inputField.setBackground(new Color(24, 24, 27));
        inputField.setForeground(Color.WHITE);
        inputField.setCaretColor(Color.WHITE);
        inputField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(63, 63, 70), 1),
                BorderFactory.createEmptyBorder(10, 12, 10, 12)
        ));

        sendButton = new JButton("Send ➔");
        sendButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        sendButton.setBackground(accentColor);
        sendButton.setForeground(Color.WHITE);
        sendButton.setFocusPainted(false);
        sendButton.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        sendButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        sendButton.addActionListener(e -> sendMessage());
        inputField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    sendMessage();
                }
            }
        });

        bottomPanel.add(inputField, BorderLayout.CENTER);
        bottomPanel.add(sendButton, BorderLayout.EAST);

        add(bottomPanel, BorderLayout.SOUTH);

        // Welcome initial greeting
        appendBotMessage("Hello! I am your Java AI Assistant. How can I assist you today? You can ask questions from the left panel or type your own!", null);
    }

    private JPanel createSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(new Color(30, 31, 38));
        sidebar.setBorder(new EmptyBorder(12, 12, 12, 12));
        sidebar.setPreferredSize(new Dimension(240, 0));

        JLabel faqTitle = new JLabel("💡 Quick Questions");
        faqTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        faqTitle.setForeground(Color.WHITE);
        faqTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        sidebar.add(faqTitle);
        sidebar.add(Box.createRigidArea(new Dimension(0, 10)));

        String[] quickQuestions = {
                "Eligibility requirements for admission",
                "How do I reset my password?",
                "How to connect to campus Wi-Fi?",
                "What is the application deadline?",
                "What is attendance policy?",
                "What is NLP?",
                "What is TF-IDF?",
                "Calculate 125 * 8",
                "What time is it?"
        };

        for (String q : quickQuestions) {
            JButton btn = new JButton("<html>" + q + "</html>");
            btn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            btn.setBackground(new Color(45, 46, 56));
            btn.setForeground(new Color(229, 231, 235));
            btn.setFocusPainted(false);
            btn.setAlignmentX(Component.LEFT_ALIGNMENT);
            btn.setMaximumSize(new Dimension(216, 40));
            btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btn.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(63, 63, 70), 1),
                    BorderFactory.createEmptyBorder(6, 8, 6, 8)
            ));
            btn.addActionListener(e -> {
                inputField.setText(q);
                sendMessage();
            });
            sidebar.add(btn);
            sidebar.add(Box.createRigidArea(new Dimension(0, 6)));
        }

        return sidebar;
    }

    private JPanel createDiagnosticsPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(new Color(30, 31, 38));
        panel.setBorder(new EmptyBorder(12, 12, 12, 12));
        panel.setPreferredSize(new Dimension(220, 0));

        JLabel title = new JLabel("🔬 NLP Inspector");
        title.setFont(new Font("Segoe UI", Font.BOLD, 14));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(title);
        panel.add(Box.createRigidArea(new Dimension(0, 12)));

        statusLabel = createDiagField(panel, "Match Type:", "Ready");
        intentLabel = createDiagField(panel, "Detected Intent:", "None");
        panel.add(Box.createRigidArea(new Dimension(0, 8)));

        JLabel confTitle = new JLabel("Confidence Score:");
        confTitle.setFont(new Font("Segoe UI", Font.BOLD, 11));
        confTitle.setForeground(new Color(156, 163, 175));
        panel.add(confTitle);

        confidenceBar = new JProgressBar(0, 100);
        confidenceBar.setValue(0);
        confidenceBar.setStringPainted(true);
        confidenceBar.setForeground(new Color(16, 185, 129));
        confidenceBar.setBackground(new Color(55, 65, 81));
        confidenceBar.setMaximumSize(new Dimension(200, 20));
        confidenceBar.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(confidenceBar);
        panel.add(Box.createRigidArea(new Dimension(0, 12)));

        stemsLabel = createDiagField(panel, "Word Stems:", "-");

        return panel;
    }

    private JLabel createDiagField(JPanel parent, String labelText, String defaultValue) {
        JLabel title = new JLabel(labelText);
        title.setFont(new Font("Segoe UI", Font.BOLD, 11));
        title.setForeground(new Color(156, 163, 175));
        title.setAlignmentX(Component.LEFT_ALIGNMENT);
        parent.add(title);

        JLabel val = new JLabel("<html>" + defaultValue + "</html>");
        val.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        val.setForeground(Color.WHITE);
        val.setAlignmentX(Component.LEFT_ALIGNMENT);
        parent.add(val);
        parent.add(Box.createRigidArea(new Dimension(0, 8)));
        return val;
    }

    private void sendMessage() {
        String userText = inputField.getText().trim();
        if (userText.isEmpty()) return;

        inputField.setText("");
        appendUserMessage(userText);

        SwingUtilities.invokeLater(() -> {
            ChatResponse response = chatEngine.processMessage(userText);
            appendBotMessage(response.getReply(), response);
            updateDiagnostics(response);
        });
    }

    private void appendUserMessage(String text) {
        chatHtml.append("<div class='msg-row' align='right'>")
                .append("<div class='user-bubble'>")
                .append(escapeHtml(text))
                .append("</div>")
                .append("</div>");
        updateChatView();
    }

    private void appendBotMessage(String text, ChatResponse resp) {
        String metaText = "";
        if (resp != null) {
            metaText = "<div class='meta'>" + resp.getMatchType() + " • " + resp.getProcessingTimeMs() + "ms</div>";
        }

        String formattedText = escapeHtml(text).replace("\n", "<br>");
        // Basic markdown bold
        formattedText = formattedText.replaceAll("\\*\\*(.*?)\\*\\*", "<b>$1</b>");

        chatHtml.append("<div class='msg-row' align='left'>")
                .append("<div class='bot-bubble'>")
                .append(formattedText)
                .append(metaText)
                .append("</div>")
                .append("</div>");
        updateChatView();
    }

    private void updateChatView() {
        chatPane.setText(chatHtml.toString() + "</body></html>");
        chatPane.setCaretPosition(chatPane.getDocument().getLength());
    }

    private void clearChat() {
        chatHtml.setLength(0);
        chatHtml.append("<html><head><style>")
                .append("body { font-family: 'Segoe UI', sans-serif; background-color: #18181b; color: #f3f4f6; margin: 10px; }")
                .append(".msg-row { margin-bottom: 12px; }")
                .append(".user-bubble { background-color: #4f46e5; color: #ffffff; padding: 10px 14px; border-radius: 12px; display: inline-block; max-width: 80%; }")
                .append(".bot-bubble { background-color: #27272a; color: #f3f4f6; border: 1px solid #3f3f46; padding: 10px 14px; border-radius: 12px; display: inline-block; max-width: 80%; }")
                .append(".meta { font-size: 9px; color: #9ca3af; margin-top: 4px; }")
                .append("b { color: #818cf8; }")
                .append("</style></head><body>");
        updateChatView();
        appendBotMessage("Chat history cleared. How can I help you?", null);
    }

    private void updateDiagnostics(ChatResponse resp) {
        if (resp == null) return;
        statusLabel.setText("<html><b style='color:#a78bfa'>" + resp.getMatchType().name() + "</b></html>");
        intentLabel.setText("<html>" + resp.getDetectedIntent() + "</html>");
        int confPercent = (int) (resp.getConfidence() * 100);
        confidenceBar.setValue(confPercent);
        confidenceBar.setString(confPercent + "%");

        if (resp.getStems() != null && !resp.getStems().isEmpty()) {
            stemsLabel.setText("<html>" + String.join(", ", resp.getStems()) + "</html>");
        } else {
            stemsLabel.setText("None");
        }
    }

    private String escapeHtml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;");
    }
}
