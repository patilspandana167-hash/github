package com.chatbot.nlp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Handles text cleaning, contraction expansion, normalization, and NLP transformations.
 */
public class TextPreprocessor {

    private static final Map<Pattern, String> CONTRACTIONS = new HashMap<>();
    private final PorterStemmer stemmer;

    static {
        addContraction("\\b(i)'m\\b", "i am");
        addContraction("\\b(he|she|it)'s\\b", "$1 is");
        addContraction("\\bwhat's\\b", "what is");
        addContraction("\\bwhere's\\b", "where is");
        addContraction("\\bwho's\\b", "who is");
        addContraction("\\bhow's\\b", "how is");
        addContraction("\\bthere's\\b", "there is");
        addContraction("\\b(you|we|they)'re\\b", "$1 are");
        addContraction("\\b(i|you|he|she|it|we|they)'ve\\b", "$1 have");
        addContraction("\\b(i|you|he|she|it|we|they)'ll\\b", "$1 will");
        addContraction("\\b(i|you|he|she|it|we|they)'d\\b", "$1 would");
        addContraction("\\bcan't\\b", "cannot");
        addContraction("\\bwon't\\b", "will not");
        addContraction("\\bshan't\\b", "shall not");
        addContraction("\\bn't\\b", " not");
        addContraction("\\blet's\\b", "let us");
    }

    private static void addContraction(String regex, String replacement) {
        CONTRACTIONS.put(Pattern.compile(regex, Pattern.CASE_INSENSITIVE), replacement);
    }

    public TextPreprocessor() {
        this.stemmer = new PorterStemmer();
    }

    /**
     * Cleans text by expanding contractions, converting to lower case, and normalizing whitespace.
     */
    public String normalize(String text) {
        if (text == null) return "";
        String result = text.trim();

        // Expand contractions
        for (Map.Entry<Pattern, String> entry : CONTRACTIONS.entrySet()) {
            Matcher m = entry.getKey().matcher(result);
            result = m.replaceAll(entry.getValue());
        }

        // Lowercase
        result = result.toLowerCase();

        // Normalize multiple whitespaces
        result = result.replaceAll("\\s+", " ").trim();
        return result;
    }

    /**
     * Extracts tokens from text, removes stop words, and stems each token.
     */
    public List<String> processToStems(String text) {
        String normalized = normalize(text);
        List<String> rawTokens = Tokenizer.tokenize(normalized);
        List<String> filteredTokens = StopWords.filter(rawTokens);

        List<String> stems = new ArrayList<>();
        for (String token : filteredTokens) {
            String stemmed = stemmer.stem(token);
            if (!stemmed.isEmpty()) {
                stems.add(stemmed);
            }
        }
        return stems;
    }

    /**
     * Extracts unigrams and bigrams from stems for richer feature representation.
     */
    public List<String> extractNGrams(List<String> tokens, int n) {
        List<String> ngrams = new ArrayList<>();
        if (tokens == null || tokens.isEmpty()) return ngrams;

        // Unigrams always included
        ngrams.addAll(tokens);

        if (n >= 2) {
            for (int i = 0; i < tokens.size() - 1; i++) {
                ngrams.add(tokens.get(i) + "_" + tokens.get(i + 1));
            }
        }
        if (n >= 3) {
            for (int i = 0; i < tokens.size() - 2; i++) {
                ngrams.add(tokens.get(i) + "_" + tokens.get(i + 1) + "_" + tokens.get(i + 2));
            }
        }
        return ngrams;
    }

    public PorterStemmer getStemmer() {
        return stemmer;
    }
}
