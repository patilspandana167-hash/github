package com.chatbot.nlp;

import java.util.Collection;

/**
 * Calculates Levenshtein distance between strings to detect typos
 * and provide intelligent "Did you mean...?" suggestions.
 */
public class LevenshteinDistance {

    public static int compute(String s1, String s2) {
        if (s1 == null) s1 = "";
        if (s2 == null) s2 = "";

        s1 = s1.toLowerCase();
        s2 = s2.toLowerCase();

        int[] costs = new int[s2.length() + 1];
        for (int j = 0; j <= s2.length(); j++) {
            costs[j] = j;
        }

        for (int i = 1; i <= s1.length(); i++) {
            costs[0] = i;
            int nw = i - 1;
            for (int j = 1; j <= s2.length(); j++) {
                int cj = Math.min(1 + Math.min(costs[j], costs[j - 1]),
                        s1.charAt(i - 1) == s2.charAt(j - 1) ? nw : nw + 1);
                nw = costs[j];
                costs[j] = cj;
            }
        }
        return costs[s2.length()];
    }

    /**
     * Calculates similarity ratio between 0.0 (completely different) and 1.0 (exact match).
     */
    public static double similarity(String s1, String s2) {
        if (s1 == null || s2 == null) return 0.0;
        if (s1.equalsIgnoreCase(s2)) return 1.0;
        int maxLen = Math.max(s1.length(), s2.length());
        if (maxLen == 0) return 1.0;
        int dist = compute(s1, s2);
        return 1.0 - ((double) dist / maxLen);
    }

    /**
     * Finds the closest match from candidate strings.
     */
    public static String findClosestMatch(String query, Collection<String> candidates, double minSimilarityThreshold) {
        if (query == null || candidates == null || candidates.isEmpty()) {
            return null;
        }

        String bestMatch = null;
        double highestSimilarity = 0.0;

        for (String candidate : candidates) {
            double sim = similarity(query, candidate);
            if (sim > highestSimilarity && sim >= minSimilarityThreshold) {
                highestSimilarity = sim;
                bestMatch = candidate;
            }
        }
        return bestMatch;
    }
}
