package com.chatbot.engine;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Handles deterministic, rule-based responses using regular expressions
 * and dynamic logic (date/time, arithmetic calculations, system identity, etc.).
 */
public class RuleBasedMatcher {

    private final Random random = new Random();

    // Regex patterns for rule matching
    private static final Pattern GREETING_PATTERN = Pattern.compile(
            "^(hi|hello|hey|greetings|howdy|good morning|good afternoon|good evening|sup|yo)(\\b|!|\\.|\\?)*",
            Pattern.CASE_INSENSITIVE
    );

    private static final Pattern FAREWELL_PATTERN = Pattern.compile(
            "^(bye|goodbye|see you|cya|take care|farewell|exit|quit)(\\b|!|\\.|\\?)*",
            Pattern.CASE_INSENSITIVE
    );

    private static final Pattern THANKS_PATTERN = Pattern.compile(
            "^(thanks|thank you|thx|much appreciated|many thanks)(\\b|!|\\.|\\?)*",
            Pattern.CASE_INSENSITIVE
    );

    private static final Pattern TIME_PATTERN = Pattern.compile(
            ".*(what time is it|current time|tell me the time|what is the time).*",
            Pattern.CASE_INSENSITIVE
    );

    private static final Pattern DATE_PATTERN = Pattern.compile(
            ".*(what is today's date|current date|today's date|what date is it|what day is it).*",
            Pattern.CASE_INSENSITIVE
    );

    private static final Pattern IDENTITY_PATTERN = Pattern.compile(
            ".*(who are you|what is your name|what are you|tell me about yourself).*",
            Pattern.CASE_INSENSITIVE
    );

    private static final Pattern HELP_PATTERN = Pattern.compile(
            "^(help|what can you do|commands|features|how do i use this)(\\b|!|\\.|\\?)*",
            Pattern.CASE_INSENSITIVE
    );

    private static final Pattern MATH_PATTERN = Pattern.compile(
            "(?:calculate|what is|calc|evaluate)?\\s*(\\d+(?:\\.\\d+)?)\\s*([+\\-*/%^])\\s*(\\d+(?:\\.\\d+)?)",
            Pattern.CASE_INSENSITIVE
    );

    private static final String[] GREETING_REPLIES = {
            "Hello! I am your AI Chatbot assistant. How can I help you today?",
            "Hi there! Good to see you. Feel free to ask me any question.",
            "Hey! I'm here to assist with questions, technical support, or admissions inquiries. What's on your mind?",
            "Greetings! How may I assist you today?"
    };

    private static final String[] FAREWELL_REPLIES = {
            "Goodbye! Have a productive and wonderful day!",
            "Take care! Don't hesitate to reach back out if you have more questions.",
            "See you later! Happy to assist you anytime.",
            "Bye! Have a great day ahead!"
    };

    private static final String[] THANKS_REPLIES = {
            "You are very welcome! Let me know if there's anything else I can do.",
            "Happy to help! Feel free to ask if you need further assistance.",
            "Anytime! I'm always here to assist."
    };

    /**
     * Checks if the user's input matches any rule. Returns a response string,
     * or null if no deterministic rule matches.
     */
    public RuleMatchResult match(String rawInput) {
        if (rawInput == null || rawInput.trim().isEmpty()) {
            return new RuleMatchResult("Please say something so I can help you!", "empty_input", 1.0);
        }

        String trimmed = rawInput.trim();

        // 1. Math calculation rule
        Matcher mathMatcher = MATH_PATTERN.matcher(trimmed);
        if (mathMatcher.find()) {
            try {
                double num1 = Double.parseDouble(mathMatcher.group(1));
                String op = mathMatcher.group(2);
                double num2 = Double.parseDouble(mathMatcher.group(3));
                double result = 0;
                boolean valid = true;

                switch (op) {
                    case "+": result = num1 + num2; break;
                    case "-": result = num1 - num2; break;
                    case "*": result = num1 * num2; break;
                    case "/":
                        if (num2 == 0) {
                            return new RuleMatchResult("Cannot divide by zero!", "arithmetic_error", 1.0);
                        }
                        result = num1 / num2;
                        break;
                    case "%": result = num1 % num2; break;
                    case "^": result = Math.pow(num1, num2); break;
                    default: valid = false;
                }

                if (valid) {
                    String formatted = (result == (long) result) ? String.format("%d", (long) result) : String.format("%.4f", result);
                    return new RuleMatchResult(
                            String.format("Calculated result: %s %s %s = **%s**", mathMatcher.group(1), op, mathMatcher.group(3), formatted),
                            "math_calculation",
                            1.0
                    );
                }
            } catch (Exception ignored) {}
        }

        // 2. Time inquiry
        if (TIME_PATTERN.matcher(trimmed).matches()) {
            String time = LocalTime.now().format(DateTimeFormatter.ofPattern("hh:mm:ss a"));
            return new RuleMatchResult("The current time is **" + time + "**.", "time_query", 1.0);
        }

        // 3. Date inquiry
        if (DATE_PATTERN.matcher(trimmed).matches()) {
            String date = LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy"));
            return new RuleMatchResult("Today is **" + date + "**.", "date_query", 1.0);
        }

        // 4. Bot Identity
        if (IDENTITY_PATTERN.matcher(trimmed).matches()) {
            return new RuleMatchResult(
                    "I am an intelligent AI Chatbot developed in Java. I combine Natural Language Processing (tokenization, stemming, TF-IDF vectorization) and Machine Learning (Multinomial Naive Bayes) with rule-based heuristics to answer questions and assist you in real time!",
                    "bot_identity",
                    1.0
            );
        }

        // 5. Help / Capabilities
        if (HELP_PATTERN.matcher(trimmed).matches()) {
            return new RuleMatchResult(
                    "Here is what I can do:\n" +
                    "- **Frequently Asked Questions**: Ask me about admissions, fees, tech support, Wi-Fi, passwords, or programming.\n" +
                    "- **Real-time Math**: Type math expressions like `calculate 45 * 12` or `150 + 25`.\n" +
                    "- **System Info**: Ask `what time is it` or `what date is it`.\n" +
                    "- **NLP Diagnostics**: View tokenization, stems, and similarity confidence under the inspector panel.\n" +
                    "Try clicking any suggested question chips or type your question below!",
                    "help",
                    1.0
            );
        }

        // 6. Greetings
        if (GREETING_PATTERN.matcher(trimmed).matches()) {
            return new RuleMatchResult(randomChoice(GREETING_REPLIES), "greeting", 1.0);
        }

        // 7. Farewells
        if (FAREWELL_PATTERN.matcher(trimmed).matches()) {
            return new RuleMatchResult(randomChoice(FAREWELL_REPLIES), "farewell", 1.0);
        }

        // 8. Thanks
        if (THANKS_PATTERN.matcher(trimmed).matches()) {
            return new RuleMatchResult(randomChoice(THANKS_REPLIES), "thanks", 1.0);
        }

        return null;
    }

    private String randomChoice(String[] choices) {
        return choices[random.nextInt(choices.length)];
    }

    public static class RuleMatchResult {
        private final String reply;
        private final String ruleName;
        private final double confidence;

        public RuleMatchResult(String reply, String ruleName, double confidence) {
            this.reply = reply;
            this.ruleName = ruleName;
            this.confidence = confidence;
        }

        public String getReply() {
            return reply;
        }

        public String getRuleName() {
            return ruleName;
        }

        public double getConfidence() {
            return confidence;
        }
    }
}
