package com.chatbot.engine;

import com.chatbot.ml.Intent;
import com.chatbot.server.JsonHelper;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Loads FAQs and Intents from JSON files or supplies embedded fallbacks.
 */
public class DataLoader {

    @SuppressWarnings("unchecked")
    public static List<FaqKnowledgeBase.FaqItem> loadFaqs(String filePath) {
        List<FaqKnowledgeBase.FaqItem> faqs = new ArrayList<>();
        File file = new File(filePath);

        if (file.exists()) {
            try {
                String content = new String(Files.readAllBytes(Paths.get(filePath)), StandardCharsets.UTF_8);
                List<Object> list = JsonHelper.parseArray(content);
                for (Object item : list) {
                    if (item instanceof Map) {
                        Map<String, Object> map = (Map<String, Object>) item;
                        FaqKnowledgeBase.FaqItem faq = new FaqKnowledgeBase.FaqItem();
                        faq.setId((String) map.get("id"));
                        faq.setCategory((String) map.get("category"));
                        faq.setQuestion((String) map.get("question"));
                        faq.setAnswer((String) map.get("answer"));

                        Object alt = map.get("alternativeQuestions");
                        if (alt instanceof List) {
                            List<?> altList = (List<?>) alt;
                            for (Object o : altList) {
                                if (o != null) faq.getAlternativeQuestions().add(o.toString());
                            }
                        }
                        faqs.add(faq);
                    }
                }
                return faqs;
            } catch (IOException e) {
                System.err.println("Failed to read FAQ file: " + e.getMessage());
            }
        }

        // Built-in fallback if file missing
        faqs.add(new FaqKnowledgeBase.FaqItem("faq-01", "General", "What are the eligibility requirements for admission?",
                "Applicants need a high school diploma with minimum 70% or 3.0 GPA for undergraduate, or relevant bachelor's degree with 65% for postgraduate."));
        faqs.add(new FaqKnowledgeBase.FaqItem("faq-02", "General", "How do I reset my account password?",
                "Go to the portal login screen, click 'Forgot Password', and follow the email verification instructions."));
        return faqs;
    }

    @SuppressWarnings("unchecked")
    public static List<Intent> loadIntents(String filePath) {
        List<Intent> intents = new ArrayList<>();
        File file = new File(filePath);

        if (file.exists()) {
            try {
                String content = new String(Files.readAllBytes(Paths.get(filePath)), StandardCharsets.UTF_8);
                List<Object> list = JsonHelper.parseArray(content);
                for (Object item : list) {
                    if (item instanceof Map) {
                        Map<String, Object> map = (Map<String, Object>) item;
                        Intent intent = new Intent();
                        intent.setName((String) map.get("name"));
                        intent.setDescription((String) map.get("description"));

                        Object patterns = map.get("patterns");
                        if (patterns instanceof List) {
                            for (Object p : (List<?>) patterns) {
                                if (p != null) intent.addPattern(p.toString());
                            }
                        }

                        Object responses = map.get("responses");
                        if (responses instanceof List) {
                            for (Object r : (List<?>) responses) {
                                if (r != null) intent.addResponse(r.toString());
                            }
                        }

                        intents.add(intent);
                    }
                }
                return intents;
            } catch (IOException e) {
                System.err.println("Failed to read Intents file: " + e.getMessage());
            }
        }

        // Fallback default intents
        Intent greet = new Intent("greeting", "Greetings");
        greet.addPattern("hi"); greet.addPattern("hello"); greet.addPattern("hey");
        greet.addResponse("Hello! How can I assist you today?");
        intents.add(greet);

        return intents;
    }
}
