package com.chatbot.engine;

import com.chatbot.ml.Intent;
import com.chatbot.ml.NaiveBayesClassifier;
import com.chatbot.nlp.LevenshteinDistance;
import com.chatbot.nlp.TextPreprocessor;
import com.chatbot.nlp.Tokenizer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Central orchestrator combining NLP preprocessing, rule heuristics,
 * Naive Bayes intent classification, TF-IDF FAQ retrieval, and fallback logic.
 */
public class ChatEngine {

    private final TextPreprocessor preprocessor;
    private final RuleBasedMatcher ruleMatcher;
    private final NaiveBayesClassifier intentClassifier;
    private final FaqKnowledgeBase knowledgeBase;

    private static final double FAQ_MATCH_THRESHOLD = 0.25;
    private static final double INTENT_CONFIDENCE_THRESHOLD = 0.65;
    private static final double SUGGESTION_SIMILARITY_THRESHOLD = 0.45;

    public ChatEngine() {
        this.preprocessor = new TextPreprocessor();
        this.ruleMatcher = new RuleBasedMatcher();
        this.intentClassifier = new NaiveBayesClassifier();
        this.knowledgeBase = new FaqKnowledgeBase();
    }

    /**
     * Initializes knowledge base and trains classifiers.
     */
    public synchronized void train(List<Intent> intents) {
        if (intents != null && !intents.isEmpty()) {
            intentClassifier.train(intents, preprocessor);
        }
        knowledgeBase.reindex(preprocessor);
    }

    /**
     * Processes a user message and returns a comprehensive ChatResponse.
     */
    public ChatResponse processMessage(String userInput) {
        long startTime = System.currentTimeMillis();

        if (userInput == null || userInput.trim().isEmpty()) {
            return new ChatResponse(
                    "Please enter a message to begin chatting!",
                    ChatResponse.MatchType.RULE_BASED,
                    "empty",
                    1.0,
                    null,
                    "General",
                    Collections.emptyList(),
                    Collections.emptyList(),
                    Collections.emptyList(),
                    System.currentTimeMillis() - startTime
            );
        }

        // 1. NLP Pipeline
        String normalized = preprocessor.normalize(userInput);
        List<String> rawTokens = Tokenizer.tokenize(normalized);
        List<String> stems = preprocessor.processToStems(userInput);
        List<String> ngrams = preprocessor.extractNGrams(stems, 2);

        // 2. High-priority Rule-based Matching
        RuleBasedMatcher.RuleMatchResult ruleResult = ruleMatcher.match(userInput);
        if (ruleResult != null) {
            return new ChatResponse(
                    ruleResult.getReply(),
                    ChatResponse.MatchType.RULE_BASED,
                    ruleResult.getRuleName(),
                    ruleResult.getConfidence(),
                    null,
                    "System",
                    rawTokens,
                    stems,
                    Collections.emptyList(),
                    System.currentTimeMillis() - startTime
            );
        }

        // 3. Machine Learning Intent Classification
        NaiveBayesClassifier.ClassificationResult intentResult = intentClassifier.classify(stems);
        String detectedIntent = intentResult != null ? intentResult.getIntent() : "unknown";
        double intentConf = intentResult != null ? intentResult.getConfidence() : 0.0;

        // 4. Semantic FAQ Matching via TF-IDF & Cosine Similarity
        FaqKnowledgeBase.MatchResult faqResult = knowledgeBase.findBestMatch(ngrams, FAQ_MATCH_THRESHOLD);
        if (faqResult != null) {
            return new ChatResponse(
                    faqResult.getItem().getAnswer(),
                    ChatResponse.MatchType.SEMANTIC_FAQ,
                    detectedIntent,
                    faqResult.getScore(),
                    faqResult.getItem().getQuestion(),
                    faqResult.getItem().getCategory(),
                    rawTokens,
                    stems,
                    Collections.emptyList(),
                    System.currentTimeMillis() - startTime
            );
        }

        // 5. ML Intent Fallback (if intent has strong confidence and is a conversational intent)
        if (intentConf >= INTENT_CONFIDENCE_THRESHOLD && isConversationalIntent(detectedIntent)) {
            String intentReply = getResponseForIntent(detectedIntent);
            if (intentReply != null) {
                return new ChatResponse(
                        intentReply,
                        ChatResponse.MatchType.ML_INTENT,
                        detectedIntent,
                        intentConf,
                        null,
                        "Conversational",
                        rawTokens,
                        stems,
                        Collections.emptyList(),
                        System.currentTimeMillis() - startTime
                );
            }
        }

        // 6. Typo Suggestion / "Did You Mean?" using Levenshtein Distance
        List<String> suggestions = findSuggestions(userInput);
        if (!suggestions.isEmpty()) {
            StringBuilder reply = new StringBuilder("I'm not completely certain about your query, but did you mean:\n");
            for (String sug : suggestions) {
                reply.append("• ").append(sug).append("\n");
            }
            reply.append("\nYou can click one of the suggested chips or rephrase your question.");

            return new ChatResponse(
                    reply.toString().trim(),
                    ChatResponse.MatchType.FALLBACK_SUGGESTION,
                    detectedIntent,
                    0.4,
                    null,
                    "Suggestions",
                    rawTokens,
                    stems,
                    suggestions,
                    System.currentTimeMillis() - startTime
            );
        }

        // 7. General Fallback
        String fallbackReply = "I am sorry, I couldn't find a direct answer to that question. " +
                "Try asking about university admissions, course details, campus Wi-Fi, resetting passwords, " +
                "or type **help** to see all supported topics.";

        return new ChatResponse(
                fallbackReply,
                ChatResponse.MatchType.FALLBACK_UNKNOWN,
                detectedIntent,
                0.0,
                null,
                "Fallback",
                rawTokens,
                stems,
                Collections.emptyList(),
                System.currentTimeMillis() - startTime
        );
    }

    private boolean isConversationalIntent(String intent) {
        return "greeting".equalsIgnoreCase(intent) ||
                "goodbye".equalsIgnoreCase(intent) ||
                "thanks".equalsIgnoreCase(intent) ||
                "help".equalsIgnoreCase(intent) ||
                "bot_identity".equalsIgnoreCase(intent) ||
                "capabilities".equalsIgnoreCase(intent);
    }

    private String getResponseForIntent(String intent) {
        switch (intent.toLowerCase()) {
            case "greeting":
                return "Hello! How can I assist you with your questions today?";
            case "goodbye":
                return "Goodbye! Let me know whenever you need more help.";
            case "thanks":
                return "You're very welcome! Let me know if you need anything else.";
            case "help":
            case "capabilities":
                return "I can answer FAQs on Admissions, Academic Programs, IT/Tech Support, and Programming. You can also ask me for real-time calculations or system time!";
            case "bot_identity":
                return "I'm your AI Chatbot powered by Java, NLP, and Machine Learning!";
            default:
                return null;
        }
    }

    private List<String> findSuggestions(String query) {
        List<String> allQuestions = knowledgeBase.getAllQuestions();
        List<String> matches = new ArrayList<>();

        for (String q : allQuestions) {
            double sim = LevenshteinDistance.similarity(query, q);
            if (sim >= SUGGESTION_SIMILARITY_THRESHOLD) {
                if (!matches.contains(q)) {
                    matches.add(q);
                }
                if (matches.size() >= 3) break;
            }
        }
        return matches;
    }

    public TextPreprocessor getPreprocessor() {
        return preprocessor;
    }

    public FaqKnowledgeBase getKnowledgeBase() {
        return knowledgeBase;
    }

    public NaiveBayesClassifier getIntentClassifier() {
        return intentClassifier;
    }
}
