package com.chatbot.engine;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Encapsulates the complete response payload from the ChatEngine,
 * including reply text, intent classification, confidence, matched FAQ,
 * and NLP diagnostic metadata.
 */
public class ChatResponse {

    public enum MatchType {
        RULE_BASED,
        ML_INTENT,
        SEMANTIC_FAQ,
        FALLBACK_SUGGESTION,
        FALLBACK_UNKNOWN
    }

    private final String reply;
    private final MatchType matchType;
    private final String detectedIntent;
    private final double confidence;
    private final String matchedQuestion;
    private final String category;
    private final List<String> tokens;
    private final List<String> stems;
    private final List<String> suggestions;
    private final long processingTimeMs;

    public ChatResponse(String reply, MatchType matchType, String detectedIntent,
                        double confidence, String matchedQuestion, String category,
                        List<String> tokens, List<String> stems, List<String> suggestions,
                        long processingTimeMs) {
        this.reply = reply;
        this.matchType = matchType;
        this.detectedIntent = detectedIntent;
        this.confidence = confidence;
        this.matchedQuestion = matchedQuestion;
        this.category = category;
        this.tokens = tokens != null ? tokens : Collections.emptyList();
        this.stems = stems != null ? stems : Collections.emptyList();
        this.suggestions = suggestions != null ? suggestions : Collections.emptyList();
        this.processingTimeMs = processingTimeMs;
    }

    public String getReply() {
        return reply;
    }

    public MatchType getMatchType() {
        return matchType;
    }

    public String getDetectedIntent() {
        return detectedIntent;
    }

    public double getConfidence() {
        return confidence;
    }

    public String getMatchedQuestion() {
        return matchedQuestion;
    }

    public String getCategory() {
        return category;
    }

    public List<String> getTokens() {
        return tokens;
    }

    public List<String> getStems() {
        return stems;
    }

    public List<String> getSuggestions() {
        return suggestions;
    }

    public long getProcessingTimeMs() {
        return processingTimeMs;
    }

    @Override
    public String toString() {
        return "ChatResponse{" +
                "reply='" + reply + '\'' +
                ", matchType=" + matchType +
                ", detectedIntent='" + detectedIntent + '\'' +
                ", confidence=" + String.format("%.2f", confidence) +
                ", matchedQuestion='" + matchedQuestion + '\'' +
                ", processingTimeMs=" + processingTimeMs +
                '}';
    }
}
