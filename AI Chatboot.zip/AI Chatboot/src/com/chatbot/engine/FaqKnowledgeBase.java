package com.chatbot.engine;

import com.chatbot.ml.CosineSimilarity;
import com.chatbot.ml.TfIdfVectorizer;
import com.chatbot.nlp.TextPreprocessor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Knowledge base containing Frequently Asked Questions across multiple domains,
 * their TF-IDF vector representations, and semantic search capabilities.
 */
public class FaqKnowledgeBase {

    public static class FaqItem {
        private String id;
        private String category;
        private String question;
        private String answer;
        private List<String> alternativeQuestions;
        private List<String> stems;
        private Map<String, Double> tfidfVector;

        public FaqItem() {
            this.alternativeQuestions = new ArrayList<>();
            this.stems = new ArrayList<>();
            this.tfidfVector = new HashMap<>();
        }

        public FaqItem(String id, String category, String question, String answer) {
            this.id = id;
            this.category = category;
            this.question = question;
            this.answer = answer;
            this.alternativeQuestions = new ArrayList<>();
            this.stems = new ArrayList<>();
            this.tfidfVector = new HashMap<>();
        }

        public String getId() { return id; }
        public void setId(String id) { this.id = id; }
        public String getCategory() { return category; }
        public void setCategory(String category) { this.category = category; }
        public String getQuestion() { return question; }
        public void setQuestion(String question) { this.question = question; }
        public String getAnswer() { return answer; }
        public void setAnswer(String answer) { this.answer = answer; }
        public List<String> getAlternativeQuestions() { return alternativeQuestions; }
        public void setAlternativeQuestions(List<String> alt) { this.alternativeQuestions = alt; }
        public List<String> getStems() { return stems; }
        public void setStems(List<String> stems) { this.stems = stems; }
        public Map<String, Double> getTfidfVector() { return tfidfVector; }
        public void setTfidfVector(Map<String, Double> vec) { this.tfidfVector = vec; }
    }

    public static class MatchResult {
        private final FaqItem item;
        private final double score;
        private final String matchedPhrase;

        public MatchResult(FaqItem item, double score, String matchedPhrase) {
            this.item = item;
            this.score = score;
            this.matchedPhrase = matchedPhrase;
        }

        public FaqItem getItem() { return item; }
        public double getScore() { return score; }
        public String getMatchedPhrase() { return matchedPhrase; }
    }

    private final List<FaqItem> items = new ArrayList<>();
    private final TfIdfVectorizer vectorizer = new TfIdfVectorizer();
    private boolean isIndexed = false;

    public synchronized void addFaq(FaqItem item) {
        items.add(item);
        isIndexed = false;
    }

    public synchronized void addFaq(String id, String category, String question, String answer, List<String> altQuestions) {
        FaqItem item = new FaqItem(id, category, question, answer);
        if (altQuestions != null) {
            item.getAlternativeQuestions().addAll(altQuestions);
        }
        addFaq(item);
    }

    /**
     * Builds stems and trains TF-IDF vectorizer over all FAQ entries and alternative questions.
     */
    public synchronized void reindex(TextPreprocessor preprocessor) {
        List<List<String>> docCorpus = new ArrayList<>();

        for (FaqItem item : items) {
            // Combine main question + alternative questions + answer keywords
            StringBuilder combinedText = new StringBuilder(item.getQuestion());
            for (String alt : item.getAlternativeQuestions()) {
                combinedText.append(" ").append(alt);
            }

            List<String> stems = preprocessor.processToStems(combinedText.toString());
            // Enrich with bigrams
            List<String> ngrams = preprocessor.extractNGrams(stems, 2);
            item.setStems(ngrams);
            docCorpus.add(ngrams);
        }

        vectorizer.fit(docCorpus);

        // Vectorize each FAQ item
        for (FaqItem item : items) {
            Map<String, Double> vec = vectorizer.transform(item.getStems());
            item.setTfidfVector(vec);
        }

        isIndexed = true;
    }

    /**
     * Finds the FAQ with highest cosine similarity to the query tokens.
     */
    public MatchResult findBestMatch(List<String> queryNGrams, double minThreshold) {
        if (!isIndexed || items.isEmpty() || queryNGrams.isEmpty()) {
            return null;
        }

        Map<String, Double> queryVector = vectorizer.transform(queryNGrams);
        if (queryVector.isEmpty()) {
            return null;
        }

        FaqItem bestItem = null;
        double highestScore = 0.0;

        for (FaqItem item : items) {
            double sim = CosineSimilarity.compute(queryVector, item.getTfidfVector());
            if (sim > highestScore) {
                highestScore = sim;
                bestItem = item;
            }
        }

        if (bestItem != null && highestScore >= minThreshold) {
            return new MatchResult(bestItem, highestScore, bestItem.getQuestion());
        }

        return null;
    }

    /**
     * Retrieves all questions (main + alternative) for fuzzy string matching / suggestions.
     */
    public List<String> getAllQuestions() {
        List<String> questions = new ArrayList<>();
        for (FaqItem item : items) {
            questions.add(item.getQuestion());
            questions.addAll(item.getAlternativeQuestions());
        }
        return questions;
    }

    public List<FaqItem> getItems() {
        return Collections.unmodifiableList(items);
    }

    public int size() {
        return items.size();
    }

    public TfIdfVectorizer getVectorizer() {
        return vectorizer;
    }
}
