# Java-Based AI Chatbot (NLP & Machine Learning Engine)

An interactive, production-ready AI Chatbot developed in pure Java 21. It features an end-to-end **Natural Language Processing (NLP)** pipeline, a hybrid **Machine Learning & Rule-based decision engine**, a multi-domain **FAQ knowledge base**, and dual interfaces: a modern responsive **Web Interface** (with live NLP Inspector & Voice Input) and a native **Java Swing Desktop GUI**.

---

## 🌟 Key Features

1. **Natural Language Processing (NLP) Pipeline**
   - **Text Cleaning & Contraction Expansion**: Expands phrases like *"what's"* $\to$ *"what is"*, *"can't"* $\to$ *"cannot"*, lowercases and normalizes whitespace.
   - **Regex Tokenization**: Splits input into discrete alphanumeric words and compound terms.
   - **Stop Words Filtering**: Filters common non-informative English stop words (`the`, `is`, `at`, `which`, `on`).
   - **Porter Stemmer Algorithm**: Complete implementation of the classic Porter Stemming algorithm reducing inflected forms (`connecting`, `connection`, `connected` $\to$ `connect`).
   - **N-Grams Feature Extraction**: Generates unigrams and bigrams for contextual sequence matching.
   - **Levenshtein Distance**: Edit distance calculation providing fuzzy matching and *"Did you mean...?"* typo suggestions.

2. **Machine Learning & Decision Logic**
   - **Multinomial Naive Bayes Classifier**: Trained on labeled intent examples with Laplace smoothing ($\alpha = 1.0$) and log probabilities for stable intent recognition.
   - **TF-IDF Vectorizer**: Computes Term Frequency and smoothed Inverse Document Frequency over FAQ corpus.
   - **Cosine Similarity Metric**: Computes geometric dot products of $L_2$-normalized vectors to find the best semantic FAQ match.
   - **Rule-Based Engine**: High-priority rules for greetings, farewells, gratitude, identity, live date/time inquiries, and arithmetic expression evaluation (e.g. `calculate 25 * 4`).
   - **Graceful Fallback**: Dynamically falls back to Levenshtein fuzzy suggestions if user input has typos.

3. **Dual User Interfaces**
  - **Responsive Web Interface (`http://localhost:8080`, or `http://YOUR-COMPUTER-IP:8080` from another device)**:
     - Modern glassmorphic dark/light UI.
     - Real-time chat bubbles with typing simulation.
     - Quick question chips and category filtering (`Admissions`, `Tech Support`, `Academics`, `AI & Code`).
     - Live **NLP Inspector Drawer**: Visualizes tokens, stems, intent classification, confidence progress bar, and processing latency in milliseconds.
     - **Voice Recognition (Web Speech API)** & **Text-to-Speech (TTS Audio)** button to speak answers out loud.
     - **Interactive Modal**: Add custom FAQs and re-train the model live from the browser without restarting!
   - **Native Java Swing Desktop GUI**:
     - Modern dark theme desktop window with bubble conversation flow.
     - Sidebar with one-click FAQ question buttons.
     - Integrated NLP diagnostics monitor.

---

## 📁 Project Architecture

```
AI Chatboot/
├── src/
│   └── com/
│       └── chatbot/
│           ├── Main.java                        # Main launcher (CLI, Web, GUI)
│           ├── nlp/
│           │   ├── TextPreprocessor.java       # Contractions, normalization, stem generation
│           │   ├── Tokenizer.java              # Sentence and word tokenizer
│           │   ├── StopWords.java              # Stop words dictionary & filter
│           │   ├── PorterStemmer.java          # Complete Porter Stemmer algorithm
│           │   └── LevenshteinDistance.java    # String distance & typo suggestion
│           ├── ml/
│           │   ├── TfIdfVectorizer.java        # TF-IDF matrix computation & L2 normalization
│           │   ├── CosineSimilarity.java       # Vector cosine angle calculation
│           │   ├── NaiveBayesClassifier.java   # Multinomial Naive Bayes intent classifier
│           │   └── Intent.java                 # Intent model with training patterns
│           ├── engine/
│           │   ├── RuleBasedMatcher.java       # Deterministic rules (math, date/time, greetings)
│           │   ├── FaqKnowledgeBase.java       # FAQ storage and semantic retrieval
│           │   ├── ChatEngine.java             # Hybrid decision orchestrator
│           │   ├── ChatResponse.java           # Response DTO with diagnostic metadata
│           │   └── DataLoader.java             # JSON FAQ & Intent dataset loader
│           ├── server/
│           │   ├── WebChatServer.java          # Embedded multi-threaded HTTP server
│           │   └── JsonHelper.java             # Zero-dependency JSON parser & serializer
│           ├── gui/
│           │   └── ChatbotGUI.java             # Java Swing desktop interface
│           └── test/
│               └── ChatbotTest.java            # Automated unit test suite
├── web/
│   ├── index.html                              # Web chat app layout
│   ├── style.css                               # Modern CSS styles (dark/light themes)
│   └── app.js                                  # Frontend client (API calls, TTS, voice, inspector)
├── data/
│   ├── faqs.json                               # FAQ knowledge base across 4 domains
│   └── intents.json                            # Intent training dataset
├── build.bat                                   # Compile script
├── run.bat                                     # Start Web Server (port 8080)
├── run-gui.bat                                 # Start Desktop Swing GUI
├── test.bat                                    # Run automated test suite
└── README.md                                   # Documentation
```

---

## 🚀 How to Run

### Requirements
- **Java 21 or higher** (`java` and `javac` in PATH). Zero external jar files or Maven/Gradle required!

### 1. Quick Start Web Interface (Recommended)
Double click `run.bat` or run in terminal:
```cmd
run.bat
```
Then open your browser to **[http://localhost:8080](http://localhost:8080)**.

The server listens on all network interfaces. To open it from another computer or phone on the same network, replace `localhost` with the host computer's IPv4 address shown in the server console, for example `http://192.168.1.25:8080`. Windows Firewall may ask for permission the first time; allow Java on private networks.

### 2. Launch Desktop GUI (Swing)
Double click `run-gui.bat` or run:
```cmd
run-gui.bat
```

### 3. Run Automated Tests
Double click `test.bat` or run:
```cmd
test.bat
```

### 4. Interactive Console Mode
```cmd
java -cp bin com.chatbot.Main --cli
```

---

## 📡 REST API Endpoints

The embedded Java HTTP server provides REST endpoints:

### `POST /api/chat`
Process a natural language user query.
- **Request**:
  ```json
  { "message": "How do I reset my password?" }
  ```
- **Response**:
  ```json
  {
    "status": "success",
    "reply": "To reset your password, visit the portal login page and click 'Forgot Password'...",
    "matchType": "SEMANTIC_FAQ",
    "detectedIntent": "tech_support_inquiry",
    "confidence": 0.88,
    "matchedQuestion": "How do I reset my student portal account password?",
    "category": "Tech Support & IT",
    "tokens": ["how", "do", "i", "reset", "my", "password"],
    "stems": ["reset", "password"],
    "suggestions": [],
    "processingTimeMs": 2
  }
  ```

### `GET /api/faqs`
Returns all indexed FAQs with categories and alternative question patterns.

### `POST /api/faqs`
Dynamically adds a new question-answer pair and reindexes the model on the fly.
- **Request**:
  ```json
  {
    "category": "Admissions & University",
    "question": "Where is the admissions office located?",
    "answer": "The admissions office is on the 1st floor of the Administrative Block."
  }
  ```

### `GET /api/stats`
Returns live chatbot metrics (total FAQs, intents, vocabulary size, message counter).

---

## 💡 Example Queries to Try

| Category | Try asking: |
|---|---|
| **Admissions** | "What are the eligibility requirements for admission?" |
| **Tech Support** | "How can I connect to campus Wi-Fi network?" |
| **Password Reset** | "I forgot my portal password, how do I reset it?" |
| **Academics** | "What is the mandatory attendance policy for exams?" |
| **NLP Explanation** | "What is Natural Language Processing and how does it work?" |
| **TF-IDF Explanation**| "Explain Term Frequency Inverse Document Frequency" |
| **Math Calculation** | "Calculate 150 * 12" or "What is 4500 / 9" |
| **Real-time System** | "What time is it?" or "What is today's date?" |
| **Typo Resilience** | "How to resset passwrd?" *(triggers fuzzy suggestion/stem match)* |
| **Capabilities** | "What can you do?" or "help" |
