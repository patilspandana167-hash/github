@echo off
if not exist bin\com\chatbot\Main.class (
    call build.bat
)
echo ========================================================
echo   Launching Java AI Chatbot Desktop GUI...
echo ========================================================
java -cp bin com.chatbot.Main --gui
