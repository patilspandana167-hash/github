@echo off
if not exist bin\com\chatbot\Main.class (
    call build.bat
)
echo ========================================================
echo   Starting Java AI Chatbot Web Server on port 8080...
echo   Open your browser to: http://localhost:8080
echo   For another device, use this computer's IPv4 address:
echo   http://YOUR-COMPUTER-IP:8080
echo ========================================================
java -cp bin com.chatbot.Main --port 8080
