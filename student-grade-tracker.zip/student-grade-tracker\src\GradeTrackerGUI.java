import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.io.File;
import java.util.List;

public class GradeTrackerGUI extends JFrame {
    private final GradeDatabase database;
    private JTable studentTable;
    private DefaultTableModel tableModel;
    private TableRowSorter<DefaultTableModel> rowSorter;
    private AnalyticsPanel analyticsPanel;
    private ModernUIComponents.ModernTextField searchField;

    public GradeTrackerGUI() {
        // Initialize database in the default user directory
        String dbPath = System.getProperty("user.home") + File.separator + ".student_grades.csv";
        this.database = new GradeDatabase(dbPath);
        this.database.load();
        if (this.database.getStudents().isEmpty()) {
            bootstrapMockData();
        }

        setTitle("GradeScale - Student Performance Tracker");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 750);
        setLocationRelativeTo(null);
        getContentPane().setBackground(ModernUIComponents.COLOR_BG);
        setLayout(new BorderLayout(15, 15));

        // Root padding
        ((JPanel) getContentPane()).setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Build UI Segments
        initHeaderPanel();
        initAnalyticsPanel();
        initTablePanel();

        // Initial Data Refresh
        refreshUI();
    }

    private void initHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout(10, 10));
        headerPanel.setOpaque(false);

        // Title and Subtitle Info
        JPanel titlePanel = new JPanel(new GridLayout(2, 1, 2, 2));
        titlePanel.setOpaque(false);
        JLabel titleLabel = new JLabel("GradeScale Tracker");
        titleLabel.setFont(ModernUIComponents.fontTitle.deriveFont(26f));
        titleLabel.setForeground(ModernUIComponents.COLOR_ACCENT);
        JLabel subtitleLabel = new JLabel("Visual Academic Grade & Performance Analyzer");
        subtitleLabel.setFont(ModernUIComponents.fontBody.deriveFont(12f));
        subtitleLabel.setForeground(ModernUIComponents.COLOR_TEXT_MUTED);
        titlePanel.add(titleLabel);
        titlePanel.add(subtitleLabel);
        headerPanel.add(titlePanel, BorderLayout.WEST);

        // Header Actions (Import / Export / Report)
        JPanel actionsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        actionsPanel.setOpaque(false);

        ModernUIComponents.ModernButton importBtn = new ModernUIComponents.ModernButton("Import CSV", 
                ModernUIComponents.COLOR_CARD, ModernUIComponents.COLOR_BORDER, ModernUIComponents.COLOR_TEXT, 10);
        ModernUIComponents.ModernButton exportBtn = new ModernUIComponents.ModernButton("Export CSV",
                ModernUIComponents.COLOR_CARD, ModernUIComponents.COLOR_BORDER, ModernUIComponents.COLOR_TEXT, 10);
        ModernUIComponents.ModernButton reportBtn = new ModernUIComponents.ModernButton("Generate Report",
                ModernUIComponents.COLOR_CARD, ModernUIComponents.COLOR_BORDER, ModernUIComponents.COLOR_TEXT, 10);

        importBtn.addActionListener(e -> handleImport());
        exportBtn.addActionListener(e -> handleExport());
        reportBtn.addActionListener(e -> handleReport());

        actionsPanel.add(importBtn);
        actionsPanel.add(exportBtn);
        actionsPanel.add(reportBtn);

        headerPanel.add(actionsPanel, BorderLayout.EAST);
        add(headerPanel, BorderLayout.NORTH);
    }

    private void initAnalyticsPanel() {
        analyticsPanel = new AnalyticsPanel(database);
        add(analyticsPanel, BorderLayout.CENTER);
    }

    private void initTablePanel() {
        JPanel bottomContainer = new JPanel(new BorderLayout(10, 10));
        bottomContainer.setOpaque(false);

        // Controls bar (Search + Add/Edit/Delete Buttons)
        JPanel controlBar = new JPanel(new BorderLayout(15, 0));
        controlBar.setOpaque(false);
        controlBar.setPreferredSize(new Dimension(bottomContainer.getWidth(), 40));

        // Search panel
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        searchPanel.setOpaque(false);
        searchField = new ModernUIComponents.ModernTextField("Search by Student Name or ID...", 25);
        searchField.setPreferredSize(new Dimension(280, 36));
        searchField.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { filterTable(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { filterTable(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { filterTable(); }
        });
        searchPanel.add(searchField);
        controlBar.add(searchPanel, BorderLayout.WEST);

        // CRUD buttons panel
        JPanel crudPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        crudPanel.setOpaque(false);

        ModernUIComponents.ModernButton addBtn = new ModernUIComponents.ModernButton("Add Student",
                ModernUIComponents.COLOR_ACCENT, ModernUIComponents.COLOR_ACCENT_HOVER, ModernUIComponents.COLOR_BG, 10);
        ModernUIComponents.ModernButton editBtn = new ModernUIComponents.ModernButton("Edit Student",
                ModernUIComponents.COLOR_CARD, ModernUIComponents.COLOR_BORDER, ModernUIComponents.COLOR_TEXT, 10);
        ModernUIComponents.ModernButton deleteBtn = new ModernUIComponents.ModernButton("Delete Student",
                ModernUIComponents.COLOR_CARD, ModernUIComponents.COLOR_BORDER, ModernUIComponents.COLOR_DANGER, 10);

        addBtn.addActionListener(e -> showStudentForm(null));
        editBtn.addActionListener(e -> {
            int selectedRow = studentTable.getSelectedRow();
            if (selectedRow >= 0) {
                int modelRow = studentTable.convertRowIndexToModel(selectedRow);
                String id = (String) tableModel.getValueAt(modelRow, 0);
                database.findStudent(id).ifPresent(this::showStudentForm);
            } else {
                JOptionPane.showMessageDialog(this, "Please select a student to edit.", "Selection Required", JOptionPane.WARNING_MESSAGE);
            }
        });
        deleteBtn.addActionListener(e -> handleDelete());

        crudPanel.add(addBtn);
        crudPanel.add(editBtn);
        crudPanel.add(deleteBtn);
        controlBar.add(crudPanel, BorderLayout.EAST);

        bottomContainer.add(controlBar, BorderLayout.NORTH);

        // Table setup
        String[] columns = {"Student ID", "Name", "Homework (20%)", "Quizzes (30%)", "Exams (50%)", "Final Score", "Grade", "GPA"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Table editing disabled, use dialog instead
            }

            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex >= 2 && columnIndex <= 5) return Double.class;
                return String.class;
            }
        };

        studentTable = new JTable(tableModel);
        ModernUIComponents.styleTable(studentTable);

        rowSorter = new TableRowSorter<>(tableModel);
        studentTable.setRowSorter(rowSorter);

        JScrollPane scrollPane = new JScrollPane(studentTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(ModernUIComponents.COLOR_BORDER, 1));
        scrollPane.getViewport().setBackground(ModernUIComponents.COLOR_BG);
        bottomContainer.add(scrollPane, BorderLayout.CENTER);

        bottomContainer.setPreferredSize(new Dimension(bottomContainer.getWidth(), 320));
        add(bottomContainer, BorderLayout.SOUTH);
    }

    private void filterTable() {
        String text = searchField.getCleanText();
        if (text.isEmpty()) {
            rowSorter.setRowFilter(null);
        } else {
            rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text, 0, 1));
        }
    }

    private void refreshUI() {
        // Clear table records
        tableModel.setRowCount(0);

        // Load and add students
        List<Student> list = database.getStudents();
        for (Student s : list) {
            tableModel.addRow(new Object[]{
                    s.getId(),
                    s.getName(),
                    s.getHomeworkScore(),
                    s.getQuizScore(),
                    s.getExamScore(),
                    s.getFinalScore(),
                    s.getLetterGrade(),
                    s.getGPA()
            });
        }

        // Request chart repaint
        analyticsPanel.repaint();
    }

    private void showStudentForm(Student student) {
        JDialog dialog = new JDialog(this, student == null ? "Add Student Record" : "Edit Student Record", true);
        dialog.setSize(380, 420);
        dialog.setLocationRelativeTo(this);
        dialog.setResizable(false);
        
        JPanel contentPanel = new JPanel(new GridBagLayout());
        contentPanel.setBackground(ModernUIComponents.COLOR_CARD);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 0, 8, 0);
        gbc.gridx = 0;

        // Header Title
        JLabel titleLabel = new JLabel(student == null ? "New Student Entry" : "Modify Details");
        titleLabel.setFont(ModernUIComponents.fontHeader.deriveFont(18f));
        titleLabel.setForeground(ModernUIComponents.COLOR_ACCENT);
        gbc.gridy = 0;
        contentPanel.add(titleLabel, gbc);

        // Fields
        ModernUIComponents.ModernTextField idField = new ModernUIComponents.ModernTextField("Student ID (e.g. STU101)", 15);
        ModernUIComponents.ModernTextField nameField = new ModernUIComponents.ModernTextField("Student Name", 15);
        ModernUIComponents.ModernTextField hwField = new ModernUIComponents.ModernTextField("Homework Score (0-100)", 15);
        ModernUIComponents.ModernTextField quizField = new ModernUIComponents.ModernTextField("Quiz Score (0-100)", 15);
        ModernUIComponents.ModernTextField examField = new ModernUIComponents.ModernTextField("Exam Score (0-100)", 15);

        if (student != null) {
            idField.setCleanText(student.getId());
            idField.setEnabled(false); // ID cannot be updated
            nameField.setCleanText(student.getName());
            hwField.setCleanText(String.valueOf(student.getHomeworkScore()));
            quizField.setCleanText(String.valueOf(student.getQuizScore()));
            examField.setCleanText(String.valueOf(student.getExamScore()));
        }

        gbc.gridy = 1; contentPanel.add(idField, gbc);
        gbc.gridy = 2; contentPanel.add(nameField, gbc);
        gbc.gridy = 3; contentPanel.add(hwField, gbc);
        gbc.gridy = 4; contentPanel.add(quizField, gbc);
        gbc.gridy = 5; contentPanel.add(examField, gbc);

        // Button panel
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        btnPanel.setOpaque(false);

        ModernUIComponents.ModernButton saveBtn = new ModernUIComponents.ModernButton("Save Record");
        ModernUIComponents.ModernButton cancelBtn = new ModernUIComponents.ModernButton("Cancel", 
                ModernUIComponents.COLOR_BG, ModernUIComponents.COLOR_BORDER, ModernUIComponents.COLOR_TEXT_MUTED, 10);

        saveBtn.addActionListener(e -> {
            String id = idField.getCleanText().trim();
            String name = nameField.getCleanText().trim();
            String hwStr = hwField.getCleanText().trim();
            String quizStr = quizField.getCleanText().trim();
            String examStr = examField.getCleanText().trim();

            if (id.isEmpty() || name.isEmpty() || hwStr.isEmpty() || quizStr.isEmpty() || examStr.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "All fields are required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                double hw = Double.parseDouble(hwStr);
                double quiz = Double.parseDouble(quizStr);
                double exam = Double.parseDouble(examStr);

                if (hw < 0 || hw > 100 || quiz < 0 || quiz > 100 || exam < 0 || exam > 100) {
                    JOptionPane.showMessageDialog(dialog, "Scores must be between 0 and 100.", "Validation Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Check duplicate ID for new entries
                if (student == null && database.findStudent(id).isPresent()) {
                    JOptionPane.showMessageDialog(dialog, "A student with this ID already exists.", "Duplicate ID", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                Student newOrUpdated = new Student(id, name, hw, quiz, exam);
                if (student == null) {
                    database.addStudent(newOrUpdated);
                } else {
                    database.updateStudent(newOrUpdated);
                }
                
                dialog.dispose();
                refreshUI();

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Scores must be valid numbers.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        cancelBtn.addActionListener(e -> dialog.dispose());

        btnPanel.add(cancelBtn);
        btnPanel.add(saveBtn);

        gbc.gridy = 6;
        gbc.insets = new Insets(15, 0, 0, 0);
        contentPanel.add(btnPanel, gbc);

        dialog.add(contentPanel);
        dialog.setVisible(true);
    }

    private void handleDelete() {
        int selectedRow = studentTable.getSelectedRow();
        if (selectedRow >= 0) {
            int modelRow = studentTable.convertRowIndexToModel(selectedRow);
            String id = (String) tableModel.getValueAt(modelRow, 0);
            String name = (String) tableModel.getValueAt(modelRow, 1);

            int confirm = JOptionPane.showConfirmDialog(this, 
                    "Are you sure you want to delete student " + name + " (ID: " + id + ")?", 
                    "Confirm Deletion", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            
            if (confirm == JOptionPane.YES_OPTION) {
                database.deleteStudent(id);
                refreshUI();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a student record to delete.", "Selection Required", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void handleImport() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Import Student Records (CSV)");
        fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("CSV Files (*.csv)", "csv"));
        
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            boolean success = database.importFromCSV(selectedFile);
            if (success) {
                refreshUI();
                JOptionPane.showMessageDialog(this, "Student records imported successfully!", "Import Complete", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Failed to import CSV. Ensure values are formatted correctly.", "Import Failed", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void handleExport() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Export Student Performance Records");
        fileChooser.setSelectedFile(new File("student_grades_export.csv"));
        fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("CSV Files (*.csv)", "csv"));

        int result = fileChooser.showSaveDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            // Append .csv extension if missing
            if (!file.getName().toLowerCase().endsWith(".csv")) {
                file = new File(file.getAbsolutePath() + ".csv");
            }
            boolean success = database.exportToCSV(file);
            if (success) {
                JOptionPane.showMessageDialog(this, "CSV file exported successfully to:\n" + file.getAbsolutePath(), "Export Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Error exporting CSV file.", "Export Failed", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void handleReport() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Generate Performance Report (TXT)");
        fileChooser.setSelectedFile(new File("academic_report.txt"));
        fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Text Files (*.txt)", "txt"));

        int result = fileChooser.showSaveDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            if (!file.getName().toLowerCase().endsWith(".txt")) {
                file = new File(file.getAbsolutePath() + ".txt");
            }
            boolean success = database.generateReport(file);
            if (success) {
                JOptionPane.showMessageDialog(this, "Academic Report generated successfully to:\n" + file.getAbsolutePath(), "Report Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Error generating report.", "Report Failed", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void bootstrapMockData() {
        database.addStudent(new Student("STU-1001", "Alice Johnson", 94.0, 90.0, 92.0));
        database.addStudent(new Student("STU-1002", "Bob Smith", 82.0, 85.0, 80.0));
        database.addStudent(new Student("STU-1003", "Charlie Brown", 65.0, 70.0, 68.0));
        database.addStudent(new Student("STU-1004", "Daisy Miller", 98.0, 96.0, 95.0));
        database.addStudent(new Student("STU-1005", "Ethan Hunt", 52.0, 60.0, 48.0));
    }

    public static void main(String[] args) {
        // Apply smooth visual antialiasing at JVM level
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");

        // Use modern FlatLaf-like aesthetics using standard Nimbus style as fallback, then customize
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            // Use default L&F
        }

        // Set custom Dark Look and feel properties
        UIManager.put("nimbusBase", ModernUIComponents.COLOR_BG);
        UIManager.put("nimbusBlueGrey", ModernUIComponents.COLOR_CARD);
        UIManager.put("control", ModernUIComponents.COLOR_CARD);
        UIManager.put("text", ModernUIComponents.COLOR_TEXT);
        UIManager.put("nimbusLightBackground", ModernUIComponents.COLOR_BG);
        UIManager.put("nimbusSelectedText", Color.WHITE);
        UIManager.put("nimbusSelectionBackground", ModernUIComponents.COLOR_ACCENT.darker());
        UIManager.put("info", ModernUIComponents.COLOR_CARD);

        SwingUtilities.invokeLater(() -> {
            GradeTrackerGUI app = new GradeTrackerGUI();
            app.setVisible(true);
        });
    }
}
