import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class GradeDatabase {
    private final List<Student> students;
    private File dbFile;

    public GradeDatabase(String filepath) {
        this.students = new ArrayList<>();
        this.dbFile = new File(filepath);
        ensureFileExists();
    }

    private void ensureFileExists() {
        try {
            File parent = dbFile.getParentFile();
            if (parent != null && !parent.exists()) {
                parent.mkdirs();
            }
            if (!dbFile.exists()) {
                dbFile.createNewFile();
            }
        } catch (IOException e) {
            System.err.println("Failed to initialize database file: " + e.getMessage());
        }
    }

    public synchronized List<Student> getStudents() {
        return new ArrayList<>(students);
    }

    public synchronized void addStudent(Student student) {
        students.add(student);
        save();
    }

    public synchronized boolean deleteStudent(String id) {
        boolean removed = students.removeIf(s -> s.getId().equals(id));
        if (removed) {
            save();
        }
        return removed;
    }

    public synchronized boolean updateStudent(Student updatedStudent) {
        for (int i = 0; i < students.size(); i++) {
            if (students.get(i).getId().equals(updatedStudent.getId())) {
                students.set(i, updatedStudent);
                save();
                return true;
            }
        }
        return false;
    }

    public synchronized Optional<Student> findStudent(String id) {
        return students.stream().filter(s -> s.getId().equals(id)).findFirst();
    }

    public synchronized void save() {
        try (PrintWriter writer = new PrintWriter(new OutputStreamWriter(
                new FileOutputStream(dbFile), StandardCharsets.UTF_8))) {
            for (Student student : students) {
                writer.println(student.toString());
            }
        } catch (IOException e) {
            System.err.println("Error saving database: " + e.getMessage());
        }
    }

    public synchronized void load() {
        students.clear();
        if (!dbFile.exists()) return;

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                new FileInputStream(dbFile), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                try {
                    Student student = Student.fromCSV(line);
                    if (student != null) {
                        students.add(student);
                    }
                } catch (Exception e) {
                    System.err.println("Skipping malformed database record: " + line);
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading database: " + e.getMessage());
        }
    }

    public synchronized boolean importFromCSV(File file) {
        List<Student> imported = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            boolean firstLine = true;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                // Skip header if present
                if (firstLine) {
                    firstLine = false;
                    if (line.toLowerCase().contains("id") || line.toLowerCase().contains("name")) {
                        continue;
                    }
                }
                try {
                    Student student = Student.fromCSV(line);
                    if (student != null) {
                        imported.add(student);
                    }
                } catch (Exception e) {
                    // Skip invalid lines
                }
            }
            if (!imported.isEmpty()) {
                students.addAll(imported);
                save();
                return true;
            }
        } catch (IOException e) {
            System.err.println("CSV Import error: " + e.getMessage());
        }
        return false;
    }

    public synchronized boolean exportToCSV(File file) {
        try (PrintWriter writer = new PrintWriter(new OutputStreamWriter(
                new FileOutputStream(file), StandardCharsets.UTF_8))) {
            writer.println("ID,Name,HomeworkScore,QuizScore,ExamScore,FinalScore,LetterGrade,GPA");
            for (Student student : students) {
                writer.printf("%s,%s,%.2f,%.2f,%.2f,%.2f,%s,%.2f\n",
                        student.getId(),
                        student.getName(),
                        student.getHomeworkScore(),
                        student.getQuizScore(),
                        student.getExamScore(),
                        student.getFinalScore(),
                        student.getLetterGrade(),
                        student.getGPA());
            }
            return true;
        } catch (IOException e) {
            System.err.println("CSV Export error: " + e.getMessage());
            return false;
        }
    }

    public synchronized boolean generateReport(File file) {
        try (PrintWriter writer = new PrintWriter(new OutputStreamWriter(
                new FileOutputStream(file), StandardCharsets.UTF_8))) {
            writer.println("==================================================");
            writer.println("             STUDENT GRADE REPORT                ");
            writer.println("==================================================");
            writer.printf("Total Students: %d\n", students.size());
            if (students.isEmpty()) {
                writer.println("No records found.");
                return true;
            }

            double sum = 0;
            double max = Double.MIN_VALUE;
            double min = Double.MAX_VALUE;
            int passCount = 0;

            for (Student s : students) {
                double score = s.getFinalScore();
                sum += score;
                if (score > max) max = score;
                if (score < min) min = score;
                if (!s.getLetterGrade().equals("F")) {
                    passCount++;
                }
            }

            double avg = sum / students.size();
            double passRate = ((double) passCount / students.size()) * 100.0;

            writer.printf("Average Score:  %.2f\n", avg);
            writer.printf("Highest Score:  %.2f\n", max);
            writer.printf("Lowest Score:   %.2f\n", min);
            writer.printf("Passing Rate:   %.2f%%\n", passRate);
            writer.println("--------------------------------------------------");
            writer.printf("%-10s %-20s %-10s %-5s\n", "ID", "Name", "Final Score", "Grade");
            writer.println("--------------------------------------------------");
            for (Student s : students) {
                writer.printf("%-10s %-20s %-11.2f %-5s\n",
                        s.getId(), s.getName(), s.getFinalScore(), s.getLetterGrade());
            }
            writer.println("==================================================");
            return true;
        } catch (IOException e) {
            System.err.println("Report Generation error: " + e.getMessage());
            return false;
        }
    }
}
