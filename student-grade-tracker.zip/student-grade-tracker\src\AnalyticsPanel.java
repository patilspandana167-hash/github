import javax.swing.*;
import java.awt.*;
import java.awt.geom.Arc2D;
import java.awt.geom.RoundRectangle2D;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AnalyticsPanel extends JPanel {
    private final GradeDatabase database;

    public AnalyticsPanel(GradeDatabase database) {
        this.database = database;
        setBackground(ModernUIComponents.COLOR_BG);
        setPreferredSize(new Dimension(800, 320));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();

        // Database stats
        List<Student> students = database.getStudents();
        int total = students.size();
        double avgScore = 0;
        double avgGpa = 0;
        int passCount = 0;
        Map<String, Integer> distributions = new HashMap<>();
        distributions.put("A", 0);
        distributions.put("B", 0);
        distributions.put("C", 0);
        distributions.put("D", 0);
        distributions.put("F", 0);

        if (total > 0) {
            double sumScore = 0;
            double sumGpa = 0;
            for (Student s : students) {
                sumScore += s.getFinalScore();
                sumGpa += s.getGPA();
                String lg = s.getLetterGrade();
                distributions.put(lg, distributions.getOrDefault(lg, 0) + 1);
                if (!lg.equals("F")) {
                    passCount++;
                }
            }
            avgScore = sumScore / total;
            avgGpa = sumGpa / total;
        }

        double passRate = total > 0 ? ((double) passCount / total) * 100.0 : 0.0;

        // Draw 4 Top Summary Cards (Total Students, Avg Score, Avg GPA, Passing Rate)
        int cardWidth = (width - 50) / 4;
        int cardHeight = 70;
        int cardY = 15;

        // Card 1: Total Students
        drawStatCard(g2, 10, cardY, cardWidth, cardHeight, "Total Students", String.valueOf(total), ModernUIComponents.COLOR_ACCENT);

        // Card 2: Average Score
        drawStatCard(g2, 10 + cardWidth + 10, cardY, cardWidth, cardHeight, "Average Score", String.format("%.1f%%", avgScore), ModernUIComponents.COLOR_SUCCESS);

        // Card 3: Average GPA
        drawStatCard(g2, 10 + (cardWidth + 10) * 2, cardY, cardWidth, cardHeight, "Average GPA", String.format("%.2f", avgGpa), ModernUIComponents.COLOR_WARNING);

        // Card 4: Passing Rate
        drawStatCard(g2, 10 + (cardWidth + 10) * 3, cardY, cardWidth, cardHeight, "Passing Rate", String.format("%.1f%%", passRate), ModernUIComponents.COLOR_DANGER);

        // Layout below cards
        int chartY = cardY + cardHeight + 20;
        int chartHeight = height - chartY - 15;
        int chartWidthLeft = (int) (width * 0.6) - 15;
        int dialWidthRight = width - chartWidthLeft - 30;

        // Left Panel: Grade Distribution Bar Chart
        drawGradeDistribution(g2, 10, chartY, chartWidthLeft, chartHeight, distributions);

        // Right Panel: Passing Rate Gauge Dial
        drawPassingRateDial(g2, 10 + chartWidthLeft + 10, chartY, dialWidthRight, chartHeight, passRate);

        g2.dispose();
    }

    private void drawStatCard(Graphics2D g2, int x, int y, int w, int h, String label, String value, Color accentColor) {
        // Draw Card Background
        g2.setColor(ModernUIComponents.COLOR_CARD);
        g2.fill(new RoundRectangle2D.Double(x, y, w, h, 14, 14));

        // Draw Left Accent Line
        g2.setColor(accentColor);
        g2.fill(new RoundRectangle2D.Double(x, y + 10, 4, h - 20, 2, 2));

        // Label
        g2.setFont(ModernUIComponents.fontBody.deriveFont(11f));
        g2.setColor(ModernUIComponents.COLOR_TEXT_MUTED);
        g2.drawString(label.toUpperCase(), x + 15, y + 25);

        // Value
        g2.setFont(ModernUIComponents.fontTitle.deriveFont(18f));
        g2.setColor(ModernUIComponents.COLOR_TEXT);
        g2.drawString(value, x + 15, y + 52);
    }

    private void drawGradeDistribution(Graphics2D g2, int x, int y, int w, int h, Map<String, Integer> distributions) {
        // Draw Container Background
        g2.setColor(ModernUIComponents.COLOR_CARD);
        g2.fill(new RoundRectangle2D.Double(x, y, w, h, 14, 14));

        // Draw Title
        g2.setColor(ModernUIComponents.COLOR_TEXT);
        g2.setFont(ModernUIComponents.fontHeader);
        g2.drawString("Grade Distribution", x + 20, y + 25);

        String[] grades = {"A", "B", "C", "D", "F"};
        int maxCount = 1;
        for (String g : grades) {
            maxCount = Math.max(maxCount, distributions.get(g));
        }

        // Draw Bars
        int barAreaY = y + 40;
        int barAreaHeight = h - 75;
        int barWidth = Math.min(36, (w - 40) / 5 - 15);
        int gap = (w - 40 - (barWidth * 5)) / 4;

        for (int i = 0; i < grades.length; i++) {
            String grade = grades[i];
            int count = distributions.get(grade);
            
            // Calculate height proportional to count
            int barHeight = (int) (((double) count / maxCount) * barAreaHeight);
            int barX = x + 20 + i * (barWidth + gap);
            int barY = barAreaY + barAreaHeight - barHeight;

            // Paint Bar Accent color depending on grade
            Color barColor;
            switch (grade) {
                case "A": barColor = ModernUIComponents.COLOR_SUCCESS; break;
                case "B": barColor = ModernUIComponents.COLOR_ACCENT; break;
                case "C": barColor = ModernUIComponents.COLOR_WARNING; break;
                case "D": barColor = new Color(250, 179, 135); break; // Orange
                default: barColor = ModernUIComponents.COLOR_DANGER; break;
            }

            // Draw shadow track background for visual depth
            g2.setColor(ModernUIComponents.COLOR_BORDER);
            g2.fill(new RoundRectangle2D.Double(barX, barAreaY, barWidth, barAreaHeight, 8, 8));

            // Draw Actual Bar
            if (barHeight > 0) {
                g2.setColor(barColor);
                g2.fill(new RoundRectangle2D.Double(barX, barY, barWidth, barHeight, 8, 8));
            }

            // Draw Value text
            g2.setColor(ModernUIComponents.COLOR_TEXT);
            g2.setFont(ModernUIComponents.fontBold.deriveFont(11f));
            String valStr = String.valueOf(count);
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(valStr, barX + (barWidth - fm.stringWidth(valStr)) / 2, barAreaY - 5);

            // Draw Label text below bar
            g2.setColor(ModernUIComponents.COLOR_TEXT_MUTED);
            g2.setFont(ModernUIComponents.fontBody.deriveFont(12f));
            g2.drawString(grade, barX + (barWidth - fm.stringWidth(grade)) / 2, y + h - 15);
        }
    }

    private void drawPassingRateDial(Graphics2D g2, int x, int y, int w, int h, double passRate) {
        // Draw Container Background
        g2.setColor(ModernUIComponents.COLOR_CARD);
        g2.fill(new RoundRectangle2D.Double(x, y, w, h, 14, 14));

        // Draw Title
        g2.setColor(ModernUIComponents.COLOR_TEXT);
        g2.setFont(ModernUIComponents.fontHeader);
        g2.drawString("Passing Summary", x + 20, y + 25);

        // Circular dial parameters
        int size = Math.min(w - 40, h - 70);
        int dialX = x + (w - size) / 2;
        int dialY = y + 45 + (h - 70 - size) / 2;

        // Draw background gray track
        g2.setColor(ModernUIComponents.COLOR_BORDER);
        g2.setStroke(new BasicStroke(12f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g2.draw(new Arc2D.Double(dialX + 6, dialY + 6, size - 12, size - 12, -30, 240, Arc2D.OPEN));

        // Draw percentage active arc
        double angleSpan = 240.0 * (passRate / 100.0);
        Color arcColor = passRate >= 70 ? ModernUIComponents.COLOR_SUCCESS :
                         passRate >= 50 ? ModernUIComponents.COLOR_WARNING : ModernUIComponents.COLOR_DANGER;

        g2.setColor(arcColor);
        g2.draw(new Arc2D.Double(dialX + 6, dialY + 6, size - 12, size - 12, 210, -angleSpan, Arc2D.OPEN));

        // Text inside Dial
        g2.setColor(ModernUIComponents.COLOR_TEXT);
        g2.setFont(ModernUIComponents.fontTitle.deriveFont(20f));
        String percentText = String.format("%.0f%%", passRate);
        FontMetrics fm = g2.getFontMetrics();
        g2.drawString(percentText, dialX + (size - fm.stringWidth(percentText)) / 2, dialY + size / 2 + 5);

        // Subtext "Passed"
        g2.setColor(ModernUIComponents.COLOR_TEXT_MUTED);
        g2.setFont(ModernUIComponents.fontBody.deriveFont(10f));
        String label = "PASS RATE";
        FontMetrics fmSub = g2.getFontMetrics();
        g2.drawString(label, dialX + (size - fmSub.stringWidth(label)) / 2, dialY + size / 2 + 20);
    }
}
