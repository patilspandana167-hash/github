import java.io.Serializable;

public class Student implements Serializable {
    private static final long serialVersionUID = 1L;

    private String id;
    private String name;
    private double homeworkScore;
    private double quizScore;
    private double examScore;

    // Default weightages: 20% HW, 30% Quiz, 50% Exam
    private static final double HW_WEIGHT = 0.20;
    private static final double QUIZ_WEIGHT = 0.30;
    private static final double EXAM_WEIGHT = 0.50;

    public Student(String id, String name, double homeworkScore, double quizScore, double examScore) {
        this.id = id;
        this.name = name;
        this.homeworkScore = Math.clamp(homeworkScore, 0.0, 100.0);
        this.quizScore = Math.clamp(quizScore, 0.0, 100.0);
        this.examScore = Math.clamp(examScore, 0.0, 100.0);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getHomeworkScore() {
        return homeworkScore;
    }

    public void setHomeworkScore(double homeworkScore) {
        this.homeworkScore = Math.clamp(homeworkScore, 0.0, 100.0);
    }

    public double getQuizScore() {
        return quizScore;
    }

    public void setQuizScore(double quizScore) {
        this.quizScore = Math.clamp(quizScore, 0.0, 100.0);
    }

    public double getExamScore() {
        return examScore;
    }

    public void setExamScore(double examScore) {
        this.examScore = Math.clamp(examScore, 0.0, 100.0);
    }

    public double getFinalScore() {
        return (homeworkScore * HW_WEIGHT) + (quizScore * QUIZ_WEIGHT) + (examScore * EXAM_WEIGHT);
    }

    public String getLetterGrade() {
        double score = getFinalScore();
        if (score >= 90.0) return "A";
        if (score >= 80.0) return "B";
        if (score >= 70.0) return "C";
        if (score >= 60.0) return "D";
        return "F";
    }

    public double getGPA() {
        double score = getFinalScore();
        if (score >= 90.0) return 4.0;
        if (score >= 80.0) return 3.0;
        if (score >= 70.0) return 2.0;
        if (score >= 60.0) return 1.0;
        return 0.0;
    }

    @Override
    public String toString() {
        return String.format("%s,%s,%.2f,%.2f,%.2f", 
            escapeCSV(id), escapeCSV(name), homeworkScore, quizScore, examScore);
    }

    public static Student fromCSV(String csvLine) {
        String[] parts = csvLine.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
        if (parts.length < 5) return null;
        
        String id = unescapeCSV(parts[0]);
        String name = unescapeCSV(parts[1]);
        double hw = Double.parseDouble(parts[2]);
        double quiz = Double.parseDouble(parts[3]);
        double exam = Double.parseDouble(parts[4]);
        
        return new Student(id, name, hw, quiz, exam);
    }

    private static String escapeCSV(String value) {
        if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
            return "\"" + value.replace("\"", "\"\"") + "\"";
        }
        return value;
    }

    private static String unescapeCSV(String value) {
        if (value.startsWith("\"") && value.endsWith("\"")) {
            value = value.substring(1, value.length() - 1);
            value = value.replace("\"\"", "\"");
        }
        return value;
    }
}
