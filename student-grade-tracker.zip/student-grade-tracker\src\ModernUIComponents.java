import javax.swing.*;
import javax.swing.border.AbstractBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;

public class ModernUIComponents {

    // Global Theme Colors
    public static final Color COLOR_BG = new Color(30, 30, 46);         // #1E1E2E
    public static final Color COLOR_CARD = new Color(37, 37, 56);       // #252538
    public static final Color COLOR_TEXT = new Color(205, 214, 244);    // #CDD6F4
    public static final Color COLOR_TEXT_MUTED = new Color(147, 153, 178); // #9399B2
    public static final Color COLOR_ACCENT = new Color(203, 166, 247);  // #CBA6F7 (Violet)
    public static final Color COLOR_ACCENT_HOVER = new Color(221, 199, 252); 
    public static final Color COLOR_SUCCESS = new Color(166, 227, 161); // #A6E3A1 (Green)
    public static final Color COLOR_WARNING = new Color(249, 226, 175); // #F9E2AF (Yellow)
    public static final Color COLOR_DANGER = new Color(243, 139, 168);  // #F38BA8 (Red)
    public static final Color COLOR_BORDER = new Color(49, 49, 74);     // #31314A

    public static Font fontTitle = new Font("Outfit", Font.BOLD, 22);
    public static Font fontHeader = new Font("Outfit", Font.BOLD, 15);
    public static Font fontBody = new Font("Outfit", Font.PLAIN, 13);
    public static Font fontBold = new Font("Outfit", Font.BOLD, 13);

    // Dynamic font loader (fallback to SansSerif if Outfit isn't loaded)
    static {
        try {
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            // We can register custom fonts here if needed, otherwise standard logical fonts are okay.
            // SansSerif will map nicely to System defaults.
            Font[] fonts = ge.getAllFonts();
            boolean hasOutfit = false;
            for (Font f : fonts) {
                if (f.getName().equalsIgnoreCase("Outfit")) {
                    hasOutfit = true;
                    break;
                }
            }
            if (!hasOutfit) {
                fontTitle = new Font("SansSerif", Font.BOLD, 22);
                fontHeader = new Font("SansSerif", Font.BOLD, 15);
                fontBody = new Font("SansSerif", Font.PLAIN, 13);
                fontBold = new Font("SansSerif", Font.BOLD, 13);
            }
        } catch (Exception e) {
            // Fallback safely
        }
    }

    public static class RoundedBorder extends AbstractBorder {
        private final Color color;
        private final int radius;
        private final int thickness;

        public RoundedBorder(Color color, int radius, int thickness) {
            this.color = color;
            this.radius = radius;
            this.thickness = thickness;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            g2.setStroke(new BasicStroke(thickness));
            g2.drawRoundRect(x + thickness / 2, y + thickness / 2, 
                             width - thickness, height - thickness, radius, radius);
            g2.dispose();
        }

        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(radius / 2 + thickness, radius / 2 + thickness, 
                              radius / 2 + thickness, radius / 2 + thickness);
        }

        @Override
        public Insets getBorderInsets(Component c, Insets insets) {
            insets.left = insets.right = radius / 2 + thickness;
            insets.top = insets.bottom = radius / 2 + thickness;
            return insets;
        }
    }

    public static class ModernButton extends JButton {
        private boolean hovered = false;
        private final Color normalBg;
        private final Color hoverBg;
        private final Color textColor;
        private final int radius;

        public ModernButton(String text, Color normalBg, Color hoverBg, Color textColor, int radius) {
            super(text);
            this.normalBg = normalBg;
            this.hoverBg = hoverBg;
            this.textColor = textColor;
            this.radius = radius;
            setContentAreaFilled(false);
            setFocusPainted(false);
            setBorderPainted(false);
            setForeground(textColor);
            setFont(fontBold);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    hovered = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hovered = false;
                    repaint();
                }
            });
        }

        public ModernButton(String text) {
            this(text, COLOR_ACCENT, COLOR_ACCENT_HOVER, COLOR_BG, 12);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            if (getModel().isPressed()) {
                g2.setColor(normalBg.darker());
            } else if (hovered) {
                g2.setColor(hoverBg);
            } else {
                g2.setColor(normalBg);
            }
            
            g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), radius, radius));
            
            // Draw text
            FontMetrics metrics = g2.getFontMetrics(getFont());
            int x = (getWidth() - metrics.stringWidth(getText())) / 2;
            int y = ((getHeight() - metrics.getHeight()) / 2) + metrics.getAscent();
            g2.setFont(getFont());
            g2.setColor(getForeground());
            g2.drawString(getText(), x, y);
            
            g2.dispose();
            super.paintComponent(g);
        }
    }

    public static class ModernTextField extends JTextField implements FocusListener {
        private final String placeholder;
        private boolean isShowingPlaceholder;
        private final Color focusColor = COLOR_ACCENT;
        private final Color normalColor = COLOR_BORDER;
        private Color currentBorderColor = normalColor;

        public ModernTextField(String placeholder, int columns) {
            super(columns);
            this.placeholder = placeholder;
            this.isShowingPlaceholder = true;
            
            setOpaque(false);
            setBackground(COLOR_CARD);
            setForeground(COLOR_TEXT_MUTED);
            setText(placeholder);
            setFont(fontBody);
            setCaretColor(COLOR_TEXT);
            setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
            addFocusListener(this);
        }

        public String getCleanText() {
            return isShowingPlaceholder ? "" : getText().trim();
        }

        public void setCleanText(String text) {
            if (text == null || text.trim().isEmpty()) {
                isShowingPlaceholder = true;
                setText(placeholder);
                setForeground(COLOR_TEXT_MUTED);
            } else {
                isShowingPlaceholder = false;
                setText(text);
                setForeground(COLOR_TEXT);
            }
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            // Background
            g2.setColor(getBackground());
            g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 10, 10));
            
            // Border
            g2.setColor(currentBorderColor);
            g2.setStroke(new BasicStroke(1.5f));
            g2.draw(new RoundRectangle2D.Double(0.75, 0.75, getWidth() - 1.5, getHeight() - 1.5, 10, 10));
            
            g2.dispose();
            super.paintComponent(g);
        }

        @Override
        public void focusGained(FocusEvent e) {
            if (isShowingPlaceholder) {
                isShowingPlaceholder = false;
                setText("");
                setForeground(COLOR_TEXT);
            }
            currentBorderColor = focusColor;
            repaint();
        }

        @Override
        public void focusLost(FocusEvent e) {
            if (getText().isEmpty()) {
                isShowingPlaceholder = true;
                setText(placeholder);
                setForeground(COLOR_TEXT_MUTED);
            }
            currentBorderColor = normalColor;
            repaint();
        }
    }

    public static class CustomTableRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus,
                                                       int row, int column) {
            Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            c.setFont(fontBody);
            
            // Custom selection and row highlight colors
            if (isSelected) {
                c.setBackground(COLOR_ACCENT.darker().darker());
                c.setForeground(Color.WHITE);
            } else {
                c.setBackground(row % 2 == 0 ? COLOR_BG : COLOR_CARD);
                c.setForeground(COLOR_TEXT);
            }

            // Alignments
            if (column == 0 || column == 6 || column == 7) {
                setHorizontalAlignment(SwingConstants.CENTER);
            } else if (column >= 2 && column <= 5) {
                setHorizontalAlignment(SwingConstants.RIGHT);
            } else {
                setHorizontalAlignment(SwingConstants.LEFT);
            }

            // Beautiful status/grade pills for letter grades
            if (column == 6) {
                String grade = (String) value;
                setHorizontalAlignment(SwingConstants.CENTER);
                
                // Let's create a custom panel inside to draw a modern rounded pill
                JPanel pillPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 4)) {
                    @Override
                    protected void paintComponent(Graphics g) {
                        Graphics2D g2 = (Graphics2D) g.create();
                        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                        
                        Color pillBg;
                        Color pillFg;
                        switch (grade) {
                            case "A":
                                pillBg = new Color(166, 227, 161, 40);
                                pillFg = COLOR_SUCCESS;
                                break;
                            case "B":
                                pillBg = new Color(203, 166, 247, 40);
                                pillFg = COLOR_ACCENT;
                                break;
                            case "C":
                                pillBg = new Color(249, 226, 175, 40);
                                pillFg = COLOR_WARNING;
                                break;
                            case "D":
                                pillBg = new Color(250, 179, 135, 40);
                                pillFg = new Color(250, 179, 135);
                                break;
                            default:
                                pillBg = new Color(243, 139, 168, 40);
                                pillFg = COLOR_DANGER;
                                break;
                        }
                        g2.setColor(pillBg);
                        g2.fillRoundRect(8, 2, getWidth() - 16, getHeight() - 4, 10, 10);
                        
                        g2.setColor(pillFg);
                        g2.setFont(fontBold);
                        FontMetrics fm = g2.getFontMetrics();
                        int x = (getWidth() - fm.stringWidth(grade)) / 2;
                        int y = ((getHeight() - fm.getHeight()) / 2) + fm.getAscent();
                        g2.drawString(grade, x, y);
                        g2.dispose();
                    }
                };
                pillPanel.setBackground(c.getBackground());
                return pillPanel;
            }

            return c;
        }
    }

    public static void styleTable(JTable table) {
        table.setBackground(COLOR_BG);
        table.setGridColor(COLOR_BORDER);
        table.setForeground(COLOR_TEXT);
        table.setSelectionBackground(COLOR_ACCENT.darker());
        table.setSelectionForeground(Color.WHITE);
        table.setRowHeight(32);
        table.setFont(fontBody);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setShowGrid(false);
        table.setShowHorizontalLines(true);
        table.setFillsViewportHeight(true);

        JTableHeader header = table.getTableHeader();
        header.setBackground(COLOR_CARD);
        header.setForeground(COLOR_ACCENT);
        header.setFont(fontHeader);
        header.setPreferredSize(new Dimension(header.getWidth(), 36));
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, COLOR_BORDER));
        
        // Custom renderer for header to keep the design aligned
        header.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int col) {
                JLabel label = (JLabel) super.getTableCellRendererComponent(t, value, isSelected, hasFocus, row, col);
                label.setBackground(COLOR_CARD);
                label.setForeground(COLOR_ACCENT);
                label.setFont(fontHeader);
                label.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
                
                // Alignments
                if (col == 0 || col == 6 || col == 7) {
                    label.setHorizontalAlignment(SwingConstants.CENTER);
                } else if (col >= 2 && col <= 5) {
                    label.setHorizontalAlignment(SwingConstants.RIGHT);
                } else {
                    label.setHorizontalAlignment(SwingConstants.LEFT);
                }
                return label;
            }
        });

        table.setDefaultRenderer(Object.class, new CustomTableRenderer());
        table.setDefaultRenderer(Double.class, new CustomTableRenderer());
        table.setDefaultRenderer(String.class, new CustomTableRenderer());
    }
}
