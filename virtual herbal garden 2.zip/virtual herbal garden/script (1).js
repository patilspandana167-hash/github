// This file imports the herbData from data.js and contains all the application logic.
import { herbData } from './data.js';


// --- EXISTING DATA: Placeholder for Companion Planting Information ---
const companionData = {
    // Companion data uses the herb NAME as the key for easy lookup
    'Basil': { good: ['Tomato', 'Asparagus', 'Chives', 'Chamomile', 'Borage', 'Peppers'], bad: ['Rue', 'Sage', 'Fennel'] },
'Mint': { good: ['Cabbage', 'Tomato', 'Carrots', 'Broccoli', 'Peas'], bad: ['Parsley', 'Fennel', 'Chamomile', 'Lavender'] },
'Lavender': { good: ['Rose', 'Chamomile', 'Yarrow', 'Cabbage', 'Broccoli'], bad: ['Mint', 'Fennel', 'Cilantro'] },
'Rosemary': { good: ['Cabbage', 'Beans', 'Carrots', 'Sage', 'Broccoli'], bad: ['Mint', 'Tomato', 'Fennel'] },
'Thyme': { good: ['Cabbage', 'Eggplant', 'Potatoes', 'Broccoli', 'Strawberries'], bad: ['Marjoram', 'Chives', 'Fennel'] },
'Chamomile': { good: ['Basil', 'Mint', 'Cabbage', 'Onion', 'Cucumber'], bad: ['Fennel'] },
'Parsley': { good: ['Tomato', 'Rose', 'Asparagus', 'Carrots', 'Chives'], bad: ['Mint', 'Lettuce', 'Fennel'] },
'Cilantro': { good: ['Beans', 'Peas', 'Spinach', 'Anise', 'Dill'], bad: ['Fennel', 'Lavender'] },
'Dill': { good: ['Cabbage', 'Lettuce', 'Onion', 'Cucumber', 'Broccoli'], bad: ['Carrot', 'Fennel', 'Tomato', 'Lavender'] },
'Sage': { good: ['Rosemary', 'Cabbage', 'Carrots', 'Strawberry', 'Marjoram'], bad: ['Cucumber', 'Fennel', 'Basil', 'Wormwood'] },
'Oregano': { good: ['Cabbage', 'Broccoli', 'Cucumber', 'Peppers', 'Grapes'], bad: ['Beans', 'Peas', 'Fennel'] },
'Marjoram': { good: ['Carrots', 'Onions', 'Cabbage', 'Sage', 'Thyme'], bad: ['Fennel'] },
'Borage': { good: ['Tomato', 'Strawberry', 'Squash', 'Cabbage', 'Cucumber'], bad: ['Fennel', 'Walnuts'] },
'Lemon Balm': { good: ['Tomato', 'Squash', 'Cabbage family', 'Broccoli'], bad: ['Mint', 'Fennel'] },
'Fennel': { good: ['Dill', 'Lovage', 'Echinacea'], bad: ['Almost everything', 'Tomato', 'Beans', 'Kohlrabi', 'Wormwood', 'Cilantro', 'Basil', 'Sage', 'Mint'] },
'Yarrow': { good: ['Aromatic herbs (boosts oils)', 'Lavender', 'Fruit trees'], bad: ['Fennel'] },
'Motherwort': { good: ['Comfrey', 'Yarrow', 'Peppermint', 'Catnip'], bad: ['Fennel'] },
'St. John\'s Wort': { good: ['Yarrow', 'Valerian', 'Mullein'], bad: ['Fennel'] },
'Calendula': { good: ['Tomato', 'Cucumber', 'Asparagus', 'Beans', 'Peppers'], bad: ['Fennel'] },
'Bay Leaf': { good: ['Rosemary', 'Thyme', 'Sage', 'Lavender'], bad: ['Fennel'] },
'Echinacea': { good: ['Rosemary', 'Sage', 'Yarrow', 'Mullein', 'Fennel'], bad: ['Mint'] },
'Ginseng': { good: ['Hardwood trees (shade)', 'Comfrey', 'Slippery Elm'], bad: ['Walnut trees', 'Sun-loving plants'] },
'Valerian': { good: ['Comfrey', 'Lovage', 'St. John\'s Wort'], bad: ['Fennel'] },
'Milk Thistle': { good: ['Nettle', 'Yarrow', 'Dandelion'], bad: ['Fennel'] },
'Ginkgo Biloba': { good: ['Shade-tolerant groundcover', 'Hostas', 'Ferns'], bad: ['Sun-loving annuals', 'Walnut trees'] },
'Saffron': { good: ['Rosemary', 'Thyme', 'Calendula', 'Lavender'], bad: ['Beans', 'Peas', 'Fennel'] },
'Anise': { good: ['Cilantro', 'Beans', 'Cabbage'], bad: ['Carrots', 'Fennel', 'Wormwood'] },
'Lovage': { good: ['Beans', 'Cabbage', 'Fennel', 'Potatoes'], bad: ['Rhubarb'] },
'Hyssop': { good: ['Cabbage', 'Grapes', 'Turnips', 'Cauliflower'], bad: ['Radish', 'Fennel'] },
'Comfrey': { good: ['Fruit trees (general)', 'Potatoes', 'Tomatoes', 'Ginseng'], bad: ['Fennel'] },
'Wormwood': { good: ['Carrots', 'Onions', 'Leeks (as deterrent)'], bad: ['Fennel', 'Sage', 'Anise', 'Beans', 'Peas'] },
'Costmary': { good: ['Mint', 'Lemon Balm', 'Peppermint'], bad: ['Fennel'] },
'Elecampane': { good: ['Mullein', 'Hyssop', 'Comfrey', 'Marshmallow'], bad: ['Fennel'] },
'Coltsfoot': { good: ['Nettle', 'Plantain', 'Self-Heal'], bad: ['Fennel'] },
'Horehound': { good: ['Tomato', 'Peppers', 'Eggplant'], bad: ['Fennel'] },
'Mullein': { good: ['Echinacea', 'Yarrow', 'Elecampane', 'St. John\'s Wort'], bad: ['Fennel'] },
'Slippery Elm': { good: ['Shade-tolerant herbs', 'Wild ginger', 'Ginseng'], bad: ['Walnut trees'] },
'Licorice Root': { good: ['Grapes', 'Peas', 'Beans', 'Vetch'], bad: ['Fennel'] },
'Red Clover': { good: ['Grasses', 'Wheat', 'Cabbage', 'Broccoli'], bad: ['Fennel'] },
'Nettle': { good: ['Comfrey', 'Peppermint', 'Most vegetables', 'Fruit trees'], bad: ['Fennel'] },
'Plantain': { good: ['Calendula', 'Yarrow', 'Self-Heal', 'Coltsfoot'], bad: ['Fennel'] },
'Shepherd\'s Purse': { good: ['Calendula', 'Plantain', 'Chickweed'], bad: ['Fennel'] },
'Sweet Cicely': { good: ['Rhubarb', 'Gooseberries', 'Fruit bushes'], bad: ['Fennel'] },
'Self-Heal': { good: ['Plantain', 'Red Clover', 'Yarrow', 'Coltsfoot'], bad: ['Fennel'] },
'Calamint': { good: ['Roses', 'Peppers', 'Cabbage', 'Beets'], bad: ['Fennel'] },
'Epazote': { good: ['Beans', 'Corn', 'Squash', 'Peas'], bad: ['Fennel', 'Wormwood'] },
'Fenugreek': { good: ['Peas', 'Beans', 'Corn', 'Potatoes'], bad: ['Fennel'] },
'Gotu Kola': { good: ['Lemon Balm', 'Mint', 'Moisture-loving plants'], bad: ['Drought-loving herbs (Rosemary, Thyme)'] },
'Ashwagandha': { good: ['Tomatoes', 'Peppers', 'Holy Basil'], bad: ['Fennel'] },
'Tulsi': { good: ['Tomato', 'Peppers', 'Marigolds', 'Ashwagandha'], bad: ['Fennel', 'Sage'] },
'Neem':{good:['Tulsi','Marigold','aloevera','coconut','mango'],bad:['maize','cucumber','wheat']},
};

// --- SYMPTOM SYNONYMS & RELATED TERMS (Expanded for Semantic Search) ---
const symptomSynonyms = {
    'pain': ['ache', 'hurt', 'sore', 'discomfort', 'painful', 'aching', 'chronic pain', 'body pain', 'hurting'],
    'inflammation': ['swelling', 'inflamed', 'inflammatory', 'swollen', 'edema', 'puffiness'],
    'fever': ['temperature', 'hot', 'pyrexia', 'febrile', 'chills', 'bukhar', 'feverish'],
    'cough': ['coughing', 'bronchitis', 'congestion', 'phlegm', 'respiratory', 'chest', 'khansi', 'throat', 'mucus'],
    'cold': ['flu', 'influenza', 'common cold', 'viral', 'virus', 'infection', 'sardi', 'runny nose', 'sneezing', 'sniffles'],
    'anxiety': ['stress', 'nervous', 'worry', 'tension', 'anxious', 'panic', 'calm', 'mental', 'worried', 'stressed', 'racing', 'restless', 'uneasy'],
    'sleep': ['insomnia', 'sleepless', 'rest', 'sleeping', 'sedative', 'neend', 'cant sleep', 'trouble sleeping', 'sleepy', 'awake', 'tired'],
    'digestion': ['stomach', 'digestive', 'indigestion', 'bloating', 'gas', 'gut', 'nausea', 'acid', 'ulcer', 'constipation', 'loose motion', 'acidity', 'belly', 'tummy', 'gastric'],
    'headache': ['migraine', 'head pain', 'cephalalgia', 'tension', 'sar dard', 'head', 'throbbing'],
    'skin': ['rash', 'eczema', 'dermatitis', 'acne', 'psoriasis', 'infection', 'wound', 'cut', 'scrape', 'pimple', 'itchy', 'itching', 'dry skin', 'oily'],
    'immune': ['immunity', 'defense', 'prevention', 'resistance', 'system', 'weakness', 'sick', 'ill', 'getting sick'],
    'energy': ['fatigue', 'tired', 'exhaustion', 'stamina', 'vitality', 'burnout', 'adrenal', 'weak', 'low energy', 'exhausted', 'drained', 'lethargic'],
    'heart': ['cardiac', 'cardiovascular', 'circulation', 'blood pressure', 'cholesterol', 'hypertension', 'bp', 'palpitations', 'racing heart'],
    'liver': ['hepatic', 'detox', 'detoxification', 'cleanse', 'toxins', 'jaundice'],
    'kidney': ['renal', 'urinary', 'bladder', 'uti', 'diuretic', 'stone', 'urine'],
    'joint': ['arthritis', 'arthritic', 'rheumatism', 'osteoarthritis', 'stiffness', 'knee', 'back', 'joints', 'stiff'],
    'muscle': ['muscular', 'cramp', 'spasm', 'strain', 'ache', 'muscles', 'sore muscles'],
    'respiratory': ['breathing', 'lungs', 'chest', 'bronchial', 'sinus', 'asthma', 'breath', 'breathe', 'wheezing'],
    'appetite': ['hunger', 'eating', 'loss of appetite', 'hungry', 'not eating'],
    'weight': ['metabolism', 'metabolic', 'obesity', 'fat', 'slimming', 'weight loss', 'overweight'],
    'infection': ['bacterial', 'antiseptic', 'antiviral', 'fungal', 'antibiotic', 'infected'],
    'women': ['pms', 'menopause', 'hormone', 'cycle', 'period', 'menstrual', 'cramps', 'hormonal'],
    'relax': ['relaxation', 'calm', 'calming', 'unwind', 'peace', 'peaceful', 'soothe', 'soothing'],
    'focus': ['concentration', 'memory', 'brain', 'cognitive', 'thinking', 'mental clarity', 'foggy'],
    'allergy': ['allergies', 'allergic', 'hay fever', 'histamine', 'sneezing', 'itchy eyes'],
    'depression': ['depressed', 'sad', 'low mood', 'unhappy', 'mood', 'melancholy']
};

// Expand synonyms to work both ways
Object.keys(symptomSynonyms).forEach(key => {
    symptomSynonyms[key].forEach(synonym => {
        if (!symptomSynonyms[synonym]) {
            symptomSynonyms[synonym] = [key];
        } else if (!symptomSynonyms[synonym].includes(key)) {
            symptomSynonyms[synonym].push(key);
        }
    });
});

// --- NEW DATA: Complete Herbal Remedies (30 Items) ---
const remedyData = [
  {
        id: 1, name: 'Ultimate Cold & Flu Tea', ailment: ['Cold', 'Flu', 'Immunity', 'Congestion'], herbs: ['Elderberry', 'Ginger', 'Echinacea', 'Thyme'], description: 'A powerful synergistic blend designed to boost the immune system, shorten the duration of a cold, and relieve congestion and body aches. The combination maximizes antiviral and anti-inflammatory effects.', preparation: 'Steep 1 tsp of each dried herb in a mug of hot water for 10-15 minutes. Add honey and lemon to taste. Drink 3 times daily at the onset of symptoms.', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRagDbsnyNHj3Toqtzq54qVhFT20mbvMKyymg&s'
    },
    {
        id: 2, name: 'Peaceful Sleep Tincture', ailment: ['Insomnia', 'Anxiety', 'Stress'], herbs: ['Valerian Root', 'Chamomile', 'Lavender'], description: 'A deeply relaxing trio that targets the nervous system to promote calm and induce restful sleep. Valerian provides deep sedation, while Chamomile and Lavender relax the mind.', preparation: 'Mix dried herbs and infuse in vodka (or another high-proof spirit) for 6 weeks, shaking daily. Strain and take 1 dropperful (approx. 30 drops) 30 minutes before bed.', image: 'https://www.buybluetea.com/cdn/shop/articles/Blog_Image_07.05.24_2_1.jpg?v=1715148721'
    },
    {
        id: 3, name: 'Digestive Comfort Blend', ailment: ['Indigestion', 'Bloating', 'Nausea'], herbs: ['Peppermint', 'Fennel', 'Ginger'], description: 'A classic blend of carminative herbs that soothe the digestive tract, reduce gas and bloating, and stimulate healthy enzyme production for improved nutrient absorption.', preparation: 'Brew as a simple infusion: use 1.5 tsp of the blend per cup of hot water. Cover while steeping for 5 minutes. Sip slowly after meals to aid digestion.', image: 'https://thumbs.dreamstime.com/b/fresh-herbs-spices-rustic-wooden-table-mint-ginger-ai-generated-fresh-herbs-spices-rustic-wooden-table-348840880.jpg'
    },
    {
        id: 4, name: 'Liver Detox Elixir', ailment: ['Detox', 'Fatigue', 'Skin issues'], herbs: ['Milk Thistle', 'Dandelion Root', 'Turmeric'], description: 'A powerful combination to support liver function, aid detoxification, and reduce inflammation, leading to clearer skin and increased energy.', preparation: 'Decoct 1 tsp of combined roots in 2 cups of water for 20 minutes. Drink 1 cup twice daily for 2 weeks.', image: 'https://oliveoilsfromspain.org/sites/default/files/recetas/olive_detox_vegetal.jpg'
    },
    {
        id: 5, name: 'Joint Pain Ointment', ailment: ['Arthritis', 'Joint Pain', 'Inflammation'], herbs: ['Arnica', 'Devil\'s Claw', 'St. John\'s Wort'], description: 'Topical oil infusion blend for deep penetrating relief of muscular and joint pain. St. John\'s Wort soothes nerve pain, while Arnica and Devil\'s Claw reduce swelling.', preparation: 'Infuse herbs in a carrier oil (e.g., olive oil) for 4 weeks. Strain and mix with beeswax to create a salve. Apply externally to affected joints 2-3 times a day.', image: 'https://t4.ftcdn.net/jpg/06/88/74/39/360_F_688743989_HTjuzj6e4mYdwoS3GSWJsetsKAiZiGsZ.jpg'
    },
    {
        id: 6, name: 'Focus & Memory Booster', ailment: ['Poor Focus', 'Cognitive Decline', 'Stress'], herbs: ['Ginkgo Biloba', 'Bacopa Monnieri', 'Rhodiola'], description: 'Nootropic blend to enhance blood flow to the brain (Ginkgo), improve memory consolidation (Bacopa), and combat mental fatigue from stress (Rhodiola).', preparation: 'Take 500mg capsules of the standardized extract blend daily with breakfast for consistent support.', image: 'https://media.istockphoto.com/id/114450026/photo/ginko-biloba-essential-oil-with-fresh-leaves-beauty-treatment.jpg?s=612x612&w=0&k=20&c=ybeTtxYdx5E9sOHHN1xUZNJzDaeK7hlpQyQDzwnVmo8='
    },
    {
        id: 7, name: 'Allergy Relief Blend', ailment: ['Seasonal Allergies', 'Hay Fever', 'Histamine'], herbs: ['Nettle Leaf', 'Quercetin (from Onion/Apple)', 'Butterbur'], description: 'Acts as a natural antihistamine and anti-inflammatory to stabilize mast cells and reduce the release of histamines, alleviating sneezing and itchy eyes.', preparation: 'Steep a strong infusion of Nettle Leaf. Add a supplement containing Quercetin and Butterbur to your daily regimen during allergy season.', image: 'https://images.squarespace-cdn.com/content/v1/5af5f71c0dbda32cd6252624/21868f61-9ab9-4637-be5a-dd85fc8ac2bc/AdobeStock_109415420+nettle+pesto.jpeg'
    },
    {
        id: 8, name: 'Adrenal Fatigue Support', ailment: ['Burnout', 'Low Energy', 'Chronic Stress'], herbs: ['Ashwagandha', 'Holy Basil', 'Siberian Ginseng'], description: 'An adaptogenic formula to balance cortisol levels, support the adrenal glands, and increase the body\'s resilience to physical and emotional stress.', preparation: 'Take a powdered form (1 tsp) mixed into a smoothie or water twice daily, morning and evening, for at least 3 months.', image: 'https://thumbs.dreamstime.com/b/ashwagandha-powder-wooden-bowl-roots-spoon-ayurveda-medicine-health-care-organic-ingredient-dry-herb-ashwagandha-389509445.jpg'
    },
    {
        id: 9, name: 'Natural Antibiotic Salve', ailment: ['Minor Wounds', 'Infections', 'Scrapes'], herbs: ['Calendula', 'Tea Tree Oil', 'Plantain'], description: 'A protective, soothing balm with antibacterial and antifungal properties. Excellent for accelerating wound healing and preventing minor topical infections.', preparation: 'Mix Plantain and Calendula infused oil with Tea Tree essential oil and beeswax. Apply externally to clean wounds and cover if necessary.', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQj6pBS0ouMbcVc0Kq81CYv5xIFdcyPJmDtHh6f-iwmpgQ-AgEJ9jPb8wr0F-tgsZKke4I&usqp=CAU'
    },
    {
        id: 10, name: 'Heart Health Tonic', ailment: ['High Blood Pressure', 'Circulation', 'Cholesterol'], herbs: ['Hawthorn Berry', 'Garlic', 'Oats'], description: 'Works to strengthen the heart muscle (Hawthorn), lower cholesterol (Oats), and improve circulation while moderately reducing blood pressure (Garlic).', preparation: 'Take a liquid extract blend (tincture) 1 tsp, three times daily. Consult a doctor if taking prescription blood pressure medication.', image: 'https://images.moneycontrol.com/static-mcnews/2024/08/20240815115020_Health-benefits-of-Chamomile-and-Lavender-Tea.jpg'
    },
    {
        id: 11, name: 'Womens Hormonal Balance', ailment: ['PMS', 'Menopausal Symptoms', 'Irregular Cycle'], herbs: ['Chaste Tree Berry (Vitex)', 'Red Raspberry Leaf', 'Dong Quai'], description: 'A classic blend to regulate female hormones, ease monthly discomfort, and nourish the reproductive system. Primarily supports progesterone balance.', preparation: 'Take a decoction of Red Raspberry Leaf daily. Use a standardized tincture of Vitex and Dong Quai, adjusting dose based on cycle phase.', image: 'https://nutratea.co.uk/wp-content/uploads/2024/10/shutterstock_2475334459-scaled-800x533.jpg'
    },
    {
        id: 12, name: 'Headache & Migraine Relief', ailment: ['Headache', 'Migraine', 'Tension'], herbs: ['Feverfew', 'Willow Bark', 'Peppermint Oil'], description: 'Feverfew prevents vasoconstriction, Willow Bark provides natural pain relief (salicin), and Peppermint oil applied topically relaxes tension headaches.', preparation: 'Chew a few fresh Feverfew leaves daily for prevention. Take a tincture of Willow Bark at the onset of pain. Apply Peppermint oil to temples.', image: 'https://www.shutterstock.com/image-photo/basil-essential-oil-fresh-leaves-600nw-2210214733.jpg'
    },
    {
        id: 13, name: 'Respiratory Congestion Steamer', ailment: ['Cough', 'Bronchitis', 'Sinusitis'], herbs: ['Eucalyptus', 'Mullein', 'Horehound'], description: 'A decongestant and expectorant blend. Eucalyptus opens airways, Mullein soothes bronchial inflammation, and Horehound helps expel mucus.', preparation: 'Add a few drops of Eucalyptus oil to a hot steam bath (or a bowl of hot water). Drink Mullein/Horehound tea 2-3 times daily.', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR2GrPdlQ0yED53GM4EOUxLN-h72mZzOhDWolf_D8EDBI6r7OLrrOlPLYMxT04-2f5MEuM&usqp=CAU'
    },
    {
        id: 14, name: 'Blood Sugar Balancer', ailment: ['Type 2 Support', 'Insulin Sensitivity'], herbs: ['Cinnamon', 'Gymnema Sylvestre', 'Fenugreek'], description: 'A combination of herbs shown to improve insulin sensitivity and slow down the absorption of glucose after a meal, helping to stabilize blood sugar.', preparation: 'Take a capsule form of the combined powdered herbs with each meal. Incorporate Cinnamon generously into the diet.', image: 'https://static.toiimg.com/thumb/imgsize-68820,msid-87490891/87490891.jpg?width=500&resizemode=4'
    },
    {
        id: 15, name: 'Kidney & Urinary Tract Flush', ailment: ['UTI', 'Kidney Stones', 'Fluid Retention'], herbs: ['Uva Ursi', 'Corn Silk', 'Marshmallow Root'], description: 'A diuretic and demulcent blend that promotes urine flow (Uva Ursi), soothes irritated tissues (Marshmallow), and flushes the urinary tract.', preparation: 'Brew a weak infusion of Uva Ursi (tannins make it bitter) and combine with a strong Marshmallow and Corn Silk tea. Drink throughout the day.', image: 'https://images.getrecipekit.com/20241210234412-zesty-20green-20detox-20juice.jpg?aspect_ratio=4:3&quality=90&'
    },
    {
        id: 16, name: 'Anti-Acne Face Toner', ailment: ['Acne', 'Oily Skin', 'Inflammation'], herbs: ['Witch Hazel', 'Green Tea', 'Lavender'], description: 'Acts as an astringent (Witch Hazel) to tighten pores, an antioxidant (Green Tea) to reduce free radical damage, and an anti-inflammatory (Lavender).', preparation: 'Brew a strong Green Tea infusion, cool, then mix with Witch Hazel hydrosol and a few drops of Lavender essential oil. Apply to clean face twice daily.', image: 'https://thumbs.dreamstime.com/b/aloe-vera-gel-leaves-natural-skincare-generative-ai-aloe-vera-gel-glass-bottle-fresh-aloe-vera-leaves-natural-beauty-346731590.jpg'
    },
    {
        id: 17, name: 'Stress & Anxiety Capsule', ailment: ['General Anxiety', 'Nervous Tension', 'Worry'], herbs: ['Kava Kava', 'Passionflower', 'Lemon Balm'], description: 'Provides immediate relief from nervous tension without heavy sedation. Kava Kava calms the central nervous system, and the others soothe anxious thoughts.', preparation: 'Take a standardized capsule or extract blend as needed for acute anxiety. Not for long-term daily use without professional guidance.', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRhOLc0-yTaawrEaQ-y7cFNbj8TySjNucAcSg&s'
    },
    {
        id: 18, name: 'Immune Boosting Fire Cider', ailment: ['Prevention', 'Circulation', 'Aches'], herbs: ['Horseradish', 'Garlic', 'Cayenne Pepper', 'Ginger'], description: 'A traditional folk tonic to kickstart the immune system and circulation. It warms the body and provides potent anti-microbial support.', preparation: 'Chop and combine all ingredients in apple cider vinegar. Macerate for 4-6 weeks. Strain and take 1 Tbsp daily as a preventative or 3-4 Tbsp daily when sick.', image: 'https://www.shutterstock.com/image-photo/amber-glass-bottle-fire-cider-260nw-2529194717.jpg'
    },
    {
        id: 19, name: 'Oral Health Swish', ailment: ['Gingivitis', 'Bad Breath', 'Sore Throat'], herbs: ['Myrrh', 'Calendula', 'Tea Tree Oil'], description: 'A powerful antiseptic mouthwash. Myrrh and Tea Tree fight bacteria and fungi, while Calendula soothes gum inflammation and sore throats.', preparation: 'Mix a tincture of Myrrh and Calendula with warm water and 1 drop of Tea Tree oil. Swish in mouth for 30 seconds and gargle, then spit. Do not swallow.', image: 'https://newsnetwork.mayoclinic.org/n7-mcnn/7bcc9724adf7b803/uploads/2019/05/shutterstock_112640333_Fotor-16x9.jpg'
    },
    {
        id: 20, name: 'Natural Laxative Formula', ailment: ['Constipation', 'Sluggish Bowel'], herbs: ['Senna Leaf', 'Ginger', 'Licorice Root'], description: 'Senna provides the laxative action. Ginger and Licorice are added to reduce cramping and soothe the gut lining that Senna can irritate.', preparation: 'Steep a very short infusion (3-5 minutes) of the blend. Use only as needed for acute constipation. Do not use for more than one week.', image: 'https://media.istockphoto.com/id/1332219901/photo/tea-and-stems-of-licorice-glycyrrhiza-glabra.jpg?s=612x612&w=0&k=20&c=E67IzNQA7YnfmbdximOhUstFa7bqtlr4SJiA4U6rMgo='
    },
    {
        id: 21, name: 'Eczema & Psoriasis Balm', ailment: ['Dry Skin', 'Eczema', 'Psoriasis'], herbs: ['Chickweed', 'Oatmeal', 'Nettle Leaf'], description: 'A soothing topical formula for itchy, inflamed, and irritated skin. Chickweed and Oatmeal provide immediate itch relief and hydration.', preparation: 'Mix a strong Nettle Leaf infusion with finely ground Oatmeal. Use a Chickweed-infused oil as a base for a thick cream. Apply 3-4 times daily.', image: 'https://i.etsystatic.com/5775934/r/il/356c04/5214803208/il_fullxfull.5214803208_1y4c.jpg'
    },
    {
        id: 22, name: 'Weight Management Support', ailment: ['Metabolism', 'Appetite Control'], herbs: ['Green Tea', 'Garcinia Cambogia', 'Cayenne Pepper'], description: 'Boosts metabolism and fat oxidation (Green Tea/Cayenne) and may help reduce appetite (Garcinia). Must be combined with diet and exercise.', preparation: 'Take as a standardized capsule blend 30 minutes before meals. Drink Green Tea throughout the day.', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXEipJCzkG-S9UfzREd0myw375gJVeMNuNexTBBwQcxec9V3ok9zVVB5BxCpUuorwMWWw&usqp=CAU'
    },
    {
        id: 23, name: 'Sore Muscle Soak', ailment: ['Muscle Aches', 'Tension', 'Cramps'], herbs: ['Epsom Salt', 'Rosemary', 'Lavender'], description: 'A bath soak to relax tense muscles and soothe aches. Rosemary increases circulation, and Lavender promotes overall relaxation.', preparation: 'Add 2 cups of Epsom Salt, a handful of dried Rosemary, and 10 drops of Lavender essential oil to a hot bath. Soak for 20 minutes.', image: 'https://sleep-rituals.com/cdn/shop/articles/bath-salts--your-guide-on-how-and-why-to-use-them.jpg?crop=center&height=1200&v=1738740378&width=1200'
    },
    {
        id: 24, name: 'Wound Disinfectant Spray', ailment: ['Cuts', 'Scratches', 'First Aid'], herbs: ['Goldenseal', 'Yarrow', 'Aloe Vera'], description: 'An antiseptic and styptic blend. Goldenseal and Yarrow cleanse and stop minor bleeding, while Aloe Vera soothes the tissue.', preparation: 'Use a strong tincture of Goldenseal and Yarrow mixed with Aloe Vera gel and boiled, cooled water in a spray bottle. Spray on minor wounds 1-2 times daily.', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQDmtG4cm7KBV7tr1dBTiLytLTg6eSWXt4W9JhQFvfyugtHJUZf4BUt9q-sGX_E2oHNo5k&usqp=CAU'
    },
    {
        id: 25, name: 'Men\'s Vitality Tonic', ailment: ['Low Libido', 'Energy', 'Stamina'], herbs: ['Tribulus', 'Maca Root', 'Nettle Root'], description: 'A blend to support healthy testosterone levels (Tribulus), energy (Maca), and prostate health (Nettle Root) for overall male vitality.', preparation: 'Take the powdered blend (1 tsp) mixed with juice or water daily, preferably in the morning. Consistent use over weeks is required for effect.', image: 'https://images.hollandandbarrettimages.co.uk/health-hub/2021/m06/nettle-tea-148760534.jpg'
    },
    {
        id: 26, name: 'Eye Strain Compress', ailment: ['Tired Eyes', 'Puffiness', 'Inflammation'], herbs: ['Eyebright', 'Chamomile', 'Fennel'], description: 'A gentle compress to soothe eye strain, reduce inflammation, and alleviate puffiness. Eyebright is specifically for ocular health.', preparation: 'Steep a cool infusion of the herbs. Dip cotton pads in the liquid, gently squeeze, and place over closed eyes for 10 minutes, 2-3 times per day.', image: 'https://fyneherbs.co.uk/cdn/shop/articles/CHV_MED_SS1422053186_1.png?v=1716456245'
    },
    {
        id: 27, name: 'Gastroesophageal Reflux Tea', ailment: ['Heartburn', 'Acid Reflux', 'Stomach Ulcers'], herbs: ['Slippery Elm Bark', 'Licorice Root', 'Marshmallow Root'], description: 'A demulcent blend that coats and soothes the inflamed lining of the esophagus and stomach, reducing acid irritation and promoting healing.', preparation: 'Mix the powdered herbs with cold water and consume immediately to form a thick, protective gel. Take 20 minutes before meals.', image: 'https://www.shutterstock.com/image-photo/glass-cup-licorice-tea-root-260nw-2251398339.jpg'
    },
    {
        id: 28, name: 'Appetite Stimulant Tonic', ailment: ['Loss of Appetite', 'Convalescence'], herbs: ['Gentian', 'Ginger', 'Orange Peel'], description: 'A bitter tonic (Gentian) to stimulate digestive juices and appetite, combined with aromatic Ginger and Orange Peel to make it more palatable.', preparation: 'Take 1 tsp of the tincture 15 minutes before a meal. The bitterness is key to stimulating digestion, so do not mix with too much sweetener.', image: 'https://www.health.com/thmb/uPqfsNLe99veil_nqVp8mrCJ3V0=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/Health-GettyImages-Cumin-9c2734c466c04e42a77e2a4764763413.jpg'
    },
    {
        id: 29, name: 'Hair and Scalp Rinse', ailment: ['Dandruff', 'Hair Loss', 'Dry Scalp'], herbs: ['Rosemary', 'Nettle Leaf', 'Apple Cider Vinegar'], description: 'A rinse to stimulate blood flow to the scalp (Rosemary), strengthen hair (Nettle), and balance pH to fight dandruff and flakiness.', preparation: 'Steep a strong infusion of Rosemary and Nettle in boiling water, strain. Mix with 1 part Apple Cider Vinegar. Use as a final rinse after shampooing.', image: 'https://i0.wp.com/naturalbeautyworkshop.com/wp-content/uploads/2018/10/How-to-make-Apple-Rosemary-Vinegar-Hair-Rinse-an-herbal-hair-rinse-made-with-just-three-all-natural-ingredients-3.png?fit=800%2C530&ssl=1'
    },
    {
        id: 30, name: 'Detoxifying Lymphatic Tea', ailment: ['Swollen Glands', 'Sluggish Lymph', 'Edema'], herbs: ['Cleavers', 'Red Clover', 'Echinacea'], description: 'A blend of alterative and lymphatic herbs to help cleanse the blood, reduce swelling in the lymph nodes, and gently encourage detoxification.', preparation: 'Brew a simple infusion with 1 tsp of the blend per cup of water. Drink 2 cups daily for 2-4 weeks. Best used in the spring.', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ5udAG8P833MHKMQIrzzM2Y7IlUDkj2T0EwA&s'
    },
];  
     

// --- DISEASE REMEDIES DATABASE: 3 Different Plant Combinations Per Disease ---
const diseaseRemediesDB = {
    'cold': [
        {
            herbs: ['Elderberry', 'Ginger', 'Echinacea'],
            preparation: 'Make a warming tea by steeping 1 tsp each of dried elderberry, fresh ginger slices, and echinacea root in 2 cups of hot water for 15 minutes. Strain and add honey. Drink 3 times daily.',
            usage: 'Drink warm, 3 cups daily at the onset of cold symptoms. Best taken on an empty stomach for maximum absorption.',
            benefits: 'Elderberry provides powerful antiviral compounds, Ginger warms the body and fights infection, Echinacea boosts white blood cell production to fight the virus faster.',
            precautions: 'Avoid if allergic to elderberry or echinacea. Not recommended for autoimmune conditions. Discontinue if stomach upset occurs.'
        },
        {
            herbs: ['Tulsi', 'Turmeric', 'Black Pepper'],
            preparation: 'Boil 1 cup water with 10 fresh tulsi leaves, 1/2 tsp turmeric powder, and a pinch of black pepper for 5 minutes. Strain and add honey to taste.',
            usage: 'Drink this golden milk twice daily - morning and before bedtime. The black pepper enhances turmeric absorption by 2000%.',
            benefits: 'Tulsi acts as a natural antibiotic, Turmeric reduces inflammation and boosts immunity, Black Pepper enhances absorption and has antimicrobial properties.',
            precautions: 'Avoid excessive turmeric if on blood thinners. Pregnant women should use tulsi moderately. May cause mild heartburn in some individuals.'
        },
        {
            herbs: ['Thyme', 'Licorice Root', 'Peppermint'],
            preparation: 'Combine 1 tsp dried thyme, 1/2 tsp licorice root, and 1 tsp peppermint leaves. Steep in 2 cups boiling water for 10 minutes. Strain well.',
            usage: 'Drink 2-3 cups throughout the day. Gargle with warm tea for sore throat relief. Can be used as steam inhalation for congestion.',
            benefits: 'Thyme has powerful antiseptic properties for respiratory infections, Licorice soothes the throat and reduces coughing, Peppermint opens airways and provides cooling relief.',
            precautions: 'Avoid licorice if you have high blood pressure or heart conditions. Not suitable for pregnant women. Limit use to 2 weeks.'
        }
    ],
    'flu': [
        {
            herbs: ['Elderberry', 'Yarrow', 'Ginger'],
            preparation: 'Simmer 2 tbsp elderberries, 1 tbsp yarrow, and 1 inch fresh ginger in 3 cups water for 20 minutes. Strain and sweeten with raw honey.',
            usage: 'Take 1/2 cup every 3-4 hours during acute flu symptoms. Reduce to 3 times daily as symptoms improve. Rest and stay hydrated.',
            benefits: 'Elderberry shortens flu duration by 3-4 days, Yarrow induces sweating to break fever naturally, Ginger reduces body aches and nausea.',
            precautions: 'Cook elderberries properly - raw berries are toxic. Avoid yarrow if pregnant. May interact with immunosuppressant medications.'
        },
        {
            herbs: ['Echinacea', 'Boneset', 'Peppermint'],
            preparation: 'Mix equal parts dried herbs. Use 1 tbsp per cup of boiling water. Cover and steep for 15 minutes to retain volatile oils.',
            usage: 'Drink every 2 hours at first sign of flu. After 24 hours, reduce to 4 cups daily. Continue for 3 days after symptoms resolve.',
            benefits: 'Echinacea activates immune cells rapidly, Boneset reduces the deep bone aches associated with flu, Peppermint eases headaches and congestion.',
            precautions: 'Boneset can cause nausea in large doses. Not for those with daisy family allergies. Avoid during pregnancy.'
        },
        {
            herbs: ['Tulsi', 'Cinnamon', 'Clove'],
            preparation: 'Boil 1 cup water with 8-10 tulsi leaves, 1 cinnamon stick, and 2 cloves for 10 minutes. Strain and add honey and lemon juice.',
            usage: 'Drink this spiced tea 4 times daily during flu. Best consumed warm. Can add to bath water for body ache relief.',
            benefits: 'Tulsi is called "The Queen of Herbs" for its immune-boosting power, Cinnamon has antiviral properties and regulates blood sugar, Cloves provide pain relief and fight infection.',
            precautions: 'Avoid cloves in large amounts during pregnancy. Cinnamon may lower blood sugar - diabetics should monitor. May cause mouth sensitivity.'
        }
    ],
    'headache': [
        {
            herbs: ['Feverfew', 'Peppermint', 'Lavender'],
            preparation: 'For tea: steep 1 tsp feverfew and peppermint leaves in hot water for 10 minutes. For topical: dilute 2 drops each of peppermint and lavender oil in 1 tsp carrier oil.',
            usage: 'Drink the tea at onset of headache. Apply the oil blend to temples and back of neck. Inhale deeply for aromatherapy benefits.',
            benefits: 'Feverfew prevents blood vessel constriction that causes migraines, Peppermint relaxes tense muscles and improves blood flow, Lavender calms the nervous system and reduces pain.',
            precautions: 'Feverfew may cause mouth ulcers if chewed. Avoid peppermint oil near eyes. Not for children under 6. May increase sensitivity to sunlight.'
        },
        {
            herbs: ['Willow Bark', 'Ginger', 'Chamomile'],
            preparation: 'Decoct 1 tsp willow bark in 2 cups water for 15 minutes. Add 1/2 tsp ginger and 1 tsp chamomile, steep 5 more minutes. Strain.',
            usage: 'Drink 1 cup at onset, repeat after 4 hours if needed. Maximum 3 cups daily. Rest in a dark, quiet room.',
            benefits: 'Willow Bark contains natural salicin (aspirin precursor) for pain relief, Ginger reduces inflammation and nausea, Chamomile relaxes muscles and reduces tension.',
            precautions: 'Avoid if allergic to aspirin or on blood thinners. Not for children under 16. May cause stomach irritation - take with food.'
        },
        {
            herbs: ['Rosemary', 'Basil', 'Lemon Balm'],
            preparation: 'Combine equal parts dried herbs. Steep 1 tbsp in 1 cup boiling water for 8 minutes. Can also use as steam inhalation.',
            usage: 'Drink 2-3 cups daily for chronic headaches. For acute pain, inhale steam from the hot tea. Massage temples with cooled tea.',
            benefits: 'Rosemary improves circulation to the brain and relieves tension, Basil has analgesic compounds that reduce pain, Lemon Balm calms nerves and reduces stress-related headaches.',
            precautions: 'Avoid rosemary in large amounts during pregnancy. May lower blood pressure. Not recommended before surgery due to blood-thinning effects.'
        }
    ],
    'anxiety': [
        {
            herbs: ['Ashwagandha', 'Chamomile', 'Lavender'],
            preparation: 'Take 1/2 tsp ashwagandha powder in warm milk at night. Drink chamomile-lavender tea (1 tsp each) 2-3 times daily.',
            usage: 'Use ashwagandha consistently for 6-8 weeks for best results. Chamomile tea can be used as needed for acute anxiety. Practice deep breathing while drinking.',
            benefits: 'Ashwagandha reduces cortisol levels by up to 30%, Chamomile binds to brain receptors that induce calm, Lavender aromatherapy lowers heart rate and blood pressure.',
            precautions: 'Ashwagandha may interact with thyroid medications. Avoid chamomile if allergic to ragweed. Not for use during pregnancy.'
        },
        {
            herbs: ['Passionflower', 'Lemon Balm', 'Valerian'],
            preparation: 'Mix dried herbs equally. Use 1 tbsp per cup of hot water, steep covered for 15 minutes. Best taken 30 minutes before stressful situations.',
            usage: 'Drink 1-2 cups during the day for general anxiety. Take 1 cup 1 hour before bed if anxiety affects sleep. Limit caffeine intake.',
            benefits: 'Passionflower increases GABA in the brain for calming effect, Lemon Balm reduces nervousness and improves mood, Valerian deeply relaxes the nervous system.',
            precautions: 'May cause drowsiness - do not drive after taking. Avoid with sedative medications. Not for use during pregnancy or breastfeeding.'
        },
        {
            herbs: ['Holy Basil', 'Brahmi', 'Gotu Kola'],
            preparation: 'Make a brain-calming tea with 1 tsp each herb in 2 cups water. Simmer for 10 minutes. Strain and drink warm.',
            usage: 'Drink 1 cup morning and evening. These adaptogens work best with consistent daily use over 4-8 weeks. Combine with meditation.',
            benefits: 'Holy Basil normalizes stress hormones and clears mental fog, Brahmi calms the mind and improves cognitive function, Gotu Kola reduces anxiety and enhances mental clarity.',
            precautions: 'May increase the effects of sedatives. Gotu Kola can cause skin sensitivity. Not recommended for those with liver conditions.'
        }
    ],
    'insomnia': [
        {
            herbs: ['Valerian', 'Hops', 'Passionflower'],
            preparation: 'Combine 1 tsp valerian root, 1/2 tsp hops, and 1 tsp passionflower. Steep in hot water for 15 minutes. Drink 30-60 minutes before bed.',
            usage: 'Take nightly for best results. Create a bedtime ritual - dim lights, avoid screens, drink tea slowly. Consistent sleep schedule is important.',
            benefits: 'Valerian increases GABA for deep sleep, Hops contains natural sedative compounds similar to melatonin, Passionflower reduces the time it takes to fall asleep.',
            precautions: 'May cause morning grogginess initially. Avoid alcohol. Not for pregnant women or children. May interact with sleep medications.'
        },
        {
            herbs: ['Chamomile', 'Lavender', 'Lemon Balm'],
            preparation: 'Blend equal parts dried herbs. Use 2 tsp per cup of hot water. Steep covered for 10 minutes. Add honey if desired.',
            usage: 'Drink 1 cup after dinner and 1 cup 30 minutes before bed. Keep bedroom cool and dark. Avoid this tea with caffeine.',
            benefits: 'Chamomile contains apigenin that binds to sleep receptors, Lavender reduces restlessness and promotes relaxation, Lemon Balm improves sleep quality and reduces nighttime waking.',
            precautions: 'Mild and generally safe. Avoid chamomile if allergic to daisies. May cause allergic reaction in sensitive individuals.'
        },
        {
            herbs: ['Ashwagandha', 'Nutmeg', 'Cardamom'],
            preparation: 'Warm 1 cup milk with 1/2 tsp ashwagandha, a pinch of nutmeg, and 1/4 tsp cardamom. Do not boil. Drink warm before bed.',
            usage: 'Take this "sleep milk" every night 30 minutes before bed. The warm milk enhances absorption and adds natural tryptophan.',
            benefits: 'Ashwagandha reduces stress-induced insomnia, Nutmeg has natural sedative properties used for centuries in Ayurveda, Cardamom aids digestion and prevents nighttime discomfort.',
            precautions: 'Use only a PINCH of nutmeg - large doses are toxic. Avoid ashwagandha with thyroid medications. Not for lactose intolerant individuals.'
        }
    ],
    'digestion': [
        {
            herbs: ['Ginger', 'Fennel', 'Peppermint'],
            preparation: 'Chew a small piece of fresh ginger before meals. Or make tea with 1/2 tsp each herb, steep 10 minutes. Drink warm.',
            usage: 'Drink 1 cup 20 minutes before meals to stimulate digestion. Or drink after meals if experiencing bloating. Chew slowly.',
            benefits: 'Ginger stimulates digestive enzymes and bile production, Fennel relaxes intestinal muscles and expels gas, Peppermint soothes stomach cramps and reduces bloating.',
            precautions: 'Avoid peppermint if you have acid reflux (can worsen it). Fennel may affect estrogen levels. Large amounts of ginger may thin blood.'
        },
        {
            herbs: ['Triphala', 'Cumin', 'Coriander'],
            preparation: 'Mix 1/2 tsp triphala powder with 1/4 tsp each cumin and coriander. Take with warm water before bed or steep as tea.',
            usage: 'Best taken at night for morning regularity. Can also be taken before meals. Start with small dose and increase gradually.',
            benefits: 'Triphala gently cleanses and tones the entire digestive tract, Cumin increases digestive enzyme secretion, Coriander reduces gas and soothes inflammation.',
            precautions: 'Triphala may cause loose stools initially - this is normal. Avoid during pregnancy. Not for those with diarrhea.'
        },
        {
            herbs: ['Chamomile', 'Licorice Root', 'Marshmallow Root'],
            preparation: 'Decoct 1/2 tsp licorice and marshmallow root in 2 cups water for 15 minutes. Add 1 tsp chamomile, steep 5 minutes. Strain.',
            usage: 'Drink 1 cup before meals for acid reflux or after meals for general digestive comfort. Best warm, sipped slowly.',
            benefits: 'Chamomile relaxes digestive muscles and reduces inflammation, Licorice coats and protects the stomach lining, Marshmallow Root soothes irritated mucous membranes.',
            precautions: 'Avoid licorice with high blood pressure or heart conditions. Use DGL (deglycyrrhizinated) licorice for long-term use. May interact with medications.'
        }
    ],
    'stress': [
        {
            herbs: ['Ashwagandha', 'Rhodiola', 'Holy Basil'],
            preparation: 'Take 1/4 tsp each ashwagandha and rhodiola powder in morning with breakfast. Drink holy basil tea in the afternoon.',
            usage: 'Use daily for 8-12 weeks for full adaptogenic benefits. Morning dose provides energy, afternoon tea maintains calm focus.',
            benefits: 'Ashwagandha lowers cortisol and rebuilds adrenal function, Rhodiola increases stress resistance and mental stamina, Holy Basil balances stress hormones and clears brain fog.',
            precautions: 'Rhodiola may cause insomnia if taken late in day. Ashwagandha affects thyroid. Not for pregnant women or those on anxiety medications.'
        },
        {
            herbs: ['Lavender', 'Chamomile', 'Lemon Balm'],
            preparation: 'Blend equal parts dried herbs. Steep 1 tbsp in 1 cup hot water for 8 minutes. Can also add to bath water for aromatherapy.',
            usage: 'Drink 2-3 cups daily during stressful periods. Inhale the steam before drinking. Best combined with regular breaks and deep breathing.',
            benefits: 'Lavender activates the parasympathetic nervous system, Chamomile reduces muscle tension and mental worry, Lemon Balm lifts mood and reduces irritability.',
            precautions: 'May cause drowsiness in sensitive individuals. Avoid driving after drinking multiple cups. Generally very safe for most people.'
        },
        {
            herbs: ['Brahmi', 'Gotu Kola', 'Shankhpushpi'],
            preparation: 'Mix 1/4 tsp each herb powder. Take with warm milk or water twice daily - morning and evening.',
            usage: 'These brain tonics work best with consistent use over 6-8 weeks. Practice stress-reduction techniques alongside herbal support.',
            benefits: 'Brahmi enhances GABA activity for calm focus, Gotu Kola reduces anxiety and improves circulation, Shankhpushpi calms the mind and supports healthy sleep.',
            precautions: 'May enhance effects of sedatives. Start with lower doses. Not recommended during pregnancy. Consult practitioner for long-term use.'
        }
    ],
    'cough': [
        {
            herbs: ['Thyme', 'Mullein', 'Licorice Root'],
            preparation: 'Decoct 1/2 tsp licorice root for 10 minutes. Add 1 tsp thyme and 1 tsp mullein, steep 10 minutes more. Strain through cloth to remove mullein hairs.',
            usage: 'Drink 3-4 cups daily for productive cough. Gargle with warm tea for throat relief. Use honey to soothe irritation.',
            benefits: 'Thyme relaxes bronchial muscles and acts as natural antibiotic, Mullein soothes inflamed respiratory passages, Licorice is a powerful expectorant and throat soother.',
            precautions: 'Filter mullein well - hairs can irritate throat. Avoid licorice with high blood pressure. Limit use to 2 weeks.'
        },
        {
            herbs: ['Tulsi', 'Ginger', 'Honey'],
            preparation: 'Boil 10 tulsi leaves and 1 inch ginger in 1 cup water for 10 minutes. Strain and add 1 tbsp raw honey when cool enough to drink.',
            usage: 'Drink every 3-4 hours for acute cough. Sip slowly and let it coat the throat. Best results when taken warm, not hot.',
            benefits: 'Tulsi has antimicrobial and anti-inflammatory properties, Ginger warms the lungs and helps expel phlegm, Raw Honey coats the throat and has natural antibacterial effects.',
            precautions: 'Do not add honey to boiling liquid - it destroys beneficial enzymes. Avoid honey for children under 1 year. May increase blood sugar.'
        },
        {
            herbs: ['Eucalyptus', 'Peppermint', 'Plantain Leaf'],
            preparation: 'Make steam inhalation with 3-4 drops eucalyptus and peppermint oil in hot water. Brew plantain leaf tea separately to drink.',
            usage: 'Inhale steam for 10-15 minutes, 2-3 times daily. Drink plantain tea 3 cups daily. Cover head with towel during steam.',
            benefits: 'Eucalyptus opens airways and has strong antimicrobial action, Peppermint cools inflammation and relieves congestion, Plantain Leaf soothes irritated membranes and reduces coughing.',
            precautions: 'Do not ingest essential oils. Keep eyes closed during steam. Not for asthmatics without doctor approval. Eucalyptus not for children under 10.'
        }
    ],
    'inflammation': [
        {
            herbs: ['Turmeric', 'Ginger', 'Boswellia'],
            preparation: 'Mix 1/2 tsp turmeric, 1/4 tsp ginger powder, and 1/4 tsp boswellia with warm milk and a pinch of black pepper. Take twice daily.',
            usage: 'Drink morning and evening with food for best absorption. Black pepper increases turmeric absorption by 2000%. Use consistently for 4-6 weeks.',
            benefits: 'Turmeric contains curcumin - a powerful anti-inflammatory equal to some medications, Ginger blocks inflammatory prostaglandins, Boswellia reduces joint inflammation and pain.',
            precautions: 'May thin blood - avoid before surgery. Turmeric can interfere with iron absorption. Not for those with gallbladder issues.'
        },
        {
            herbs: ['Nettle', 'Willow Bark', 'Devil\'s Claw'],
            preparation: 'Decoct 1 tsp willow bark and devils claw for 15 minutes. Add 1 tsp nettle leaf, steep 10 minutes. Strain and drink.',
            usage: 'Drink 2-3 cups daily for chronic inflammation. May take 2-4 weeks to notice significant improvement. Combine with anti-inflammatory diet.',
            benefits: 'Nettle reduces inflammatory cytokines and is rich in minerals, Willow Bark provides natural pain relief without stomach irritation, Devils Claw is especially effective for back and joint pain.',
            precautions: 'Avoid willow bark if allergic to aspirin. Devils claw not for ulcers or pregnancy. May interact with blood thinners and pain medications.'
        },
        {
            herbs: ['Holy Basil', 'Rosemary', 'Green Tea'],
            preparation: 'Blend equal parts. Steep 1 tbsp in hot (not boiling) water for 5 minutes to preserve antioxidants. Drink throughout the day.',
            usage: 'Drink 3-4 cups daily. These herbs provide gentle, long-term anti-inflammatory support. Best combined with exercise and omega-3 rich foods.',
            benefits: 'Holy Basil blocks COX-2 inflammatory enzymes naturally, Rosemary contains rosmarinic acid - a potent anti-inflammatory, Green Tea catechins reduce systemic inflammation.',
            precautions: 'Green tea contains caffeine - limit evening consumption. May affect iron absorption. Holy basil may affect fertility - avoid when trying to conceive.'
        }
    ],
    'joint pain': [
        {
            herbs: ['Turmeric', 'Boswellia', 'Ginger'],
            preparation: 'Take 1/2 tsp turmeric and 1/4 tsp each boswellia and ginger with warm milk and black pepper. Can also make golden paste for daily use.',
            usage: 'Take twice daily with meals. For acute pain, apply turmeric-ginger paste externally to joints. Continue for 8-12 weeks for lasting relief.',
            benefits: 'Turmeric reduces cartilage breakdown and joint inflammation, Boswellia improves joint mobility and reduces stiffness, Ginger blocks pain signals and improves circulation to joints.',
            precautions: 'Blood-thinning effects - consult doctor if on medications. May cause digestive upset in some. Not recommended before surgery.'
        },
        {
            herbs: ['Ashwagandha', 'Guggulu', 'Shallaki'],
            preparation: 'Take 1/4 tsp each herb powder with warm water twice daily. These Ayurvedic herbs work synergistically for joint health.',
            usage: 'Best taken consistently for 3-6 months. Morning and evening doses. Combine with gentle stretching and adequate hydration.',
            benefits: 'Ashwagandha reduces inflammation and rebuilds cartilage, Guggulu purifies tissues and reduces joint swelling, Shallaki (Boswellia) is the premier Ayurvedic joint remedy.',
            precautions: 'Guggulu may interact with thyroid medications. Not for pregnancy. Start with lower doses to assess tolerance.'
        },
        {
            herbs: ['Nettle Leaf', 'Willow Bark', 'Meadowsweet'],
            preparation: 'Decoct 1/2 tsp willow bark for 15 minutes. Add 1 tsp each nettle and meadowsweet, steep 10 minutes. Strain and drink warm.',
            usage: 'Drink 2-3 cups daily for chronic joint pain. Can apply strong tea externally as compress on painful joints.',
            benefits: 'Nettle provides silica for joint repair and reduces uric acid, Willow Bark offers aspirin-like pain relief naturally, Meadowsweet protects the stomach while reducing inflammation.',
            precautions: 'Avoid if allergic to aspirin. Not for children under 16. May interact with blood thinners and NSAIDs.'
        }
    ],
    'immunity': [
        {
            herbs: ['Elderberry', 'Echinacea', 'Astragalus'],
            preparation: 'Simmer 1 tbsp elderberry and 1 tsp astragalus root in 2 cups water for 20 minutes. Add 1 tsp echinacea, steep 10 minutes. Strain and sweeten.',
            usage: 'Take 1/2 cup daily as prevention during cold/flu season. Increase to 3-4 times daily at first sign of illness. Continue for 2 weeks.',
            benefits: 'Elderberry provides antiviral compounds and vitamin C, Echinacea activates immune cells and increases white blood cells, Astragalus builds deep immunity and protects against infections.',
            precautions: 'Cook elderberries - raw berries are toxic. Avoid echinacea with autoimmune conditions. Astragalus not during acute infections.'
        },
        {
            herbs: ['Tulsi', 'Giloy', 'Amla'],
            preparation: 'Boil 1 inch giloy stem and 1 tsp amla powder in 2 cups water for 15 minutes. Add 8-10 tulsi leaves, steep 5 minutes. Strain.',
            usage: 'Drink 1 cup daily for ongoing immune support. Increase during seasonal changes or when feeling run down.',
            benefits: 'Tulsi is called "The Incomparable One" for its immune-boosting power, Giloy enhances macrophage function and fights infections, Amla provides massive vitamin C and antioxidant protection.',
            precautions: 'Giloy may lower blood sugar - diabetics should monitor. May stimulate uterus - avoid during pregnancy. Safe for long-term use.'
        },
        {
            herbs: ['Reishi Mushroom', 'Ashwagandha', 'Ginger'],
            preparation: 'Simmer 1 tsp reishi powder and 1/2 tsp ashwagandha in 2 cups water for 20 minutes. Add fresh ginger slices, steep 5 minutes.',
            usage: 'Drink 1 cup daily for immune modulation. These adaptogens work best with consistent long-term use (3-6 months).',
            benefits: 'Reishi is the "Mushroom of Immortality" - deeply strengthens immunity, Ashwagandha helps body adapt to stress which weakens immunity, Ginger adds antimicrobial power and aids absorption.',
            precautions: 'Reishi may thin blood - avoid before surgery. Ashwagandha affects thyroid. Not recommended during pregnancy or breastfeeding.'
        }
    ],
    'skin': [
        {
            herbs: ['Neem', 'Turmeric', 'Aloe Vera'],
            preparation: 'For paste: Mix 1 tsp neem powder, 1/2 tsp turmeric with fresh aloe vera gel. For tea: steep neem and turmeric in hot water, drink internally.',
            usage: 'Apply paste to affected skin for 20 minutes, rinse. Use 3 times weekly. Drink tea once daily for internal cleansing.',
            benefits: 'Neem is powerfully antibacterial and antifungal for skin infections, Turmeric reduces inflammation and speeds wound healing, Aloe Vera soothes, moisturizes, and promotes skin repair.',
            precautions: 'Turmeric may temporarily stain skin yellow. Patch test first. Neem is bitter - add honey to tea. Avoid neem during pregnancy.'
        },
        {
            herbs: ['Calendula', 'Chamomile', 'Lavender'],
            preparation: 'Make infused oil: fill jar with dried flowers, cover with olive oil, steep 4-6 weeks. Strain and use topically.',
            usage: 'Apply oil to irritated, dry, or inflamed skin 2-3 times daily. Can add to bath water. Excellent for eczema and sensitive skin.',
            benefits: 'Calendula promotes rapid tissue healing and reduces scarring, Chamomile calms irritated and inflamed skin conditions, Lavender has antimicrobial properties and promotes cell regeneration.',
            precautions: 'Patch test before widespread use. Avoid on deep wounds. Chamomile may cause reaction in those allergic to ragweed.'
        },
        {
            herbs: ['Manjistha', 'Sariva', 'Neem'],
            preparation: 'Mix 1/4 tsp each herb powder with water to make paste for external use. Or take 1/4 tsp each with warm water internally.',
            usage: 'Use paste on acne, eczema, or psoriasis. Take internally for 4-8 weeks for blood purification and long-term skin health.',
            benefits: 'Manjistha purifies blood and gives natural glow to skin, Sariva cools the blood and treats chronic skin conditions, Neem clears toxins and fights bacterial skin infections.',
            precautions: 'Internal use should be supervised for long periods. Bitter taste - can mix with honey. Not for pregnancy. May cause initial breakouts as toxins clear.'
        }
    ],
    'fever': [
        {
            herbs: ['Tulsi', 'Ginger', 'Black Pepper'],
            preparation: 'Boil 10 tulsi leaves, 1 inch ginger, and 4-5 black peppercorns in 2 cups water until reduced to 1 cup. Add honey when warm.',
            usage: 'Drink every 4 hours during fever. This induces sweating to break fever naturally. Rest and stay hydrated between doses.',
            benefits: 'Tulsi reduces fever and fights the underlying infection, Ginger warms the body and promotes sweating, Black Pepper has antimicrobial properties and enhances absorption.',
            precautions: 'Do not use to suppress fever in infants - seek medical care. Stay hydrated. If fever exceeds 103°F or lasts more than 3 days, consult doctor.'
        },
        {
            herbs: ['Yarrow', 'Elderflower', 'Peppermint'],
            preparation: 'Mix equal parts dried herbs. Steep 1 tbsp in 1 cup hot water, covered, for 15 minutes. Drink as warm as comfortable.',
            usage: 'Drink 1 cup every 2-3 hours. This classic combination opens pores and induces therapeutic sweating. Keep warm while sweating.',
            benefits: 'Yarrow is a premier fever herb that promotes sweating and cooling, Elderflower supports the immune system while reducing fever, Peppermint adds cooling sensation and relieves headache.',
            precautions: 'This combination is for breaking fever through sweating - keep body warm, not cold. Not for pregnant women. Avoid yarrow with blood thinners.'
        },
        {
            herbs: ['Giloy', 'Neem', 'Turmeric'],
            preparation: 'Boil 1 inch giloy stem and 4-5 neem leaves in 2 cups water for 15 minutes. Add 1/4 tsp turmeric. Strain and drink.',
            usage: 'Drink twice daily for viral fevers. This Ayurvedic combination addresses fever while fighting infection and boosting immunity.',
            benefits: 'Giloy is called "Amrita" (nectar) and is famous for treating chronic fevers, Neem has powerful antipyretic and antimicrobial properties, Turmeric reduces inflammation and supports healing.',
            precautions: 'Very bitter - honey helps. Giloy may lower blood sugar. Not during pregnancy. If fever persists beyond 5 days, seek medical care.'
        }
    ],
    'diabetes': [
        {
            herbs: ['Gymnema', 'Fenugreek', 'Bitter Melon'],
            preparation: 'Take 1/4 tsp gymnema powder, 1/2 tsp soaked fenugreek seeds, and 1/4 cup bitter melon juice. Can be taken separately or combined.',
            usage: 'Take 30 minutes before meals to reduce sugar absorption. Consistent daily use for 3-6 months shows best results. Monitor blood sugar regularly.',
            benefits: 'Gymnema is called "sugar destroyer" - reduces sugar cravings and absorption, Fenugreek slows carbohydrate digestion and improves insulin sensitivity, Bitter Melon contains compounds that act like insulin.',
            precautions: 'MONITOR BLOOD SUGAR CAREFULLY - these herbs are powerful. May need medication adjustment. Not a replacement for prescribed diabetes treatment.'
        },
        {
            herbs: ['Cinnamon', 'Turmeric', 'Amla'],
            preparation: 'Add 1/2 tsp cinnamon and 1/4 tsp turmeric to warm water. Take 1 tsp amla powder or juice separately. Use daily.',
            usage: 'Take cinnamon-turmeric water in the morning. Amla can be taken anytime. Combine with low-glycemic diet and regular exercise.',
            benefits: 'Cinnamon improves insulin sensitivity and lowers fasting blood sugar, Turmeric reduces diabetes-related inflammation and protects organs, Amla supports pancreatic health and reduces complications.',
            precautions: 'Use Ceylon cinnamon for long-term use (not Cassia). May interact with diabetes medications. Regular blood sugar monitoring essential.'
        },
        {
            herbs: ['Neem', 'Jamun', 'Gurmar'],
            preparation: 'Take 1/4 tsp each neem and gurmar powder with water. Eat fresh jamun fruit in season or take jamun seed powder.',
            usage: 'Take morning and evening on empty stomach. Jamun (Indian Blackberry) seeds are especially powerful - dry and powder them.',
            benefits: 'Neem increases insulin sensitivity and reduces blood sugar, Jamun seeds contain compounds that slow starch to sugar conversion, Gurmar (Gymnema) regenerates pancreatic cells over time.',
            precautions: 'These herbs enhance medication effects - work with your doctor to monitor and adjust. Not for type 1 diabetes. May cause hypoglycemia if not monitored.'
        }
    ],
    'blood pressure': [
        {
            herbs: ['Hawthorn', 'Hibiscus', 'Garlic'],
            preparation: 'Make tea with 1 tsp hawthorn berries and 1 tbsp hibiscus flowers. Take 1-2 garlic cloves daily (raw or lightly cooked).',
            usage: 'Drink 2-3 cups of the tea daily. Eat garlic with meals. These work gradually - expect results over 4-8 weeks.',
            benefits: 'Hawthorn dilates blood vessels and strengthens heart muscle, Hibiscus acts as a natural ACE inhibitor to lower pressure, Garlic reduces arterial stiffness and has mild blood-thinning effects.',
            precautions: 'May enhance blood pressure medication - monitor closely. Avoid excessive garlic before surgery. Hibiscus may affect estrogen levels.'
        },
        {
            herbs: ['Arjuna', 'Ashwagandha', 'Brahmi'],
            preparation: 'Mix 1/4 tsp each herb powder. Take with warm water or milk twice daily - morning and evening.',
            usage: 'Take consistently for 8-12 weeks. These Ayurvedic heart tonics work gradually but deeply. Combine with stress reduction.',
            benefits: 'Arjuna is the premier Ayurvedic heart herb - strengthens cardiac muscle, Ashwagandha reduces stress-related blood pressure elevation, Brahmi calms the nervous system and improves circulation.',
            precautions: 'May interact with heart medications. Ashwagandha affects thyroid. Not during pregnancy. Regular blood pressure monitoring recommended.'
        },
        {
            herbs: ['Olive Leaf', 'Celery Seed', 'Lemon Balm'],
            preparation: 'Steep 1 tsp olive leaf and 1/2 tsp celery seed in hot water for 15 minutes. Add lemon balm for flavor. Strain and drink.',
            usage: 'Drink 2 cups daily. Celery can also be eaten fresh or juiced. These herbs support healthy blood pressure through different mechanisms.',
            benefits: 'Olive Leaf contains oleuropein which relaxes blood vessels, Celery Seed has diuretic action and contains phthalides that relax artery walls, Lemon Balm reduces stress and anxiety that raise pressure.',
            precautions: 'Celery seed may interact with blood thinners and lithium. Avoid during pregnancy. May increase sun sensitivity.'
        }
    ],
    'acidity': [
        {
            herbs: ['Licorice Root', 'Slippery Elm', 'Marshmallow Root'],
            preparation: 'Decoct 1/2 tsp licorice and 1/2 tsp marshmallow root in 2 cups water for 15 minutes. Add 1/2 tsp slippery elm powder to warm tea.',
            usage: 'Drink 20 minutes before meals and at bedtime. The mucilage coats and protects the stomach lining. Sip slowly.',
            benefits: 'Licorice (DGL form) increases protective mucus in the stomach, Slippery Elm coats the esophagus and stomach with soothing gel, Marshmallow Root reduces inflammation and promotes tissue healing.',
            precautions: 'Use DGL licorice (deglycyrrhizinated) for long-term use to avoid blood pressure effects. These herbs may slow medication absorption.'
        },
        {
            herbs: ['Amla', 'Shatavari', 'Fennel'],
            preparation: 'Take 1/2 tsp amla powder and 1/4 tsp shatavari with water. Chew 1/2 tsp fennel seeds after meals.',
            usage: 'Take amla-shatavari in the morning. Fennel after every meal. These Ayurvedic herbs cool excess pitta (heat/acidity).',
            benefits: 'Amla is cooling and reduces excess stomach acid production, Shatavari nourishes and soothes the digestive lining, Fennel reduces gas and bloating while cooling the digestive tract.',
            precautions: 'Generally very safe. Shatavari not recommended during acute colds or congestion. Amla may enhance iron absorption.'
        },
        {
            herbs: ['Chamomile', 'Ginger', 'Aloe Vera'],
            preparation: 'Drink chamomile tea after meals. Take 2 tbsp aloe vera juice before meals. Add small amount of ginger to reduce nausea.',
            usage: 'Aloe vera juice taken on empty stomach is very effective. Chamomile tea calms spasms. Avoid lying down after eating.',
            benefits: 'Chamomile relaxes the stomach and reduces acid production, Aloe Vera heals damaged digestive tissue and reduces inflammation, Ginger promotes healthy digestion without increasing acid.',
            precautions: 'Use only inner gel aloe vera (outer leaf is a laxative). Avoid mint if acid reflux is present. Small ginger amounts only - excess can worsen acidity.'
        }
    ],
    'hair loss': [
        {
            herbs: ['Bhringraj', 'Amla', 'Brahmi'],
            preparation: 'Make hair oil: heat 1 cup coconut oil with 2 tbsp each bhringraj, amla, and brahmi powder on low for 20 minutes. Strain and store.',
            usage: 'Massage warm oil into scalp 30 minutes before washing, 2-3 times weekly. Leave overnight for deep treatment. Consistent use for 3-6 months.',
            benefits: 'Bhringraj is the "King of Hair" - prevents hair loss and promotes regrowth, Amla strengthens hair follicles and prevents premature graying, Brahmi nourishes the scalp and reduces hair fall from stress.',
            precautions: 'Patch test first. May stain light hair slightly. These herbs work slowly but provide lasting results. Be patient.'
        },
        {
            herbs: ['Rosemary', 'Nettle', 'Horsetail'],
            preparation: 'Make strong tea with 1 tbsp each herb in 2 cups water. Simmer 15 minutes. Cool and use as final rinse after shampooing.',
            usage: 'Use as hair rinse 2-3 times weekly. Massage into scalp and leave for 5 minutes before rinsing. Also drink nettle tea internally.',
            benefits: 'Rosemary stimulates hair follicles and improves circulation to scalp, Nettle blocks DHT (the hormone that causes pattern baldness), Horsetail provides silica for stronger, thicker hair shafts.',
            precautions: 'These herbs work best for early-stage hair loss. May darken light hair over time. Avoid horsetail tea internally during pregnancy.'
        },
        {
            herbs: ['Hibiscus', 'Fenugreek', 'Curry Leaves'],
            preparation: 'Soak 2 tbsp fenugreek overnight. Blend with fresh hibiscus flowers and curry leaves. Apply paste to scalp for 30 minutes.',
            usage: 'Use this hair mask weekly. For daily support, heat curry leaves in coconut oil and massage into scalp before bed.',
            benefits: 'Hibiscus strengthens hair from root to tip and adds shine, Fenugreek seeds are rich in proteins that rebuild damaged hair, Curry Leaves prevent premature graying and stimulate hair growth.',
            precautions: 'Fenugreek may smell slightly - add essential oils if desired. Fresh ingredients work best. May cause allergic reaction in some - patch test.'
        }
    ],
    'weight loss': [
        {
            herbs: ['Green Tea', 'Ginger', 'Cinnamon'],
            preparation: 'Brew green tea with fresh ginger slices and a cinnamon stick. Steep 3-5 minutes only (longer makes it bitter).',
            usage: 'Drink 2-3 cups daily between meals. Best taken 30 minutes before exercise. Avoid adding sugar or milk.',
            benefits: 'Green Tea boosts metabolism and increases fat burning by 4-5%, Ginger is thermogenic - increases calorie burning, Cinnamon regulates blood sugar to prevent fat storage.',
            precautions: 'Contains caffeine - avoid in evening. May cause stomach upset if taken on empty stomach. Not for pregnant women.'
        },
        {
            herbs: ['Triphala', 'Garcinia', 'Guggulu'],
            preparation: 'Take 1/2 tsp triphala before bed. Take garcinia 30 minutes before meals. Guggulu can be taken morning and evening.',
            usage: 'Consistent use for 3-6 months with diet and exercise. Triphala cleanses, garcinia suppresses appetite, guggulu boosts metabolism.',
            benefits: 'Triphala gently detoxifies and improves nutrient absorption, Garcinia Cambogia suppresses appetite and blocks fat production, Guggulu stimulates thyroid and increases metabolic rate.',
            precautions: 'Guggulu may interact with thyroid medications. Garcinia controversial - use quality sources only. These support weight loss but require lifestyle changes.'
        },
        {
            herbs: ['Fennel', 'Cumin', 'Fenugreek'],
            preparation: 'Soak 1 tsp fenugreek seeds overnight. In the morning, add 1/2 tsp each fennel and cumin seeds. Drink the water and chew the seeds.',
            usage: 'Take first thing in the morning on empty stomach. These seeds help control appetite and improve digestion throughout the day.',
            benefits: 'Fennel suppresses appetite and reduces water retention, Cumin increases fat burning and improves digestion, Fenugreek creates feeling of fullness and stabilizes blood sugar.',
            precautions: 'May cause initial bloating as digestion adjusts. Fenugreek may smell in sweat. Not recommended during pregnancy.'
        }
    ]
};

// --- FUNCTION: Generate 3 Dynamic Remedy Cards for a Disease ---
function generateDiseaseRemedies(diseaseName) {
    const normalizedDisease = diseaseName.toLowerCase().trim();
    
    // Find matching disease in database
    let matchedDisease = null;
    let matchedRemedies = null;
    
    // Check for exact match first
    if (diseaseRemediesDB[normalizedDisease]) {
        matchedDisease = normalizedDisease;
        matchedRemedies = diseaseRemediesDB[normalizedDisease];
    } else {
        // Check for partial matches
        for (const disease of Object.keys(diseaseRemediesDB)) {
            if (normalizedDisease.includes(disease) || disease.includes(normalizedDisease)) {
                matchedDisease = disease;
                matchedRemedies = diseaseRemediesDB[disease];
                break;
            }
        }
    }
    
    if (!matchedRemedies) {
        return null;
    }
    
    // Generate 3 remedy cards with unique IDs
    const generatedRemedies = matchedRemedies.map((remedy, index) => {
        const remedyNumber = index + 1;
        const remedyNames = [
            `${capitalizeFirst(matchedDisease)} Relief Formula ${remedyNumber}`,
            `Natural ${capitalizeFirst(matchedDisease)} Treatment ${remedyNumber}`,
            `Herbal ${capitalizeFirst(matchedDisease)} Remedy ${remedyNumber}`
        ];
        
        return {
            id: `gen-${matchedDisease}-${index}`,
            name: remedyNames[index] || `${capitalizeFirst(matchedDisease)} Remedy ${remedyNumber}`,
            ailment: [capitalizeFirst(matchedDisease)],
            herbs: remedy.herbs,
            preparation: remedy.preparation,
            usage: remedy.usage,
            benefits: remedy.benefits,
            precautions: remedy.precautions,
            description: remedy.benefits,
            isGenerated: true,
            image: getRemedyImage(remedy.herbs, matchedDisease)
        };
    });
    
    return {
        disease: matchedDisease,
        remedies: generatedRemedies
    };
}

// Helper function to capitalize first letter
function capitalizeFirst(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

// Helper function to get a relevant image based on herbs
function getRemedyImage(herbs, disease) {
    const herbImages = {
        'Elderberry': 'https://images.unsplash.com/photo-1596463989950-4fe4a5ecb6a1?w=400',
        'Ginger': 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?w=400',
        'Turmeric': 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?w=400',
        'Chamomile': 'https://images.unsplash.com/photo-1587593810167-a84920ea0781?w=400',
        'Lavender': 'https://images.unsplash.com/photo-1611909023032-2d6b3134ecba?w=400',
        'Peppermint': 'https://images.unsplash.com/photo-1628556270448-4d4e4148e1b1?w=400',
        'Tulsi': 'https://images.unsplash.com/photo-1515694346937-94d85e41e6f0?w=400',
        'Ashwagandha': 'https://images.unsplash.com/photo-1611909023032-2d6b3134ecba?w=400',
        'Valerian': 'https://images.unsplash.com/photo-1587593810167-a84920ea0781?w=400',
        'Neem': 'https://images.unsplash.com/photo-1515694346937-94d85e41e6f0?w=400'
    };
    
    // Try to find image for first herb
    for (const herb of herbs) {
        if (herbImages[herb]) {
            return herbImages[herb];
        }
    }
    
    // Default images based on disease category
    const diseaseImages = {
        'cold': 'https://images.unsplash.com/photo-1587593810167-a84920ea0781?w=400',
        'flu': 'https://images.unsplash.com/photo-1587593810167-a84920ea0781?w=400',
        'headache': 'https://images.unsplash.com/photo-1611909023032-2d6b3134ecba?w=400',
        'anxiety': 'https://images.unsplash.com/photo-1611909023032-2d6b3134ecba?w=400',
        'insomnia': 'https://images.unsplash.com/photo-1611909023032-2d6b3134ecba?w=400',
        'digestion': 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?w=400',
        'stress': 'https://images.unsplash.com/photo-1611909023032-2d6b3134ecba?w=400',
        'cough': 'https://images.unsplash.com/photo-1587593810167-a84920ea0781?w=400',
        'inflammation': 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?w=400',
        'skin': 'https://images.unsplash.com/photo-1515694346937-94d85e41e6f0?w=400',
        'fever': 'https://images.unsplash.com/photo-1515694346937-94d85e41e6f0?w=400',
        'immunity': 'https://images.unsplash.com/photo-1587593810167-a84920ea0781?w=400'
    };
    
    return diseaseImages[disease] || 'https://images.unsplash.com/photo-1587593810167-a84920ea0781?w=400';
}

// --- HERB BENEFITS DATABASE (for remedy content generation) ---
const herbBenefitsDB = {
    'Elderberry': {
        botanical: 'Sambucus nigra',
        benefits: {
            'Cold': 'Rich in antioxidants and vitamins that boost immune response and reduce cold duration.',
            'Flu': 'Contains anthocyanins that inhibit viral replication and reduce flu severity by 3-4 days.',
            'Immunity': 'Stimulates cytokine production to strengthen the immune system naturally.',
            'Congestion': 'Acts as a natural decongestant and reduces inflammation in respiratory passages.'
        }
    },
    'Ginger': {
        botanical: 'Zingiber officinale',
        benefits: {
            'Cold': 'Warming properties help fight infection and soothe sore throat.',
            'Flu': 'Anti-inflammatory compounds reduce body aches and fever.',
            'Nausea': 'Gingerols calm the digestive system and reduce nausea effectively.',
            'Congestion': 'Promotes sweating to help break fever and clear congestion.',
            'Indigestion': 'Stimulates digestive enzymes and relieves bloating.',
            'Bloating': 'Carminative properties help expel gas and reduce abdominal discomfort.'
        }
    },
    'Echinacea': {
        botanical: 'Echinacea purpurea',
        benefits: {
            'Cold': 'Increases white blood cell count to fight off cold viruses.',
            'Flu': 'Reduces duration of flu symptoms when taken at first sign.',
            'Immunity': 'Activates immune cells and enhances the body\'s defense mechanisms.'
        }
    },
    'Thyme': {
        botanical: 'Thymus vulgaris',
        benefits: {
            'Cold': 'Natural antiseptic that fights respiratory infections.',
            'Cough': 'Relaxes bronchial muscles and acts as an expectorant.',
            'Congestion': 'Thymol compound helps clear mucus from airways.',
            'Bronchitis': 'Anti-inflammatory and antimicrobial properties soothe bronchial inflammation.'
        }
    },
    'Valerian Root': {
        botanical: 'Valeriana officinalis',
        benefits: {
            'Insomnia': 'Increases GABA levels in the brain to promote natural sleep.',
            'Anxiety': 'Calms the nervous system without causing morning grogginess.',
            'Stress': 'Reduces cortisol levels and promotes relaxation.'
        }
    },
    'Chamomile': {
        botanical: 'Matricaria chamomilla',
        benefits: {
            'Insomnia': 'Contains apigenin that binds to brain receptors inducing calm.',
            'Anxiety': 'Gentle sedative effect reduces nervous tension.',
            'Stress': 'Soothes frayed nerves and promotes mental relaxation.',
            'Indigestion': 'Relaxes digestive muscles and reduces stomach cramps.'
        }
    },
    'Lavender': {
        botanical: 'Lavandula angustifolia',
        benefits: {
            'Insomnia': 'Linalool compound promotes deep, restful sleep.',
            'Anxiety': 'Calms the limbic system and reduces panic symptoms.',
            'Stress': 'Aromatherapy benefits lower heart rate and blood pressure.'
        }
    },
    'Peppermint': {
        botanical: 'Mentha piperita',
        benefits: {
            'Indigestion': 'Relaxes stomach muscles and improves bile flow.',
            'Bloating': 'Menthol relieves gas and intestinal spasms.',
            'Nausea': 'Cooling sensation calms the stomach and reduces nausea.',
            'Headache': 'Applied topically, relieves tension headaches.'
        }
    },
    'Fennel': {
        botanical: 'Foeniculum vulgare',
        benefits: {
            'Indigestion': 'Stimulates digestive juices and reduces acid reflux.',
            'Bloating': 'Carminative properties expel trapped gas.',
            'Nausea': 'Soothes the stomach lining and reduces queasiness.'
        }
    },
    'Milk Thistle': {
        botanical: 'Silybum marianum',
        benefits: {
            'Detox': 'Silymarin protects liver cells and promotes regeneration.',
            'Fatigue': 'Supports liver function leading to improved energy.',
            'Skin issues': 'Liver detox reflects in clearer, healthier skin.'
        }
    },
    'Turmeric': {
        botanical: 'Curcuma longa',
        benefits: {
            'Inflammation': 'Curcumin is a powerful anti-inflammatory compound.',
            'Joint Pain': 'Reduces arthritis pain and stiffness.',
            'Detox': 'Supports liver detoxification pathways.'
        }
    },
    'Ashwagandha': {
        botanical: 'Withania somnifera',
        benefits: {
            'Stress': 'Adaptogen that balances cortisol and reduces chronic stress.',
            'Burnout': 'Restores adrenal function and combats exhaustion.',
            'Low Energy': 'Increases stamina and reduces fatigue.',
            'Anxiety': 'Calms the nervous system without sedation.'
        }
    },
    'Holy Basil': {
        botanical: 'Ocimum tenuiflorum',
        benefits: {
            'Stress': 'Adaptogenic herb that normalizes stress response.',
            'Burnout': 'Supports adrenal glands and restores energy.',
            'Immunity': 'Antimicrobial properties boost immune defense.'
        }
    },
    'Nettle Leaf': {
        botanical: 'Urtica dioica',
        benefits: {
            'Seasonal Allergies': 'Natural antihistamine that reduces allergic reactions.',
            'Hay Fever': 'Inhibits histamine release and reduces sneezing.',
            'Inflammation': 'Rich in anti-inflammatory compounds.'
        }
    },
    'Hawthorn Berry': {
        botanical: 'Crataegus monogyna',
        benefits: {
            'High Blood Pressure': 'Dilates blood vessels and improves blood flow.',
            'Circulation': 'Strengthens heart muscle and improves cardiac output.',
            'Cholesterol': 'Antioxidants help reduce LDL oxidation.'
        }
    },
    'Feverfew': {
        botanical: 'Tanacetum parthenium',
        benefits: {
            'Migraine': 'Parthenolide prevents blood vessel constriction.',
            'Headache': 'Reduces frequency and severity of headaches.'
        }
    },
    'Willow Bark': {
        botanical: 'Salix alba',
        benefits: {
            'Headache': 'Contains salicin, a natural pain reliever similar to aspirin.',
            'Migraine': 'Reduces inflammation and pain signaling.',
            'Joint Pain': 'Anti-inflammatory properties ease arthritis pain.'
        }
    },
    'Slippery Elm Bark': {
        botanical: 'Ulmus rubra',
        benefits: {
            'Heartburn': 'Mucilage coats and soothes the esophagus.',
            'Acid Reflux': 'Creates protective barrier against stomach acid.',
            'Stomach Ulcers': 'Promotes healing of damaged digestive lining.'
        }
    },
    'Licorice Root': {
        botanical: 'Glycyrrhiza glabra',
        benefits: {
            'Heartburn': 'DGL form soothes stomach lining without side effects.',
            'Stomach Ulcers': 'Promotes mucus production to protect stomach.',
            'Sore Throat': 'Demulcent properties coat and soothe throat.'
        }
    },
    'Calendula': {
        botanical: 'Calendula officinalis',
        benefits: {
            'Minor Wounds': 'Promotes rapid tissue healing and skin regeneration.',
            'Infections': 'Antimicrobial properties prevent wound infection.',
            'Inflammation': 'Reduces swelling and redness in skin conditions.'
        }
    },
    'Arnica': {
        botanical: 'Arnica montana',
        benefits: {
            'Joint Pain': 'Reduces swelling and bruising when applied topically.',
            'Arthritis': 'Anti-inflammatory action eases joint stiffness.',
            'Muscle Aches': 'Increases blood flow and speeds healing.'
        }
    },
    'Ginkgo Biloba': {
        botanical: 'Ginkgo biloba',
        benefits: {
            'Poor Focus': 'Increases blood flow to the brain improving concentration.',
            'Cognitive Decline': 'Antioxidants protect brain cells from damage.',
            'Memory': 'Enhances neurotransmitter function for better recall.'
        }
    },
    'Rosemary': {
        botanical: 'Rosmarinus officinalis',
        benefits: {
            'Hair Loss': 'Stimulates hair follicles and improves circulation to scalp.',
            'Dandruff': 'Antimicrobial properties reduce scalp irritation.',
            'Memory': 'Aromatic compounds improve alertness and memory.'
        }
    }
};

// Function to get herb benefits for a specific condition
function getHerbBenefitsForCondition(herbName, conditions) {
    const herbInfo = herbBenefitsDB[herbName];
    if (!herbInfo) {
        // Try to find in herbData
        const herbFromData = herbData.find(h => h.name.toLowerCase() === herbName.toLowerCase());
        if (herbFromData) {
            return {
                name: herbName,
                botanical: herbFromData.botanicalName,
                benefits: herbFromData.medicinalUses ? herbFromData.medicinalUses.join(' ') : 'Supports overall wellness.'
            };
        }
        return { name: herbName, botanical: '', benefits: 'Traditional herb used in herbal medicine.' };
    }
    
    // Find benefits matching the conditions
    let relevantBenefits = [];
    conditions.forEach(condition => {
        Object.keys(herbInfo.benefits).forEach(key => {
            if (key.toLowerCase().includes(condition.toLowerCase()) || 
                condition.toLowerCase().includes(key.toLowerCase())) {
                relevantBenefits.push(herbInfo.benefits[key]);
            }
        });
    });
    
    // If no specific match, get first available benefit
    if (relevantBenefits.length === 0) {
        relevantBenefits = Object.values(herbInfo.benefits).slice(0, 1);
    }
    
    return {
        name: herbName,
        botanical: herbInfo.botanical,
        benefits: [...new Set(relevantBenefits)].join(' ')
    };
}

// --- LOCAL SEARCH HISTORY MANAGER ---
const LOCAL_SEARCH_KEY = 'hg_local_searches';
const MAX_HISTORY = 8;

const LocalSearchHistory = {
    add(query, type) {
        if (!query || query.trim().length === 0) return;
        
        const history = this.getAll();
        if (!history[type]) history[type] = [];
        
        history[type] = history[type].filter(q => q.toLowerCase() !== query.toLowerCase());
        history[type].unshift(query.trim());
        history[type] = history[type].slice(0, MAX_HISTORY);
        
        localStorage.setItem(LOCAL_SEARCH_KEY, JSON.stringify(history));
    },
    
    get(type) {
        const history = this.getAll();
        return history[type] || [];
    },
    
    getAll() {
        try {
            return JSON.parse(localStorage.getItem(LOCAL_SEARCH_KEY)) || {};
        } catch {
            return {};
        }
    },
    
    clear(type) {
        const history = this.getAll();
        if (type) {
            delete history[type];
        } else {
            localStorage.removeItem(LOCAL_SEARCH_KEY);
            return;
        }
        localStorage.setItem(LOCAL_SEARCH_KEY, JSON.stringify(history));
    },
    
    show(input, type) {
        const searches = this.get(type);
        if (searches.length === 0) {
            this.hide(input);
            return;
        }
        
        let dropdown = input.nextElementSibling;
        if (!dropdown?.classList.contains('history-dropdown')) {
            dropdown = document.createElement('div');
            dropdown.className = 'history-dropdown';
            input.parentElement.style.position = 'relative';
            input.after(dropdown);
        }
        
        dropdown.innerHTML = `
            <div class="history-header">
                <span>Recent Searches</span>
                <button class="history-clear" onclick="LocalSearchHistory.clearAndRefresh('${input.id}', '${type}'); event.stopPropagation();">Clear</button>
            </div>
            ${searches.map(s => `
                <div class="history-item" onclick="LocalSearchHistory.select('${input.id}', \`${s.replace(/`/g, '\\`').replace(/'/g, "\\'")}\`)">
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                    <span>${s}</span>
                </div>
            `).join('')}
        `;
        
        dropdown.style.display = 'block';
    },
    
    hide(input) {
        const dropdown = input.nextElementSibling;
        if (dropdown?.classList.contains('history-dropdown')) {
            dropdown.style.display = 'none';
        }
    },
    
    select(inputId, query) {
        const input = document.getElementById(inputId);
        if (!input) return;
        
        input.value = query;
        this.hide(input);
        
        // Map input IDs to pages
        const pageMap = {
            'search-input': 'garden',
            'tour-search-input': 'tour',
            'remedies-search-input': 'remedies',
            'planner-search-input': 'planner'
        };
        
        const targetPage = pageMap[inputId];
        
        // Use the global function if available, otherwise trigger input event
        if (window.showPageAndSearch && targetPage) {
            window.showPageAndSearch(targetPage, query);
        } else {
            // Fallback: trigger input event
            input.dispatchEvent(new Event('input', { bubbles: true }));
        }
    },
    
    clearAndRefresh(inputId, type) {
        this.clear(type);
        const input = document.getElementById(inputId);
        if (input) this.hide(input);
    }
};

// Expose to window for inline onclick handlers
window.LocalSearchHistory = LocalSearchHistory;

// --- SYMPTOM TO DISEASE MAPPING ---
const symptomToDiseaseMap = {
    // Sleep related
    'sleep': ['Insomnia', 'Anxiety', 'Stress'],
    'insomnia': ['Insomnia', 'Anxiety', 'Stress'],
    'sleepless': ['Insomnia', 'Anxiety'],
    'cant sleep': ['Insomnia', 'Anxiety'],
    'trouble sleeping': ['Insomnia', 'Stress'],
    'restless': ['Insomnia', 'Anxiety'],
    'awake': ['Insomnia'],
    
    // Anxiety & Stress
    'anxiety': ['Anxiety', 'Stress', 'Nervous Tension'],
    'anxious': ['Anxiety', 'General Anxiety', 'Worry'],
    'stress': ['Stress', 'Chronic Stress', 'Burnout'],
    'stressed': ['Stress', 'Burnout', 'Low Energy'],
    'nervous': ['Anxiety', 'Nervous Tension'],
    'worry': ['Anxiety', 'General Anxiety', 'Worry'],
    'worried': ['Anxiety', 'Worry'],
    'panic': ['Anxiety', 'General Anxiety'],
    'racing': ['Anxiety', 'Insomnia'],
    'tension': ['Tension', 'Headache', 'Stress'],
    'calm': ['Anxiety', 'Stress'],
    'relax': ['Stress', 'Anxiety', 'Tension'],
    
    // Pain
    'pain': ['Joint Pain', 'Headache', 'Muscle Aches'],
    'ache': ['Muscle Aches', 'Joint Pain', 'Headache'],
    'aching': ['Muscle Aches', 'Aches'],
    'sore': ['Sore Throat', 'Muscle Aches'],
    'hurt': ['Joint Pain', 'Muscle Aches'],
    'headache': ['Headache', 'Migraine', 'Tension'],
    'migraine': ['Migraine', 'Headache'],
    'joint': ['Joint Pain', 'Arthritis', 'Inflammation'],
    'arthritis': ['Arthritis', 'Joint Pain', 'Inflammation'],
    'muscle': ['Muscle Aches', 'Tension', 'Cramps'],
    'back': ['Joint Pain', 'Muscle Aches'],
    'knee': ['Joint Pain', 'Arthritis'],
    
    // Digestive
    'stomach': ['Indigestion', 'Bloating', 'Nausea'],
    'digestion': ['Indigestion', 'Bloating'],
    'indigestion': ['Indigestion', 'Bloating', 'Nausea'],
    'bloating': ['Bloating', 'Indigestion'],
    'bloated': ['Bloating', 'Indigestion'],
    'gas': ['Bloating', 'Indigestion'],
    'nausea': ['Nausea', 'Indigestion'],
    'constipation': ['Constipation', 'Sluggish Bowel'],
    'constipated': ['Constipation', 'Sluggish Bowel'],
    'heartburn': ['Heartburn', 'Acid Reflux'],
    'acid': ['Acid Reflux', 'Heartburn'],
    'reflux': ['Acid Reflux', 'Heartburn', 'Stomach Ulcers'],
    'ulcer': ['Stomach Ulcers', 'Acid Reflux'],
    'appetite': ['Loss of Appetite', 'Appetite Control'],
    
    // Cold & Flu
    'cold': ['Cold', 'Flu', 'Congestion', 'Immunity'],
    'flu': ['Flu', 'Cold', 'Immunity', 'Congestion'],
    'fever': ['Cold', 'Flu', 'Immunity'],
    'feverish': ['Cold', 'Flu', 'Immunity'],
    'chills': ['Cold', 'Flu'],
    'cough': ['Cough', 'Bronchitis', 'Congestion', 'Cold'],
    'coughing': ['Cough', 'Bronchitis', 'Cold'],
    'congestion': ['Congestion', 'Sinusitis', 'Cold', 'Flu'],
    'congested': ['Congestion', 'Sinusitis', 'Cold'],
    'phlegm': ['Cough', 'Bronchitis', 'Congestion'],
    'mucus': ['Congestion', 'Sinusitis', 'Bronchitis'],
    'bronchitis': ['Bronchitis', 'Cough', 'Congestion'],
    'sinus': ['Sinusitis', 'Congestion'],
    'throat': ['Sore Throat', 'Cold'],
    'sore throat': ['Sore Throat', 'Cold', 'Flu'],
    'runny nose': ['Cold', 'Flu', 'Seasonal Allergies'],
    'sneezing': ['Seasonal Allergies', 'Cold', 'Hay Fever', 'Flu'],
    'body ache': ['Cold', 'Flu', 'Aches'],
    'body aches': ['Cold', 'Flu', 'Aches'],
    
    // Skin
    'skin': ['Skin issues', 'Acne', 'Eczema'],
    'acne': ['Acne', 'Oily Skin'],
    'pimple': ['Acne', 'Oily Skin'],
    'eczema': ['Eczema', 'Dry Skin', 'Psoriasis'],
    'psoriasis': ['Psoriasis', 'Eczema', 'Dry Skin'],
    'rash': ['Eczema', 'Skin issues'],
    'itchy': ['Eczema', 'Dry Skin', 'Seasonal Allergies'],
    'itching': ['Eczema', 'Psoriasis'],
    'dry skin': ['Dry Skin', 'Eczema'],
    'wound': ['Minor Wounds', 'Cuts', 'Scrapes'],
    'cut': ['Cuts', 'Minor Wounds', 'First Aid'],
    'scratch': ['Scratches', 'Minor Wounds'],
    'burn': ['Minor Wounds'],
    
    // Energy & Fatigue
    'tired': ['Low Energy', 'Fatigue', 'Burnout'],
    'fatigue': ['Fatigue', 'Low Energy', 'Burnout'],
    'exhausted': ['Fatigue', 'Burnout', 'Low Energy'],
    'exhaustion': ['Fatigue', 'Burnout'],
    'energy': ['Low Energy', 'Energy', 'Stamina'],
    'weak': ['Low Energy', 'Fatigue'],
    'burnout': ['Burnout', 'Chronic Stress', 'Low Energy'],
    'drained': ['Fatigue', 'Burnout'],
    
    // Immune & Prevention
    'immune': ['Immunity', 'Prevention'],
    'immunity': ['Immunity', 'Prevention'],
    'sick': ['Cold', 'Flu', 'Immunity'],
    'infection': ['Infections', 'Minor Wounds'],
    
    // Heart & Circulation
    'heart': ['Circulation', 'High Blood Pressure'],
    'blood pressure': ['High Blood Pressure', 'Circulation'],
    'circulation': ['Circulation', 'High Blood Pressure'],
    'cholesterol': ['Cholesterol', 'Heart Health'],
    'palpitations': ['Anxiety', 'Stress'],
    
    // Women's Health
    'pms': ['PMS', 'Menopausal Symptoms'],
    'period': ['PMS', 'Irregular Cycle'],
    'menstrual': ['PMS', 'Irregular Cycle'],
    'cramps': ['PMS', 'Muscle Aches', 'Cramps'],
    'menopause': ['Menopausal Symptoms', 'PMS'],
    'hormonal': ['PMS', 'Menopausal Symptoms', 'Irregular Cycle'],
    
    // Allergies
    'allergy': ['Seasonal Allergies', 'Hay Fever', 'Histamine'],
    'allergies': ['Seasonal Allergies', 'Hay Fever'],
    'hay fever': ['Hay Fever', 'Seasonal Allergies'],
    'histamine': ['Histamine', 'Seasonal Allergies'],
    
    // Mental & Focus
    'focus': ['Poor Focus', 'Cognitive Decline'],
    'concentration': ['Poor Focus', 'Cognitive Decline'],
    'memory': ['Cognitive Decline', 'Poor Focus'],
    'brain': ['Cognitive Decline', 'Poor Focus'],
    'foggy': ['Poor Focus', 'Cognitive Decline'],
    'depression': ['Stress', 'Anxiety'],
    'depressed': ['Stress', 'Anxiety'],
    'sad': ['Stress', 'Anxiety'],
    'mood': ['PMS', 'Stress'],
    
    // Detox & Liver
    'detox': ['Detox', 'Fatigue', 'Skin issues'],
    'liver': ['Detox'],
    'toxins': ['Detox'],
    
    // Urinary
    'uti': ['UTI', 'Kidney Stones'],
    'urinary': ['UTI', 'Fluid Retention'],
    'bladder': ['UTI'],
    'kidney': ['Kidney Stones', 'UTI'],
    
    // Weight
    'weight': ['Metabolism', 'Appetite Control'],
    'metabolism': ['Metabolism', 'Weight Management'],
    'overweight': ['Metabolism', 'Appetite Control'],
    
    // Eyes
    'eyes': ['Tired Eyes', 'Puffiness'],
    'eye strain': ['Tired Eyes', 'Puffiness'],
    'puffy eyes': ['Tired Eyes', 'Puffiness'],
    
    // Hair
    'hair': ['Hair Loss', 'Dandruff'],
    'dandruff': ['Dandruff', 'Dry Scalp'],
    'scalp': ['Dandruff', 'Dry Scalp'],
    'hair loss': ['Hair Loss'],
    
    // Oral Health
    'breath': ['Bad Breath', 'Gingivitis'],
    'gums': ['Gingivitis', 'Bad Breath'],
    'gingivitis': ['Gingivitis', 'Bad Breath']
};

// --- DIRECT DISEASE NAME LIST (common diseases user might type) ---
const directDiseaseNames = [
    'cold', 'flu', 'fever', 'cough', 'headache', 'migraine', 
    'anxiety', 'stress', 'insomnia', 'depression',
    'acne', 'eczema', 'psoriasis', 'rash',
    'arthritis', 'joint pain', 'back pain', 'muscle pain',
    'indigestion', 'bloating', 'constipation', 'diarrhea', 'nausea', 'heartburn',
    'allergy', 'allergies', 'hay fever', 'asthma',
    'diabetes', 'high blood pressure', 'hypertension', 'cholesterol',
    'fatigue', 'weakness', 'tiredness',
    'uti', 'urinary infection', 'kidney stone',
    'pms', 'menstrual cramps', 'period pain',
    'sore throat', 'bronchitis', 'sinusitis', 'congestion',
    'obesity', 'weight gain', 'weight loss',
    'hair loss', 'dandruff', 'baldness',
    'infection', 'wound', 'cut', 'burn',
    'immunity', 'low immunity', 'weak immunity'
];

// --- HERBAL REMEDIES ASSISTANT: Extract symptoms and find single best remedy ---
function extractSymptomsFromSentence(userInput) {
    const input = userInput.toLowerCase().trim();
    const detectedSymptoms = new Set();
    const matchedDiseases = new Set();
    
    // Phrases to remove from input (filler phrases)
    const fillerPhrases = [
        'i have', 'i am having', 'i am suffering from', 'i suffer from', 'suffering from',
        'i need', 'i want', 'need help with', 'help me with', 'help for',
        'fast recovery', 'quick recovery', 'quick relief', 'fast relief', 'immediate relief',
        'please help', 'please suggest', 'can you help', 'can you suggest',
        'what should i take', 'what can i take', 'what remedy', 'which remedy',
        'i feel', 'i am feeling', 'feeling like', 'i have been', 'i had',
        'for the past', 'since yesterday', 'since today', 'since morning',
        'give me', 'suggest me', 'recommend me', 'tell me',
        'any remedy', 'some remedy', 'good remedy', 'best remedy', 'natural remedy',
        'herbal remedy', 'home remedy', 'treatment for', 'cure for', 'medicine for',
        'i got', 'i am getting', 'getting', 'having problem with', 'problem with',
        'suffering with', 'dealing with', 'going through'
    ];
    
    // Remove filler phrases from input
    let cleanedInput = input;
    fillerPhrases.forEach(phrase => {
        cleanedInput = cleanedInput.replace(new RegExp(phrase, 'gi'), ' ');
    });
    cleanedInput = cleanedInput.replace(/\s+/g, ' ').trim();
    
    // Common stop words to ignore
    const stopWords = new Set(['i', 'am', 'have', 'been', 'having', 'a', 'an', 'the', 'my', 'me', 'and', 'or', 'but', 'is', 'are', 'was', 'were', 'be', 'being', 'do', 'does', 'did', 'doing', 'would', 'could', 'should', 'will', 'can', 'cant', 'cannot', 'dont', 'doesnt', 'didnt', 'wont', 'wouldnt', 'couldnt', 'shouldnt', 'to', 'of', 'in', 'for', 'on', 'with', 'at', 'by', 'from', 'as', 'into', 'through', 'during', 'before', 'after', 'above', 'below', 'up', 'down', 'out', 'off', 'over', 'under', 'again', 'further', 'then', 'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 'just', 'also', 'now', 'lately', 'recently', 'always', 'sometimes', 'often', 'never', 'really', 'feel', 'feeling', 'feels', 'like', 'get', 'getting', 'got', 'keeps', 'keep', 'kept', 'lot', 'lots', 'much', 'many', 'little', 'bit', 'quite', 'seem', 'seems', 'seemed', 'think', 'thought', 'know', 'knew', 'want', 'need', 'try', 'trying', 'because', 'since', 'every', 'day', 'night', 'time', 'times', 'week', 'weeks', 'month', 'months', 'year', 'years', 'really', 'help', 'please', 'something', 'anything', 'nothing', 'everything', 'fast', 'quick', 'immediate', 'urgent', 'recovery', 'relief', 'remedy', 'suggest', 'recommend', 'give', 'tell', 'cure', 'treatment', 'medicine', 'problem', 'issue', 'suffering', 'badly', 'severe', 'mild', 'chronic', 'acute']);
    
    // STEP 1: Check for direct disease names in input
    directDiseaseNames.forEach(disease => {
        if (cleanedInput.includes(disease)) {
            detectedSymptoms.add(disease);
            // Map to standardized disease names
            if (symptomToDiseaseMap[disease]) {
                symptomToDiseaseMap[disease].forEach(d => matchedDiseases.add(d));
            } else {
                // Capitalize first letter for display
                matchedDiseases.add(disease.charAt(0).toUpperCase() + disease.slice(1));
            }
        }
    });
    
    // STEP 2: Check for multi-word symptom/disease phrases
    Object.keys(symptomToDiseaseMap).forEach(symptom => {
        if (symptom.includes(' ') && cleanedInput.includes(symptom)) {
            detectedSymptoms.add(symptom);
            symptomToDiseaseMap[symptom].forEach(disease => matchedDiseases.add(disease));
        }
    });
    
    // STEP 3: Check directly for disease names from remedyData ailments
    remedyData.forEach(remedy => {
        remedy.ailment.forEach(ailment => {
            const ailmentLower = ailment.toLowerCase();
            if (cleanedInput.includes(ailmentLower)) {
                detectedSymptoms.add(ailment);
                matchedDiseases.add(ailment);
            }
        });
    });
    
    // STEP 4: Extract individual words and check against symptom map
    const words = cleanedInput.split(/[\s,?!.;:–\-\n]+/).filter(w => w.length > 2 && !stopWords.has(w));
    
    words.forEach(word => {
        // Check symptom-to-disease map
        if (symptomToDiseaseMap[word]) {
            detectedSymptoms.add(word);
            symptomToDiseaseMap[word].forEach(disease => matchedDiseases.add(disease));
        }
        
        // Check symptom synonyms
        Object.entries(symptomSynonyms).forEach(([category, synonyms]) => {
            if (synonyms.includes(word) || category === word) {
                if (symptomToDiseaseMap[category]) {
                    detectedSymptoms.add(word);
                    symptomToDiseaseMap[category].forEach(disease => matchedDiseases.add(disease));
                }
            }
        });
    });
    
    return {
        symptoms: Array.from(detectedSymptoms),
        diseases: Array.from(matchedDiseases)
    };
}

function findBestRemedy(extractedData) {
    const { symptoms, diseases } = extractedData;
    
    if (diseases.length === 0 && symptoms.length === 0) return null;
    
    let bestMatch = null;
    let highestScore = 0;
    
    // Track which user diseases each remedy covers
    remedyData.forEach(remedy => {
        let score = 0;
        const matchedAilments = [];
        const coveredUserDiseases = new Set();
        
        // For each user disease, check if this remedy treats it
        diseases.forEach(disease => {
            const diseaseLower = disease.toLowerCase();
            let diseaseMatched = false;
            
            remedy.ailment.forEach(ailment => {
                const ailmentLower = ailment.toLowerCase();
                
                // Exact match with disease (highest priority)
                if (ailmentLower === diseaseLower) {
                    score += 200;
                    diseaseMatched = true;
                    if (!matchedAilments.includes(ailment)) {
                        matchedAilments.push(ailment);
                    }
                }
                // Partial match - ailment contains disease word or vice versa
                else if (ailmentLower.includes(diseaseLower) || diseaseLower.includes(ailmentLower)) {
                    score += 100;
                    diseaseMatched = true;
                    if (!matchedAilments.includes(ailment)) {
                        matchedAilments.push(ailment);
                    }
                }
            });
            
            if (diseaseMatched) {
                coveredUserDiseases.add(disease);
            }
        });
        
        // BIG bonus for covering multiple user diseases
        const coverageBonus = coveredUserDiseases.size * 150;
        score += coverageBonus;
        
        // Extra bonus if remedy covers ALL user diseases
        if (coveredUserDiseases.size === diseases.length && diseases.length > 1) {
            score += 300;
        }
        
        // Calculate coverage percentage
        const coveragePercent = diseases.length > 0 ? (coveredUserDiseases.size / diseases.length) * 100 : 0;
        
        // Only consider remedies with at least one match
        if (score > 0 && score > highestScore) {
            highestScore = score;
            bestMatch = {
                ...remedy,
                matchScore: score,
                matchedAilments: [...new Set(matchedAilments)],
                coveredDiseases: Array.from(coveredUserDiseases),
                coveragePercent: Math.round(coveragePercent)
            };
        }
    });
    
    return bestMatch;
}

function renderAssistantResult(extractedData, remedy) {
    const resultContainer = document.getElementById('symptom-assistant-result');
    if (!resultContainer) return;
    
    const { symptoms, diseases } = extractedData;
    
    if (!remedy) {
        resultContainer.innerHTML = `
            <div class="p-6 rounded-xl border-2" style="border-color: #fbbf24; background-color: #fffbeb;">
                <div class="flex items-start gap-3">
                    <svg class="w-6 h-6 flex-shrink-0 mt-0.5" style="color: #f59e0b;" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                    </svg>
                    <div>
                        <p class="font-semibold text-amber-800">No matching remedy found</p>
                        <p class="text-sm text-amber-700 mt-1">Try describing your symptoms differently or browse our remedy collection below.</p>
                    </div>
                </div>
            </div>
        `;
        resultContainer.classList.remove('hidden');
        return;
    }
    
    // Get herb details from herbData
    const herbDetails = remedy.herbs.map(herbName => {
        const herb = herbData.find(h => h.name.toLowerCase() === herbName.toLowerCase());
        return herb ? { name: herbName, botanical: herb.botanicalName } : { name: herbName, botanical: '' };
    });
    
    // Show coverage info
    const coverageText = remedy.coveragePercent === 100 
        ? '✅ Covers all your conditions!' 
        : `Covers ${remedy.coveredDiseases?.length || 0} of ${diseases.length} conditions`;
    
    resultContainer.innerHTML = `
        <div class="rounded-xl overflow-hidden border-2" style="border-color: var(--sage-green-light); background-color: white;">
            <!-- Detected Symptoms -->
            <div class="p-4 border-b" style="background-color: var(--soft-gray); border-color: var(--sage-green-light);">
                <p class="text-sm font-medium mb-2" style="color: var(--sage-green-dark);">🔍 Detected Symptoms:</p>
                <div class="flex flex-wrap gap-2">
                    ${symptoms.map(s => `<span class="px-3 py-1 rounded-full text-sm font-medium" style="background-color: var(--sage-green-light); color: var(--sage-green-dark);">${s}</span>`).join('')}
                </div>
            </div>
            
            <!-- Matched Diseases/Conditions -->
            <div class="p-4 border-b" style="background-color: #f0fdf4; border-color: var(--sage-green-light);">
                <p class="text-sm font-medium mb-2" style="color: var(--sage-green-dark);">🎯 Matched Conditions (${diseases.length}):</p>
                <div class="flex flex-wrap gap-2">
                    ${diseases.map(d => {
                        const isCovered = remedy.coveredDiseases?.includes(d);
                        return `<span class="px-3 py-1 rounded-full text-sm font-medium border ${isCovered ? '' : 'opacity-50'}" style="border-color: ${isCovered ? 'var(--sage-green-medium)' : '#ccc'}; background-color: ${isCovered ? '#dcfce7' : 'white'}; color: var(--sage-green-dark);">${isCovered ? '✓ ' : ''}${d}</span>`;
                    }).join('')}
                </div>
            </div>
            
            <!-- Best Match Header -->
            <div class="p-4" style="background: linear-gradient(135deg, var(--sage-green-medium), var(--sage-green-dark));">
                <div class="flex items-center justify-between text-white">
                    <div class="flex items-center gap-2">
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                        </svg>
                        <span class="font-semibold">Best Remedy Match</span>
                    </div>
                    <span class="text-sm">${coverageText}</span>
                </div>
            </div>
            
            <!-- Remedy Content -->
            <div class="p-6">
                <div class="flex flex-col md:flex-row gap-6">
                    <img src="${remedy.image}" alt="${remedy.name}" class="w-full md:w-48 h-40 object-cover rounded-xl" onerror="this.onerror=null;this.src='https://placehold.co/400x300/cbd5e1/475569?text=Image';">
                    <div class="flex-1">
                        <h3 class="text-2xl font-bold mb-2" style="color: var(--sage-green-dark);">${remedy.name}</h3>
                        <p class="text-sm mb-3" style="color: var(--text-light);">Treats: ${remedy.matchedAilments.length > 0 ? remedy.matchedAilments.join(', ') : remedy.ailment.join(', ')}</p>
                        
                        <!-- Herbs Used -->
                        <div class="mb-4">
                            <p class="text-sm font-semibold mb-2" style="color: var(--sage-green-dark);">🌿 Herbs Used:</p>
                            <div class="flex flex-wrap gap-2">
                                ${herbDetails.map(h => `
                                    <span class="px-3 py-1 rounded-full text-sm border" style="border-color: var(--sage-green-medium); color: var(--sage-green-dark);">
                                        ${h.name}${h.botanical ? ` <span class="italic text-xs">(${h.botanical})</span>` : ''}
                                    </span>
                                `).join('')}
                            </div>
                        </div>
                        
                        <!-- Why This Works -->
                        <div class="mb-4">
                            <p class="text-sm font-semibold mb-1" style="color: var(--sage-green-dark);">💡 Why This Works:</p>
                            <p class="text-sm" style="color: var(--text-dark);">${remedy.description.substring(0, 200)}${remedy.description.length > 200 ? '...' : ''}</p>
                        </div>
                        
                        <!-- Simple Usage -->
                        <div class="p-3 rounded-lg" style="background-color: var(--soft-gray);">
                            <p class="text-sm font-semibold mb-1" style="color: var(--sage-green-dark);">📋 Simple Usage:</p>
                            <p class="text-sm" style="color: var(--text-dark);">${remedy.preparation.substring(0, 150)}${remedy.preparation.length > 150 ? '...' : ''}</p>
                        </div>
                    </div>
                </div>
                
                <!-- View Full Details Button -->
                <button onclick="window.showRemedyDetail(${remedy.id})" class="modern-btn mt-4 w-full py-3 rounded-xl font-semibold">
                    View Full Remedy Details
                </button>
            </div>
            
            <!-- Disclaimer -->
            <div class="px-6 pb-4">
                <p class="text-xs text-center" style="color: var(--text-light);">⚠️ Always consult a healthcare professional before using herbal remedies.</p>
            </div>
        </div>
    `;
    
    resultContainer.classList.remove('hidden');
}

// Function to generate herbal recommendation
function generateHerbalRecommendation(userInput) {
    const input = userInput.toLowerCase();
    
    // Extract temperature
    const tempMatch = input.match(/(\d+(\.\d+)?)\s*°?\s*f/i);
    const temperature = tempMatch ? parseFloat(tempMatch[1]) : null;
    
    // Extract symptoms
    const words = input.split(/\W+/).filter(w => w.length > 1);
    const symptoms = new Set();
    words.forEach(word => {
        if (symptomSynonyms[word]) {
            symptomSynonyms[word].forEach(syn => symptoms.add(syn));
        }
        symptoms.add(word);
    });
    
    // Find matching remedies
    const matches = remedyData.filter(remedy => {
        return remedy.ailment.some(ailment => {
            const ailmentWords = ailment.toLowerCase().split(/\W+/);
            return ailmentWords.some(word => symptoms.has(word));
        });
    });
    
    // Select 2-3
    const selected = matches.slice(0, 3);
    if (selected.length === 0) {
        return "I'm sorry, I couldn't find specific herbal remedies for your symptoms. Please consult a healthcare professional for personalized advice.";
    }
    
    // Generate response
    let response = "I'm here to help with some gentle, traditional herbal suggestions based on what you've shared. ";
    if (temperature) {
        if (temperature > 100) {
            response += `With a temperature of ${temperature}°F, which suggests a moderate fever, it's important to support your body's natural defenses while staying hydrated. `;
        } else if (temperature > 98.6) {
            response += `Your temperature of ${temperature}°F indicates a mild fever, so let's focus on soothing remedies to help you feel better. `;
        } else {
            response += `Since your temperature is ${temperature}°F, which is within normal range, these remedies can help with your other symptoms. `;
        }
    }
    response += "Here are a couple of traditional herbal remedies that may help: ";
    selected.forEach((remedy, index) => {
        if (index > 0) response += " Additionally, ";
        // For parts used, assume dried herbs if not specified
        const parts = remedy.herbs.map(herb => {
            // Simple mapping, can be expanded
            if (herb.toLowerCase().includes('root')) return `${herb} (root)`;
            if (herb.toLowerCase().includes('leaf')) return `${herb} (leaves)`;
            if (herb.toLowerCase().includes('berry')) return `${herb} (berries)`;
            return `${herb} (dried herb)`;
        }).join(', ');
        response += `try ${remedy.name}, using ${parts}. ${remedy.preparation}. `;
    });
    response += "Remember, these are traditional suggestions and not a substitute for professional medical advice. Please consult with a healthcare provider before starting any new remedies, especially if you're pregnant, nursing, or taking medications.";
    return response;
}

// Define a function that contains ALL of the application's logic.
// This function will be called ONLY after a successful login.
const initializeApp = () => {
    // --- DOM Elements ---
    const mainContent = document.getElementById('main-content');
    const gardenContainer = document.getElementById('herb-garden');
    const modal = document.getElementById('herb-modal');
    const modalContent = document.getElementById('modal-content');
    const searchInput = document.getElementById('search-input');
    const pageContents = document.querySelectorAll('.page-content');
    const navLinks = document.querySelectorAll('.nav-link');
    const mobileNavLinks = document.querySelectorAll('.nav-link-mobile');
    const tourContent = document.getElementById('tour-content');
    const tourSearchInput = document.getElementById('tour-search-input');
    const tourSuggestionsContainer = document.getElementById('tour-suggestions');
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const mobileMenu = document.getElementById('mobile-menu');
    const herbOfTheDayContainer = document.getElementById('herb-of-the-day');
    const header = document.getElementById('main-header'); 
    
    // --- PLANNER ELEMENTS ---
    const plannerSearchInput = document.getElementById('planner-search-input');
    const companionResult = document.getElementById('companion-result');      
    
    // --- NEW REMEDY ELEMENTS ---
    const remediesContainer = document.getElementById('remedies-container');
    const remediesSearchInput = document.getElementById('remedies-search-input');

    // --- SYMPTOM ASSISTANT ELEMENTS ---
    const symptomAssistantInput = document.getElementById('symptom-assistant-input');
    const symptomAssistantBtn = document.getElementById('symptom-assistant-btn');
    const symptomAssistantResult = document.getElementById('symptom-assistant-result');

    // --- HEALTH ASSISTANT ELEMENTS ---
    const healthAssistantInput = document.getElementById('health-assistant-input');
    const healthAssistantOutput = document.getElementById('health-assistant-output');
    const healthAssistantButton = document.getElementById('health-assistant-button');
    
    // --- GLOBAL SEARCH HANDLER (for Enter key and history) ---
    window.showPageAndSearch = (pageId, searchTerm) => {
        const currentPage = document.querySelector('.page-content:not(.hidden)')?.id;
        const needsNavigation = currentPage !== `page-${pageId}`;
        
        // Execute search based on page type
        const executeSearch = () => {
            switch(pageId) {
                case 'garden':
                    if (searchInput) {
                        searchInput.value = searchTerm;
                        const filteredHerbs = herbData.filter(herb => 
                            herb.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            herb.botanicalName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            (herb.medicinalUses && herb.medicinalUses.some(use => use.toLowerCase().includes(searchTerm.toLowerCase())))
                        );
                        renderGarden(filteredHerbs, true);
                        LocalSearchHistory.add(searchTerm, 'Garden');
                        logSearch(searchTerm, 'Garden');
                    }
                    break;
                    
                case 'tour':
                    if (tourSearchInput) {
                        tourSearchInput.value = searchTerm;
                        const tourHerbs = searchTerm.trim().length > 0 
                            ? instantSearch(searchTerm, herbSearchIndex, herbData)
                            : herbData;
                        renderTour(tourHerbs);
                        if (tourSuggestionsContainer) tourSuggestionsContainer.classList.add('hidden');
                        LocalSearchHistory.add(searchTerm, 'Virtual Tour');
                        logSearch(searchTerm, 'Virtual Tour');
                    }
                    break;
                    
                case 'remedies':
                    if (remediesSearchInput) {
                        remediesSearchInput.value = searchTerm;
                        // Try to generate 3 disease-specific remedy cards first
                        const generated = generateDiseaseRemedies(searchTerm);
                        if (generated && generated.remedies && generated.remedies.length > 0) {
                            renderRemedies(searchTerm); // Pass search term for generated cards
                        } else {
                            // Fallback to symptom-based search
                            const remedies = searchRemediesBySymptoms(searchTerm);
                            renderRemedies(remedies);
                        }
                        LocalSearchHistory.add(searchTerm, 'Herbal Remedies');
                        logSearch(searchTerm, 'Herbal Remedies');
                    }
                    break;
                    
                case 'planner':
                    if (plannerSearchInput) {
                        plannerSearchInput.value = searchTerm;
                        renderCompanionInfo(searchTerm);
                        LocalSearchHistory.add(searchTerm, 'Garden Planner');
                        logSearch(searchTerm, 'Garden Planner');
                    }
                    break;
            }
        };
        
        // Navigate if needed, then execute search
        if (needsNavigation) {
            showPage(pageId);
            setTimeout(executeSearch, 450);
        } else {
            executeSearch();
        }
    };


    // --- UTILITY FUNCTIONS ---
    function createHerbCardHTML(herb) {
        return `
            <div data-id="${herb.id}" class="herb-card bg-white rounded-2xl soft-shadow cursor-pointer overflow-hidden fade-in-on-scroll">
                <img src="${herb.image}" alt="${herb.name}" class="w-full h-48 object-cover" 
                    onerror="this.onerror=null;this.src='https://placehold.co/400x400/cbd5e1/475569?text=Image+Not+Found';">
                <div class="p-6">
                    <div class="flex items-center justify-between">
                        <h3 class="text-xl font-bold mb-1">${herb.name}</h3>
                        <button aria-label="Listen to plant name" title="Listen" data-id="${herb.id}" class="speak-btn p-2 rounded-md text-gray-600 hover:text-green-700 transition-colors">
                            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.3-2.5-4.04v8.08c1.48-.74 2.5-2.27 2.5-4.04zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/></svg>
                        </button>
                    </div>
                    <p class="text-sm italic mb-4" style="color: var(--text-light);">${herb.botanicalName}</p>
                    <div class="flex items-center space-x-2 text-sm" style="color: var(--sage-green-medium);">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 005.9 21.21c1.986.72 4.153 1.082 6.096.793a12.02 12.02 0 006.104-.793c1.727-1.125 2.584-2.822 2.766-4.524a12.03 12.03 0 00-.008-.946z"></path></svg>
                        <span>${herb.medicinalUses[0]}</span>
                    </div>
                    <button data-id="${herb.id}" class="modern-btn mt-4 w-full text-sm font-semibold py-2 px-4 rounded-full">View Details</button>
                </div>
            </div>
        `;
    }

    function createModalContentHTML(herb) {
        const ageSuggestionsHtml = Object.entries(herb.ageGroupSuggestions).map(([key, value]) => {
            const ageRange = key.replace('ages_', '').replace('_', '-').toUpperCase();
            return `
                <div class="p-3 rounded-lg" style="background-color: var(--soft-gray);">
                    <h4 class="font-semibold text-sm mb-1" style="color: var(--sage-green-dark);">${ageRange}</h4>
                    <p class="text-xs" style="color: var(--text-dark);">${value}</p>
                </div>
            `;
        }).join('');

        return `
            <div class="p-8">
                <div class="flex justify-end items-center mb-4 space-x-2">
                    <button aria-label="Listen to plant name in modal" title="Listen" data-id="${herb.id}" class="speak-btn p-2 rounded-md text-gray-600 hover:text-green-700 transition-colors">
                        <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.3-2.5-4.04v8.08c1.48-.74 2.5-2.27 2.5-4.04zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/></svg>
                    </button>
                    <button id="close-modal" class="text-gray-500 hover:text-gray-900">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                </div>
                
                <h2 class="text-4xl font-bold mb-2">${herb.name}</h2>
                <p class="text-lg italic mb-6" style="color: var(--sage-green-medium);">${herb.botanicalName}</p>
                
                <img src="${herb.image}" alt="${herb.name}" class="w-full h-64 object-cover rounded-xl mb-6 soft-shadow" 
                    onerror="this.onerror=null;this.src='https://placehold.co/800x400/cbd5e1/475569?text=Image+Not+Found';">
                
                <h3 class="text-2xl font-semibold mb-4">About the Plant</h3>
                <p class="leading-relaxed mb-8" style="color: var(--text-dark);">${herb.aboutPlant}</p>
                
                <div class="grid md:grid-cols-2 gap-6 mb-8">
                    <div>
                        <h3 class="text-2xl font-semibold mb-3">Medicinal Uses</h3>
                        <ul class="list-disc pl-5 space-y-2" style="color: var(--text-dark);">
                            ${herb.medicinalUses.map(use => `<li>${use}</li>`).join('')}
                        </ul>
                    </div>
                    <div>
                        <h3 class="text-2xl font-semibold mb-3">Culinary/Other Uses</h3>
                        <ul class="list-disc pl-5 space-y-2" style="color: var(--text-dark);">
                            ${herb.uses.map(use => `<li>${use}</li>`).join('')}
                        </ul>
                    </div>
                </div>

                <h3 class="text-2xl font-semibold mb-3">Preparation & Steps to Use</h3>
                <pre class="whitespace-pre-wrap p-4 rounded-xl mb-8 border-l-4" style="background-color: var(--soft-gray); border-color: var(--sage-green-light); color: var(--text-dark);">${herb.stepsToUse}</pre>

                <h3 class="text-2xl font-semibold mb-3">Age Group Suggestions</h3>
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    ${ageSuggestionsHtml}
                </div>
                
                <div class="p-4 rounded-lg soft-shadow" style="background-color: var(--off-white); border-left: 4px solid var(--sage-green-dark);">
                    <p class="font-semibold" style="color: var(--sage-green-dark);">Fun Fact:</p>
                    <p class="italic" style="color: var(--sage-green-medium);">${herb.funFact}</p>
                </div>
            </div>
        `;
    }

    // --- TEXT-TO-SPEECH: Speak only the primary and botanical name ---
    function speakPlant(herb) {
        if (!herb) return;

        // Cancel any ongoing speech
        if (window.speechSynthesis && window.speechSynthesis.speaking) {
            try { window.speechSynthesis.cancel(); } catch (e) { /* ignore */ }
        }

        const primary = (herb.name || '').toString().trim();
        const botanical = (herb.botanicalName || '').toString().trim();

        if (!primary && !botanical) return;

        const synth = window.speechSynthesis;
        if (!synth) return; // not supported

        const voices = synth.getVoices();
        // Prefer an English voice if available
        let voice = voices.find(v => /en(-|_)?/i.test(v.lang)) || voices.find(v => v.lang === 'en-US') || voices[0];

        const speakText = (text, options = {}) => {
            const u = new SpeechSynthesisUtterance(text);
            if (voice) u.voice = voice;
            u.rate = options.rate ?? 0.96;
            u.pitch = options.pitch ?? 1.0;
            u.volume = 1.0;
            if (options.lang) u.lang = options.lang;
            return u;
        };

        // Create utterances for primary and botanical only — no extra words
        const primaryUtterance = speakText(primary);
        const botanicalUtterance = speakText(botanical);

        // Chain them: after primary ends, speak botanical (if present)
        primaryUtterance.onend = () => {
            if (botanical) {
                // small pause before botanical
                setTimeout(() => synth.speak(botanicalUtterance), 180);
            }
        };

        synth.speak(primaryUtterance);
    }
    
    function renderCompanionInfo(searchTerm) {
        const name = searchTerm.toLowerCase().replace(/[^a-z]/g, '').trim(); 

        const herbKeys = Object.keys(companionData).map(key => ({
            original: key,
            cleaned: key.toLowerCase().replace(/[^a-z]/g, '').trim()
        }));
        
        const matchingKey = herbKeys.find(key => key.cleaned.includes(name));
        const data = matchingKey ? companionData[matchingKey.original] : null;
        
        const fullHerbData = herbData.find(h => h.name.toLowerCase() === matchingKey?.original.toLowerCase());

        if (data) {
            const goodList = data.good.map(plant => `<li class="flex items-center space-x-2 text-green-700 font-semibold"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg><span>${plant}</span></li>`).join('');
            const badList = data.bad.map(plant => `<li class="flex items-center space-x-2 text-red-700 font-semibold"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg><span>${plant}</span></li>`).join('');

            companionResult.innerHTML = `
                <h3 class="text-3xl font-bold mb-2">${matchingKey.original}</h3>
                ${fullHerbData ? `<p class="italic mb-6 text-lg" style="color: var(--sage-green-medium);">${fullHerbData.botanicalName}</p>` : ''}
                
                <div class="grid md:grid-cols-2 gap-10">
                    <div>
                        <h4 class="text-2xl font-semibold mb-4" style="color: var(--sage-green-dark);"><span class="text-green-600">✅</span> Good Companions</h4>
                        <ul class="space-y-3 pl-0">${goodList}</ul>
                        <p class="mt-4 text-sm text-gray-500">These plants support ${matchingKey.original}'s growth, deter pests, or improve flavor.</p>
                    </div>
                    <div>
                        <h4 class="text-2xl font-semibold mb-4" style="color: var(--sage-green-dark);"><span class="text-red-600">🚫</span> Bad Companions</h4>
                        <ul class="space-y-3 pl-0">${badList}</ul>
                        <p class="mt-4 text-sm text-gray-500">These plants compete for resources or attract pests that harm ${matchingKey.original}.</p>
                    </div>
                </div>
            `;
        } else {
            companionResult.innerHTML = `
                <div class="text-center p-12">
                    <svg class="w-12 h-12 mx-auto mb-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    <p class="text-xl text-gray-600">No companion data found for "${searchTerm}".</p>
                    <p class="text-sm text-gray-400 mt-2">Try searching for Basil, Rosemary, or Mint.</p>
                </div>
            `;
        }
    }

    function setupScrollAnimations() {
        const animatedElements = document.querySelectorAll('.fade-in-on-scroll');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                }
            });
        }, { threshold: 0.1 });
        animatedElements.forEach(el => {
            observer.observe(el);
        });
    }

    function showModal(herb) {
        modalContent.innerHTML = createModalContentHTML(herb);
        modal.classList.remove('hidden');
        document.body.style.overflow = 'hidden';

        document.getElementById('close-modal').addEventListener('click', () => hideModal(modal));
    }

    function hideModal(modalElement) {
        if (modalElement) {
            modalElement.classList.add('hidden');
        }
        document.body.style.overflow = 'auto';
    }


    // --- NEW REMEDIES FUNCTIONS ---

    // Create detailed remedy card for generated remedies (with full info)
    function createGeneratedRemedyCardHTML(remedy, cardNumber) {
        return `
            <div class="remedy-card bg-white rounded-2xl soft-shadow overflow-hidden fade-in-on-scroll">
                <!-- Card Header with Number Badge -->
                <div class="relative">
                    <img src="${remedy.image}" alt="${remedy.name}" class="w-full h-48 object-cover" 
                        onerror="this.onerror=null;this.src='https://placehold.co/400x300/cbd5e1/475569?text=Herbal+Remedy';">
                    <div class="absolute top-4 left-4">
                        <span class="px-3 py-1 rounded-full text-sm font-bold" style="background-color: var(--sage-green-dark); color: white;">
                            Remedy ${cardNumber}
                        </span>
                    </div>
                </div>
                
                <div class="p-6">
                    <!-- Remedy Title -->
                    <h3 class="text-xl font-bold mb-2" style="color: var(--sage-green-dark);">${remedy.name}</h3>
                    <p class="text-sm mb-4" style="color: var(--text-light);">For: ${remedy.ailment.join(', ')}</p>
                    
                    <!-- Plant Names Section -->
                    <div class="mb-4">
                        <p class="text-sm font-semibold mb-2 flex items-center gap-2" style="color: var(--sage-green-dark);">
                            <span>🌿</span> Plants Used:
                        </p>
                        <div class="flex flex-wrap gap-2">
                            ${remedy.herbs.map(herb => 
                                `<span class="text-sm font-medium px-3 py-1 rounded-full border-2" style="border-color: var(--sage-green-medium); color: var(--sage-green-dark); background-color: var(--sage-green-light);">${herb}</span>`
                            ).join('')}
                        </div>
                    </div>
                    
                    <!-- Preparation Method -->
                    <div class="mb-4 p-4 rounded-xl" style="background-color: var(--off-white); border-left: 4px solid var(--sage-green-medium);">
                        <p class="text-sm font-semibold mb-2 flex items-center gap-2" style="color: var(--sage-green-dark);">
                            <span>📋</span> Preparation Method:
                        </p>
                        <p class="text-sm leading-relaxed" style="color: var(--text-dark);">${remedy.preparation}</p>
                    </div>
                    
                    <!-- Usage Instructions -->
                    <div class="mb-4 p-4 rounded-xl" style="background-color: #e8f5e9; border-left: 4px solid #4caf50;">
                        <p class="text-sm font-semibold mb-2 flex items-center gap-2" style="color: #2e7d32;">
                            <span>💊</span> How to Use:
                        </p>
                        <p class="text-sm leading-relaxed" style="color: var(--text-dark);">${remedy.usage}</p>
                    </div>
                    
                    <!-- Benefits -->
                    <div class="mb-4 p-4 rounded-xl" style="background-color: #fff8e1; border-left: 4px solid #ffc107;">
                        <p class="text-sm font-semibold mb-2 flex items-center gap-2" style="color: #f57f17;">
                            <span>✨</span> Benefits:
                        </p>
                        <p class="text-sm leading-relaxed" style="color: var(--text-dark);">${remedy.benefits}</p>
                    </div>
                    
                    <!-- Precautions -->
                    <div class="p-4 rounded-xl" style="background-color: #ffebee; border-left: 4px solid #f44336;">
                        <p class="text-sm font-semibold mb-2 flex items-center gap-2" style="color: #c62828;">
                            <span>⚠️</span> Precautions:
                        </p>
                        <p class="text-sm leading-relaxed" style="color: var(--text-dark);">${remedy.precautions}</p>
                    </div>
                </div>
            </div>
        `;
    }

    // Original simple remedy card (for default view)
    function createRemedyCardHTML(remedy) {
        return `
            <div data-id="${remedy.id}" class="remedy-card bg-white rounded-2xl soft-shadow overflow-hidden fade-in-on-scroll">
                <img src="${remedy.image}" alt="${remedy.name}" class="w-full h-40 object-cover" 
                    onerror="this.onerror=null;this.src='https://placehold.co/400x400/cbd5e1/475569?text=Image+Not+Found';">
                <div class="p-6">
                    <h3 class="text-xl font-bold mb-2">${remedy.name}</h3>
                    <div class="flex flex-wrap gap-2 mb-4">
                        ${remedy.herbs.map(herb => 
                            `<span class="text-xs font-medium px-3 py-1 rounded-full" style="background-color: var(--soft-gray); color: var(--sage-green-dark);">${herb}</span>`
                        ).join('')}
                    </div>
                    <div class="bg-slate-50 p-3 rounded-lg mb-4 border-l-4 border-sage-green-medium">
                        <p class="text-sm text-gray-700 leading-relaxed">${remedy.description}</p>
                    </div>
                    <div class="flex items-center space-x-2 text-sm mb-4" style="color: var(--sage-green-medium);">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                        <span>Targets: ${remedy.ailment.join(', ')}</span>
                    </div>
                    <button data-id="${remedy.id}" class="modern-btn-small w-full text-sm font-semibold py-2 px-4 rounded-full">View Preparation</button>
                </div>
            </div>
        `;
    }

    // Updated renderRemedies to handle disease search with 3 generated cards
    function renderRemedies(remediesOrSearchTerm) {
        if (!remediesContainer) return;
        remediesContainer.innerHTML = '';
        
        // Check if it's a string (disease search) or array (filtered remedies)
        if (typeof remediesOrSearchTerm === 'string' && remediesOrSearchTerm.trim().length > 0) {
            // Try to generate 3 remedies for the disease
            const generated = generateDiseaseRemedies(remediesOrSearchTerm);
            
            if (generated && generated.remedies && generated.remedies.length > 0) {
                // Show disease header
                remediesContainer.innerHTML = `
                    <div class="col-span-full mb-6">
                        <div class="text-center p-6 rounded-2xl" style="background: linear-gradient(135deg, var(--sage-green-light), var(--off-white));">
                            <h2 class="text-2xl font-bold mb-2" style="color: var(--sage-green-dark);">
                                🌿 3 Herbal Remedies for "${capitalizeFirst(generated.disease)}"
                            </h2>
                            <p class="text-sm" style="color: var(--text-light);">
                                Each remedy uses different plant combinations for effective natural treatment
                            </p>
                        </div>
                    </div>
                `;
                
                // Render all 3 generated remedy cards
                generated.remedies.forEach((remedy, index) => {
                    remediesContainer.innerHTML += createGeneratedRemedyCardHTML(remedy, index + 1);
                });
                
                // Add disclaimer
                remediesContainer.innerHTML += `
                    <div class="col-span-full mt-6">
                        <div class="p-4 rounded-xl text-center" style="background-color: #fff3cd; border: 1px solid #ffc107;">
                            <p class="text-sm" style="color: #856404;">
                                <strong>⚠️ Important:</strong> These remedies are based on traditional herbal medicine. 
                                Always consult a qualified healthcare professional before starting any herbal treatment, 
                                especially if you're pregnant, nursing, have medical conditions, or are taking medications.
                            </p>
                        </div>
                    </div>
                `;
                
                setupScrollAnimations();
                return;
            }
        }
        
        // Handle array of remedies (from old search or default view)
        const remedies = Array.isArray(remediesOrSearchTerm) ? remediesOrSearchTerm : [];
        
        if (remedies.length === 0) {
            // Try disease search as fallback for empty results
            if (typeof remediesOrSearchTerm === 'string' && remediesOrSearchTerm.trim().length > 0) {
                const generated = generateDiseaseRemedies(remediesOrSearchTerm);
                if (generated && generated.remedies) {
                    renderRemedies(remediesOrSearchTerm);
                    return;
                }
            }
            remediesContainer.innerHTML = `
                <div class="col-span-full text-center py-12">
                    <div class="text-6xl mb-4">🔍</div>
                    <p class="text-slate-500 text-lg mb-2">No remedies found for your search.</p>
                    <p class="text-slate-400 text-sm">Try searching for common conditions like: cold, headache, anxiety, digestion, stress, insomnia, fever, etc.</p>
                </div>
            `;
            return;
        }
        
        // Render regular remedy cards
        remedies.forEach(remedy => {
            remediesContainer.innerHTML += createRemedyCardHTML(remedy);
        });
        setupScrollAnimations();
    }
    
    // Helper function for capitalizing (available in scope)
    function capitalizeFirst(str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
    }

    function showRemedyModal(remedyId) {
        const remedy = remedyData.find(r => r.id === remedyId);
        showRemedyModalEnhanced(remedyId, remedy?.ailment?.[0] || '');
    }


    // --- CORE FUNCTIONS ---
    function showPage(pageId) {
        const activePage = document.querySelector('.page-content:not(.hidden)');
        if (activePage) {
            activePage.classList.add('page-fade-out');
        }

        setTimeout(() => {
            if (activePage) {
                activePage.classList.add('hidden');
                activePage.classList.remove('page-fade-out');
            }

            pageContents.forEach(page => {
                const isTargetPage = page.id === `page-${pageId}`;
                if (isTargetPage) {
                    page.classList.remove('hidden');
                    setTimeout(() => page.classList.add('page-fade-in'), 10);
                } else {
                    page.classList.add('hidden');
                    page.classList.remove('page-fade-in');
                }
            });
            setupScrollAnimations();
        }, 400);

        navLinks.forEach(link => {
            link.classList.toggle('active', link.dataset.page === pageId);
        });

        mobileMenu.classList.add('hidden');
        window.scrollTo(0, 0);
        
        if (pageId === 'planner' && plannerSearchInput && companionResult.innerHTML.includes('Search for an herb above')) {
             companionResult.innerHTML = `<p class="text-center text-xl text-gray-500 mt-0">Search for an herb above to view its companion planting recommendations.</p>`;
        }
    }

    function renderGarden(herbs, isSearch = false) {
        gardenContainer.innerHTML = '';
        if (herbs.length === 0) {
            gardenContainer.innerHTML = `<p class="text-slate-500 text-center col-span-full">No herbs found matching your search.</p>`;
            return;
        }
        const cardsHtml = herbs.map((herb) => {
            return createHerbCardHTML(herb).replace(
                'herb-card bg-white rounded-2xl soft-shadow cursor-pointer overflow-hidden fade-in-on-scroll',
                `herb-card bg-white rounded-2xl soft-shadow cursor-pointer overflow-hidden${isSearch ? '' : ' fade-in-on-scroll'}`
            );
        }).join('');
        gardenContainer.innerHTML = cardsHtml;
    }

    function renderTour(herbsToRender = herbData) {
        if (!tourContent) return;
        
        // Filter strictly for valid 3D models
        const valid3DHerbs = herbsToRender.filter(herb => {
            return herb.model3d && 
                   typeof herb.model3d === 'string' && 
                   herb.model3d.trim() !== '' &&
                   !herb.model3d.endsWith('.mp4') && // No videos
                   !herb.model3d.includes('YOUR_DIRECT_GLB_URL_HERE'); // No placeholders
        });

        tourContent.innerHTML = '';
        
        if (valid3DHerbs.length === 0) {
            tourContent.innerHTML = `<p class="text-slate-500 text-center col-span-full">No 3D plants available.</p>`;
            return;
        }

        valid3DHerbs.forEach(herb => {
            const tourSection = document.createElement('section');
            tourSection.id = `tour-stop-${herb.id}`;
            tourSection.className = 'flex flex-col md:flex-row gap-10 items-center fade-in-on-scroll';
            
            tourSection.innerHTML = `
                <div class="md:w-1/2 w-full h-[500px]">
                    <model-viewer class="soft-shadow w-full h-full rounded-xl" src="${herb.model3d}" alt="${herb.name} 3D Model" shadow-intensity="1" 
                        camera-controls touch-action="none" auto-rotate ar ar-modes="webxr scene-viewer quick-look" shadow-intensity="1" style="background-color: #f5f5f5;">
                    </model-viewer>
                </div>
                <div class="md:w-1/2 w-full text-center md:text-left pl-8">
                    <h3 class="text-3xl font-bold">${herb.name}</h3>
                    <p class="text-md italic mb-4" style="color: var(--text-light);">${herb.botanicalName}</p>
                    <p class="leading-relaxed mb-4" style="color: var(--text-light);">${herb.aboutPlant}</p>
                    <div class="p-4 rounded-lg mb-6" style="background-color: var(--off-white); border-left: 4px solid var(--sage-green-light);">
                        <p class="font-semibold" style="color: var(--sage-green-dark);">Did you know?</p>
                        <p class="italic" style="color: var(--sage-green-medium);">${herb.funFact}</p>
                    </div>
                    <button data-id="${herb.id}" class="w-full md:w-auto text-center modern-btn font-bold py-3 px-6 rounded-full shadow-md"> View Full Details </button>
                </div>
            `;
            tourContent.appendChild(tourSection);
        });
        
        setupScrollAnimations();
    }

    function renderHerbOfTheDay() {
        if (!herbOfTheDayContainer || herbData.length === 0) return;
        const randomIndex = Math.floor(Math.random() * herbData.length);
        const herb = herbData[randomIndex];
        herbOfTheDayContainer.innerHTML = `
            <div class="bg-white rounded-2xl soft-shadow cursor-pointer overflow-hidden p-6" data-id="${herb.id}">
                <img src="${herb.image}" alt="${herb.name}" class="w-full h-56 object-cover rounded-xl mb-4" onerror="this.onerror=null;this.src='https://placehold.co/400x400/cbd5e1/475569?text=Image+Not+Found';">
                <h3 class="text-2xl font-semibold">${herb.name}</h3>
                <p class="text-sm italic mb-2" style="color: var(--text-light);">${herb.botanicalName}</p>
                <p class="mb-4" style="color: var(--text-light);">${herb.medicinalUses[0]}</p>
                <button data-id="${herb.id}" class="font-semibold transition-colors" style="color: var(--sage-green-medium);">Learn More &rarr;</button>
            </div>
        `;
    }

    function renderTourSuggestions(searchTerm) {
        if (!tourSuggestionsContainer) return;
        
        if (searchTerm.length < 2) {
            tourSuggestionsContainer.innerHTML = '';
            tourSuggestionsContainer.classList.add('hidden');
            return;
        }

        const lowerSearchTerm = searchTerm.toLowerCase();
        const suggestions = herbData.filter(herb => 
            herb.name.toLowerCase().includes(lowerSearchTerm) || 
            herb.botanicalName.toLowerCase().includes(lowerSearchTerm)
        ).slice(0, 5); 

        if (suggestions.length === 0) {
            tourSuggestionsContainer.innerHTML = '<div class="suggestion-item" style="cursor: default; color: var(--text-light);">No suggestions found.</div>';
            tourSuggestionsContainer.classList.remove('hidden');
            return;
        }

        tourSuggestionsContainer.innerHTML = suggestions.map(herb => 
            `<div class="suggestion-item" data-name="${herb.name}">${herb.name} <span class="text-xs italic" style="color: var(--text-light);">(${herb.botanicalName})</span></div>`
        ).join('');
        
        tourSuggestionsContainer.classList.remove('hidden');

        tourSuggestionsContainer.querySelectorAll('.suggestion-item').forEach(item => {
            item.addEventListener('click', () => {
                const selectedName = item.dataset.name;
                tourSearchInput.value = selectedName;
                
                const filteredHerbs = herbData.filter(herb => herb.name === selectedName);
                renderTour(filteredHerbs); 
                
                tourSuggestionsContainer.classList.add('hidden');
            });
        });
    }

    // --- EVENT LISTENERS ---
    // Navigation (handle all [data-page] links, including CTAs on home/footer)
    document.querySelectorAll('a[data-page]').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const target = e.currentTarget;
            showPage(target.dataset.page);
        });
    });

    // Mobile menu toggle
    mobileMenuButton.addEventListener('click', () => {
        mobileMenu.classList.toggle('hidden');
    });

    // Herb Card, Button, and Remedy Button Clicks (Delegation)
    mainContent.addEventListener('click', (e) => {
        // 0. Handle speaker button clicks (TTS) — must run before opening modal
        const speakBtn = e.target.closest('.speak-btn');
        if (speakBtn && speakBtn.dataset.id) {
            e.stopPropagation();
            const id = parseInt(speakBtn.dataset.id);
            const herb = herbData.find(h => h.id === id);
            if (herb) {
                speakPlant(herb);
            }
            return;
        }

        // 1. Handle Herb/Tour Card Clicks (modern-btn, herb-card, etc.)
        const herbCard = e.target.closest('.herb-card') || e.target.closest('#herb-of-the-day div');
        const tourButton = e.target.closest('#page-tour button');
        
        if (herbCard || tourButton) {
            const id = parseInt(herbCard?.dataset.id || tourButton?.dataset.id || e.target.dataset.id);
            const herb = herbData.find(h => h.id === id);
            if (herb) {
                if (!isAuthenticated()) {
                    openAuthModal();
                    return;
                }
                showModal(herb);
                return;
            }
        }
        
        // 2. Handle Remedy Button Clicks (modern-btn-small)
        const remedyButton = e.target.closest('.modern-btn-small');
        if (remedyButton && remedyButton.dataset.id) {
            const remedyId = parseInt(remedyButton.dataset.id);
            showRemedyModal(remedyId);
        }
    });

    // Modal close behavior
    modal.addEventListener('click', (e) => {
        if (e.target.id === 'close-modal' || e.target.closest('#close-modal') || e.target.id === 'herb-modal') {
            hideModal(modal);
        }
    });
    window.addEventListener('keydown', (e) => { 
        if (e.key === 'Escape' && !modal.classList.contains('hidden')) hideModal(modal); 
    });

    // Header scroll effect
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            header.classList.add('header-scrolled');
        } else {
            header.classList.remove('header-scrolled');
        }
    });


    // Search functionality for The Garden
    if (searchInput) {
        let searchTimeout;
        
        searchInput.addEventListener('focus', () => {
            LocalSearchHistory.show(searchInput, 'Garden');
        });
        
        searchInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                const searchTerm = searchInput.value.trim();
                if (searchTerm.length > 0) {
                    LocalSearchHistory.hide(searchInput);
                    window.showPageAndSearch('garden', searchTerm);
                }
            }
        });
        
        searchInput.addEventListener('input', (e) => {
            const searchTerm = e.target.value.toLowerCase();
            // Use symptom-based search instead of letter matching
            const filteredHerbs = searchHerbsBySymptoms(searchTerm);
            renderGarden(filteredHerbs, true);
            
            // Log search after user stops typing (debounce)
            if (searchTerm.trim().length > 0) {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(() => {
                    LocalSearchHistory.add(searchTerm, 'Garden');
                    logSearch(searchTerm, 'Garden');
                }, 1000);
            }
        });
        
        document.addEventListener('click', (e) => {
            if (!searchInput.contains(e.target) && !e.target.closest('.history-dropdown')) {
                LocalSearchHistory.hide(searchInput);
            }
        });
    }

    // Create search index for instant search
    const createSearchIndex = (items, fields) => {
        const index = new Map();
        items.forEach(item => {
            const searchableText = fields.map(field => {
                const value = field.split('.').reduce((obj, key) => obj && obj[key], item);
                return Array.isArray(value) ? value.join(' ') : (value || '');
            }).join(' ').toLowerCase();
            
            // Create word index
            const words = searchableText.split(/\s+/);
            words.forEach(word => {
                for (let i = 1; i <= word.length; i++) {
                    const prefix = word.substring(0, i);
                    if (!index.has(prefix)) {
                        index.set(prefix, new Set());
                    }
                    index.get(prefix).add(item);
                }
            });
        });
        return index;
    };

    // Create indexes for both herbs and tour data
    const herbSearchIndex = createSearchIndex(herbData, ['name', 'botanicalName', 'funFact']);
    
    // Instant search function
    const instantSearch = (searchTerm, searchIndex, originalData) => {
        if (!searchTerm) return originalData;
        
        const terms = searchTerm.toLowerCase().trim().split(/\s+/);
        if (terms[0].length === 0) return originalData;
        
        // Get matches for the first term
        const matches = searchIndex.get(terms[0]) || new Set();
        
        // If there are multiple terms, filter further
        if (terms.length > 1) {
            return Array.from(matches).filter(item => {
                const itemText = `${item.name} ${item.botanicalName} ${item.funFact}`.toLowerCase();
                return terms.every(term => itemText.includes(term));
            });
        }
        
        return Array.from(matches);
    };

    // Search functionality for Virtual Tour (same as Garden)
    if (tourSearchInput) {
        let tourSearchTimeout;
        
        tourSearchInput.addEventListener('focus', () => {
            LocalSearchHistory.show(tourSearchInput, 'Virtual Tour');
        });
        
        tourSearchInput.addEventListener('input', (e) => {
            const searchTerm = e.target.value.toLowerCase();
            const filteredHerbs = herbData.filter(herb => 
                herb.name.toLowerCase().includes(searchTerm) || 
                herb.botanicalName.toLowerCase().includes(searchTerm) ||
                herb.funFact.toLowerCase().includes(searchTerm) ||
                (herb.medicinalUses && herb.medicinalUses.some(use => use.toLowerCase().includes(searchTerm)))
            );
            renderTourSuggestions(searchTerm);
            renderTour(filteredHerbs);
            
            // Log search after user stops typing
            if (searchTerm.trim().length > 0) {
                clearTimeout(tourSearchTimeout);
                tourSearchTimeout = setTimeout(() => {
                    LocalSearchHistory.add(searchTerm, 'Virtual Tour');
                    logSearch(searchTerm, 'Virtual Tour');
                }, 1000);
            }
        });
        
        document.addEventListener('click', (e) => {
            if (!tourSearchInput.contains(e.target) && !e.target.closest('.history-dropdown')) {
                LocalSearchHistory.hide(tourSearchInput);
            }
        });
        
        document.addEventListener('click', (e) => {
            if (tourSuggestionsContainer && !tourSearchInput.contains(e.target) && !tourSuggestionsContainer.contains(e.target)) {
                 tourSuggestionsContainer.classList.add('hidden');
            }
        });
    }
    
    // Search functionality for Garden Planner
    if (plannerSearchInput) {
        let plannerSearchTimeout;
        
        plannerSearchInput.addEventListener('focus', () => {
            LocalSearchHistory.show(plannerSearchInput, 'Garden Planner');
        });
        
        plannerSearchInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                const searchTerm = plannerSearchInput.value.trim();
                if (searchTerm.length >= 2) {
                    LocalSearchHistory.hide(plannerSearchInput);
                    window.showPageAndSearch('planner', searchTerm);
                }
            }
        });
        
        plannerSearchInput.addEventListener('input', (e) => {
            const searchTerm = e.target.value.trim();
            if (searchTerm.length >= 2) {
                renderCompanionInfo(searchTerm);
                
                // Log search
                clearTimeout(plannerSearchTimeout);
                plannerSearchTimeout = setTimeout(() => {
                    LocalSearchHistory.add(searchTerm, 'Garden Planner');
                    logSearch(searchTerm, 'Garden Planner');
                }, 1000);
            } else {
                companionResult.innerHTML = `<p class="text-center text-xl text-gray-500 mt-12">Search for an herb above to view its companion planting recommendations.</p>`;
            }
        });
        
        document.addEventListener('click', (e) => {
            if (!plannerSearchInput.contains(e.target) && !e.target.closest('.history-dropdown')) {
                LocalSearchHistory.hide(plannerSearchInput);
            }
        });
    }

    // Search functionality for Herbal Remedies - DISEASE-BASED 3 REMEDY GENERATION
    if (remediesSearchInput) {
        let remedySearchTimeout;

        remediesSearchInput.addEventListener('focus', () => {
            LocalSearchHistory.show(remediesSearchInput, 'Herbal Remedies');
        });

        remediesSearchInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                const searchTerm = remediesSearchInput.value.trim();
                if (searchTerm.length > 0) {
                    LocalSearchHistory.hide(remediesSearchInput);
                    window.showPageAndSearch('remedies', searchTerm);
                }
            }
        });

        remediesSearchInput.addEventListener('input', (e) => {
            const searchTerm = e.target.value.trim();
            
            if (searchTerm.length === 0) {
                // Show all default remedies when search is empty
                renderRemedies(remedyData);
                return;
            }
            
            // First, try to generate 3 disease-specific remedy cards
            const generated = generateDiseaseRemedies(searchTerm);
            
            if (generated && generated.remedies && generated.remedies.length > 0) {
                // Pass the search term directly to render the 3 generated cards
                renderRemedies(searchTerm);
            } else {
                // Fallback to the old symptom-based search
                const filteredRemedies = searchRemediesBySymptoms(searchTerm.toLowerCase());
                renderRemedies(filteredRemedies);
            }

            // Log search after user stops typing
            if (searchTerm.trim().length > 0) {
                clearTimeout(remedySearchTimeout);
                remedySearchTimeout = setTimeout(() => {
                    LocalSearchHistory.add(searchTerm, 'Herbal Remedies');
                    logSearch(searchTerm, 'Herbal Remedies');
                }, 1000);
            }
        });

        document.addEventListener('click', (e) => {
            if (!remediesSearchInput.contains(e.target) && !e.target.closest('.history-dropdown')) {
                LocalSearchHistory.hide(remediesSearchInput);
            }
        });
    }

    // Health Assistant Event Listener
    if (healthAssistantButton && healthAssistantInput && healthAssistantOutput) {
        healthAssistantButton.addEventListener('click', () => {
            const userInput = healthAssistantInput.value.trim();
            if (userInput) {
                const recommendation = generateHerbalRecommendation(userInput);
                healthAssistantOutput.innerHTML = `<p>${recommendation}</p>`;
            }
        });
        // Allow Enter key to trigger recommendation
        healthAssistantInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                healthAssistantButton.click();
            }
        });
    }

    // --- SYMPTOM ASSISTANT EVENT LISTENERS ---
    if (symptomAssistantBtn && symptomAssistantInput) {
        symptomAssistantBtn.addEventListener('click', () => {
            const userInput = symptomAssistantInput.value.trim();
            if (!userInput) {
                symptomAssistantResult.innerHTML = `
                    <div class="p-4 rounded-xl border-2" style="border-color: #f87171; background-color: #fef2f2;">
                        <p class="text-red-600 text-sm">Please describe your health concern first.</p>
                    </div>
                `;
                symptomAssistantResult.classList.remove('hidden');
                return;
            }
            
            // Extract symptoms and map to diseases
            const extracted = extractSymptomsFromSentence(userInput);
            
            // Find the single best matching remedy based on diseases
            const bestRemedy = findBestRemedy(extracted);
            
            // Render the result with symptoms and diseases
            renderAssistantResult(extracted, bestRemedy);
        });

        // Allow Enter key (with Ctrl/Cmd) to submit
        symptomAssistantInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                e.preventDefault();
                symptomAssistantBtn.click();
            }
        });
    }

    // Expose showRemedyDetail for the assistant "View Full Details" button
    window.showRemedyDetail = (remedyId) => {
        showRemedyModalEnhanced(remedyId, '');
    };
    
    // Intelligent Semantic Search Function - STRICT MATCHING
    // Only shows remedies that DIRECTLY match the user's search terms

    function searchRemediesBySymptoms(searchQuery) {
        const input = (searchQuery || '').toLowerCase().trim();
        if (input.length === 0) return remedyData;

        // Remove common filler words
        const fillerWords = ['i', 'have', 'am', 'having', 'got', 'need', 'want', 'please', 'help', 'fast', 'quick', 'recovery', 'relief', 'remedy', 'for', 'with', 'the', 'a', 'an', 'and', 'or', 'its', 'my', 'me', 'been', 'feeling', 'feel', 'like', 'some', 'get', 'any'];
        
        // Extract meaningful search terms (only words 3+ characters that aren't filler)
        const searchWords = input.split(/[\s,?!.;:–\-\n]+/)
            .filter(t => t.length >= 3 && !fillerWords.includes(t));

        // If no meaningful terms, show all
        if (searchWords.length === 0) return remedyData;

        // Find remedies that DIRECTLY match the search terms in their ailments ONLY
        const results = [];
        
        remedyData.forEach(remedy => {
            let matchScore = 0;
            const matchedAilmentsForRemedy = [];
            
            // Only check ailments - no fuzzy matching
            remedy.ailment.forEach(ailment => {
                const ailmentLower = ailment.toLowerCase();
                
                searchWords.forEach(searchWord => {
                    // STRICT: ailment must contain the exact search word
                    // "cold" matches "Cold" ✓
                    // "cold" does NOT match "Stress" or "Anxiety" ✗
                    if (ailmentLower.includes(searchWord)) {
                        matchScore += 100;
                        if (!matchedAilmentsForRemedy.includes(ailment)) {
                            matchedAilmentsForRemedy.push(ailment);
                        }
                    }
                });
            });

            // Only include remedies with DIRECT ailment match
            if (matchScore > 0) {
                results.push({
                    ...remedy,
                    matchScore,
                    matchedAilments: matchedAilmentsForRemedy
                });
            }
        });

        // If no results found, return empty (not all remedies)
        if (results.length === 0) {
            return [];
        }

        // Sort by score and return
        return results.sort((a, b) => b.matchScore - a.matchScore);
    }

    // Enhanced remedy modal with detailed plant information
    function showRemedyModalEnhanced(remedyId, disease = '') {
        const remedy = remedyData.find(r => r.id === remedyId);
        if (!remedy) return;

        // Generate detailed herb benefits using the herbBenefitsDB
        const herbDetails = remedy.herbs.map(herbName => {
            // Get benefits from our comprehensive database
            const herbInfo = getHerbBenefitsForCondition(herbName, remedy.ailment);
            
            // Also try to get image from herbData
            const herbFromData = herbData.find(h => h.name.toLowerCase() === herbName.toLowerCase());
            
            return {
                name: herbInfo.name,
                botanical: herbInfo.botanical || (herbFromData ? herbFromData.botanicalName : ''),
                benefits: herbInfo.benefits,
                image: herbFromData ? herbFromData.image : ''
            };
        });

        const herbDetailsHtml = herbDetails.map(herb => `
            <div class="p-4 rounded-xl mb-4" style="background-color: var(--soft-gray); border-left: 4px solid var(--sage-green-medium);">
                <div class="flex items-start gap-3">
                    <div class="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0" style="background-color: var(--sage-green-light);">
                        <svg class="w-5 h-5" style="color: var(--sage-green-dark);" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"/>
                        </svg>
                    </div>
                    <div class="flex-1">
                        <h4 class="font-bold text-lg" style="color: var(--sage-green-dark);">${herb.name}</h4>
                        ${herb.botanical ? `<p class="italic text-sm mb-2" style="color: var(--sage-green-medium);">${herb.botanical}</p>` : ''}
                        <p class="text-sm leading-relaxed" style="color: var(--text-dark);">
                            <strong>Benefits for ${remedy.ailment[0]}:</strong><br>
                            ${herb.benefits}
                        </p>
                    </div>
                </div>
            </div>
        `).join('');

        const html = `
            <div class="p-8">
                <div class="flex justify-end mb-4">
                    <button id="close-modal" class="text-gray-500 hover:text-gray-900">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                </div>
                
                <h2 class="text-4xl font-bold mb-2">${remedy.name}</h2>
                <p class="text-lg mb-6" style="color: var(--sage-green-medium);">For: ${remedy.ailment.join(', ')}</p>
                
                <img src="${remedy.image}" alt="${remedy.name}" class="w-full h-64 object-cover rounded-xl mb-6 soft-shadow" 
                    onerror="this.onerror=null;this.src='https://placehold.co/800x400/cbd5e1/475569?text=Image+Not+Found';">
                
                <h3 class="text-2xl font-semibold mb-4">Why This Combination Works</h3>
                <p class="leading-relaxed mb-8" style="color: var(--text-dark);">${remedy.description}</p>
                
                <h3 class="text-2xl font-semibold mb-6">🌿 Medicinal Plants & How They Help</h3>
                <div class="mb-8">
                    ${herbDetailsHtml}
                </div>

                <h3 class="text-2xl font-semibold mb-3">📋 Preparation & Usage</h3>
                <pre class="whitespace-pre-wrap p-4 rounded-xl mb-8 border-l-4" style="background-color: var(--soft-gray); border-color: var(--sage-green-light); color: var(--text-dark);">${remedy.preparation}</pre>
                
                <div class="p-4 rounded-lg" style="background-color: #fff3cd; border-left: 4px solid #ffc107; color: #856404;">
                    <p class="font-semibold mb-2">⚠️ Important Notice:</p>
                    <p class="text-sm">Always consult a qualified healthcare professional before starting any herbal remedy, especially if you're pregnant, nursing, or taking medications.</p>
                </div>
            </div>
        `;

        modalContent.innerHTML = html;
        modal.classList.remove('hidden');
        document.body.style.overflow = 'hidden';

        document.getElementById('close-modal').addEventListener('click', () => hideModal(modal));
    }


    // INITIAL APP RENDERING
    renderGarden(herbData);
    renderTour();
    renderRemedies(remedyData);
    renderHerbOfTheDay();
    setupScrollAnimations();
};


// --- AUTHENTICATION SYSTEM ---

const API_BASE_URL = 'http://localhost:3000/api';
const SESSION_KEY = 'hg_current_user_v1';

function setCurrentUser(user) {
    if (user) localStorage.setItem(SESSION_KEY, JSON.stringify({ email: user.email, username: user.username }));
    else localStorage.removeItem(SESSION_KEY);
}
function getCurrentUser() {
    try { return JSON.parse(localStorage.getItem(SESSION_KEY)); } catch { return null; }
}
function isAuthenticated() { return !!getCurrentUser(); }

async function logSearch(query, searchType) {
    const user = getCurrentUser();
    try {
        await fetch(`${API_BASE_URL}/search-history`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                user_id: user?.id || null,
                username: user?.username || 'Guest',
                search_query: query,
                search_type: searchType
            })
        });
    } catch (error) {
        console.error('Failed to log search:', error);
    }
}

function openAuthModal(defaultTab = 'login') {
    const modal = document.getElementById('auth-modal');
    if (!modal) return;
    modal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
    switchAuthTab(defaultTab);
}
function closeAuthModal() {
    const modal = document.getElementById('auth-modal');
    if (!modal) return;
    modal.classList.add('hidden');
    document.body.style.overflow = 'auto';
    const err = document.getElementById('auth-error');
    if (err) { err.classList.add('hidden'); err.textContent = ''; }
}
function switchAuthTab(tab) {
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const tabLogin = document.getElementById('tab-login');
    const tabRegister = document.getElementById('tab-register');
    if (!loginForm || !registerForm || !tabLogin || !tabRegister) return;
    const loginActive = tab === 'login';
    loginForm.classList.toggle('hidden', !loginActive);
    registerForm.classList.toggle('hidden', loginActive);
    tabLogin.classList.toggle('bg-gray-100', loginActive);
    tabRegister.classList.toggle('bg-gray-100', !loginActive);
}

function updateProfileUI() {
    const user = getCurrentUser();
    const label = document.getElementById('profile-label');
    const dropdown = document.getElementById('profile-dropdown');
    const authSection = document.getElementById('profile-auth-section');
    const userSection = document.getElementById('profile-user-section');
    const usernameEl = document.getElementById('profile-username');
    if (label) label.textContent = user ? user.username : 'Profile';
    if (authSection && userSection) {
        if (user) {
            authSection.classList.add('hidden');
            userSection.classList.remove('hidden');
            if (usernameEl) usernameEl.textContent = user.username;
        } else {
            authSection.classList.remove('hidden');
            userSection.classList.add('hidden');
        }
    }
    if (dropdown) dropdown.classList.add('hidden');
}

document.addEventListener('DOMContentLoaded', () => {
    initializeApp();

    const profileButton = document.getElementById('profile-button');
    const profileDropdown = document.getElementById('profile-dropdown');
    const openAuthBtn = document.getElementById('open-auth-modal');
    const openAuthBtnMobile = document.getElementById('open-auth-modal-mobile');
    const authClose = document.getElementById('auth-close');
    const tabLogin = document.getElementById('tab-login');
    const tabRegister = document.getElementById('tab-register');
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const logoutButton = document.getElementById('logout-button');

    updateProfileUI();

    if (profileButton && profileDropdown) {
        profileButton.addEventListener('click', () => {
            profileDropdown.classList.toggle('hidden');
        });
        document.addEventListener('click', (e) => {
            if (!profileDropdown.contains(e.target) && !profileButton.contains(e.target)) {
                profileDropdown.classList.add('hidden');
            }
        });
    }
    if (openAuthBtn) openAuthBtn.addEventListener('click', () => openAuthModal('login'));
    if (openAuthBtnMobile) openAuthBtnMobile.addEventListener('click', () => openAuthModal('login'));
    if (authClose) authClose.addEventListener('click', closeAuthModal);

    if (tabLogin) tabLogin.addEventListener('click', () => switchAuthTab('login'));
    if (tabRegister) tabRegister.addEventListener('click', () => switchAuthTab('register'));

    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('login-email').value.trim().toLowerCase();
            const password = document.getElementById('login-password').value;
            const err = document.getElementById('auth-error');
            
            try {
                const response = await fetch(`${API_BASE_URL}/login`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email, password })
                });
                
                const data = await response.json();
                
                if (!response.ok) {
                    if (err) { err.textContent = data.error || 'Login failed'; err.classList.remove('hidden'); }
                    return;
                }
                
                setCurrentUser(data.user);
                updateProfileUI();
                closeAuthModal();
            } catch (error) {
                if (err) { err.textContent = 'Server connection error. Please try again.'; err.classList.remove('hidden'); }
                console.error('Login error:', error);
            }
        });
    }
    if (registerForm) {
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const username = document.getElementById('reg-username').value.trim();
            const email = document.getElementById('reg-email').value.trim().toLowerCase();
            const password = document.getElementById('reg-password').value;
            const mobile = document.getElementById('reg-mobile').value.trim();
            const err = document.getElementById('auth-error');
            
            try {
                const response = await fetch(`${API_BASE_URL}/register`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ username, email, password, mobile })
                });
                
                const data = await response.json();
                
                if (!response.ok) {
                    if (err) { err.textContent = data.error || 'Registration failed'; err.classList.remove('hidden'); }
                    return;
                }
                
                setCurrentUser(data.user);
                updateProfileUI();
                closeAuthModal();
            } catch (error) {
                if (err) { err.textContent = 'Server connection error. Please try again.'; err.classList.remove('hidden'); }
                console.error('Registration error:', error);
            }
        });
    }
    if (logoutButton) {
        logoutButton.addEventListener('click', () => {
            setCurrentUser(null);
            updateProfileUI();
        });
    }
});