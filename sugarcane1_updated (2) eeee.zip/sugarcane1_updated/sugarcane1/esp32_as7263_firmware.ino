/*
 =============================================================================
   AI-based Sugarcane Quality Assessment & Harvest Advisory System
   ---------------------------------------------------------------------------
   esp32_as7263_firmware.ino - ESP32 High-Speed Firmware for AS7263 NIR Sensor

   Hardware Connections (ESP32 to SparkFun AS7263 NIR Sensor):
     - 3V3 / 3.3V  ->  AS7263 3V3 / VIN (DO NOT connect to 5V!)
     - GND         ->  AS7263 GND
     - GPIO 21     ->  AS7263 SDA (I2C Data)
     - GPIO 22     ->  AS7263 SCL (I2C Clock)

   Required Arduino Library:
     - SparkFun AS726X Arduino Library (Install via Arduino Library Manager:
       Tools -> Manage Libraries -> Search "SparkFun AS726X")

   Serial Output:
     - Baud Rate: 115200 baud
     - Output Rate: High Speed (~5 Hz / 200ms interval)
     - Output Format: CSV (R, S, T, U, V, W calibrated readings)
       e.g., 41.13,7.25,3.16,1.63,1.68,1.09
 =============================================================================
*/

#include <Wire.h>
#include "AS726X.h"

AS726X sensor;

// Onboard LED pin on ESP32 for read activity heartbeat
const int LED_PIN = 2;

// Fast Sampling interval (200ms = 5 readings per second for smooth live responsiveness)
const unsigned long SAMPLING_INTERVAL_MS = 200;
unsigned long lastReadTime = 0;

void setup() {
  // Initialize USB Serial at 115200 baud
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);
  
  // Wait a moment for serial connection to stabilize
  delay(500);
  Serial.println("\n[ESP32] Sugarcane Quality Assessment - AS7263 High-Speed NIR Firmware");
  Serial.println("[ESP32] Initializing I2C bus (SDA=GPIO21, SCL=GPIO22)...");

  // Initialize I2C on ESP32 default pins
  Wire.begin(21, 22);

  // Initialize AS7263 Sensor
  if (!sensor.begin(Wire)) {
    Serial.println("[ERROR] AS7263 sensor not detected!");
    Serial.println("[CHECK] 1. Verify I2C wiring (SDA->21, SCL->22, 3V3->3V3, GND->GND)");
    Serial.println("[CHECK] 2. Ensure sensor power LED is ON");
    while (1) {
      delay(1000);
      Serial.println("[WAITING] Retrying AS7263 initialization...");
      if (sensor.begin(Wire)) break;
    }
  }

  // Set sensor integration time and gain (default is robust)
  // sensor.setIntegrationTime(50); // ~140ms
  // sensor.setGain(3); // 64x gain

  Serial.println("[OK] AS7263 NIR Spectral Sensor connected successfully.");
  Serial.println("[INFO] Streaming high-frequency spectral calibrated channels (R, S, T, U, V, W)...");
}

void loop() {
  unsigned long currentTime = millis();

  if (currentTime - lastReadTime >= SAMPLING_INTERVAL_MS) {
    lastReadTime = currentTime;

    // Flash activity LED briefly
    digitalWrite(LED_PIN, HIGH);

    // Use active illumination for reflectance spectroscopy:
    // takeMeasurementsWithBulb() activates the onboard NIR illumination LED
    // during optical measurement, then powers it down.
    sensor.takeMeasurementsWithBulb();

    // Read calibrated spectral channels:
    // R = 610 nm, S = 680 nm, T = 730 nm, U = 760 nm, V = 810 nm, W = 860 nm
    float r = sensor.getCalibratedR();
    float s = sensor.getCalibratedS();
    float t = sensor.getCalibratedT();
    float u = sensor.getCalibratedU();
    float v = sensor.getCalibratedV();
    float w = sensor.getCalibratedW();

    digitalWrite(LED_PIN, LOW);

    // Print CSV line to USB Serial for Python / Web Dashboard
    Serial.print(r, 2);
    Serial.print(",");
    Serial.print(s, 2);
    Serial.print(",");
    Serial.print(t, 2);
    Serial.print(",");
    Serial.print(u, 2);
    Serial.print(",");
    Serial.print(v, 2);
    Serial.print(",");
    Serial.println(w, 2);
  }
}
