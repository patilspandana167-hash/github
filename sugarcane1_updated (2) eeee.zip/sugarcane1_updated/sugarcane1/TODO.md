# TODO - Implementation Plan for live_prediction.py

## Steps

- [x] 1. Read existing files and understand the project
- [x] 2. Create plan and get user approval
- [x] 3. Update `live_prediction.py`:
  - [x] 3a. Replace hardcoded sample with real serial port reading from ESP32
  - [x] 3b. Update harvest status messages to exact required format:
    - "READY FOR HARVEST" (Brix >= 18)
    - "NEARLY READY FOR HARVEST" (16 <= Brix < 18)
    - "NOT READY FOR HARVEST" (Brix < 16)
  - [x] 3c. Add graceful error handling (serial errors, invalid data, keyboard interrupt)
  - [x] 3d. Remove hardcoded DataFrame sample
- [x] 4. Install pyserial dependency if needed
- [x] 5. Test the script (dry run / verify syntax)

## ✅ ALL TASKS COMPLETE
