import pandas as pd
import numpy as np

np.random.seed(42)

n_sugarcane = 20
n_other = 10

# Sugarcane spectral signatures (higher NIR reflectance)
r_s = np.random.normal(3.0, 0.5, n_sugarcane)
s_s = np.random.normal(4.2, 0.6, n_sugarcane)
t_s = np.random.normal(5.1, 0.7, n_sugarcane)
u_s = np.random.normal(6.0, 0.8, n_sugarcane)
v_s = np.random.normal(5.5, 0.6, n_sugarcane)
w_s = np.random.normal(4.8, 0.5, n_sugarcane)
brix_s = np.random.uniform(14, 22, n_sugarcane)

# Other materials (lower/ different spectral signature)
r_o = np.random.normal(1.5, 0.4, n_other)
s_o = np.random.normal(2.0, 0.5, n_other)
t_o = np.random.normal(2.8, 0.5, n_other)
u_o = np.random.normal(3.2, 0.6, n_other)
v_o = np.random.normal(3.0, 0.5, n_other)
w_o = np.random.normal(2.5, 0.4, n_other)

objects = ["Sugarcane"] * n_sugarcane + ["Wood"] * 3 + ["Plastic"] * 3 + ["Leaf"] * 2 + ["Paper"] * 2
brix_other = [np.nan] * n_other

data = pd.DataFrame({
    "R": np.concatenate([r_s, r_o]),
    "S": np.concatenate([s_s, s_o]),
    "T": np.concatenate([t_s, t_o]),
    "U": np.concatenate([u_s, u_o]),
    "V": np.concatenate([v_s, v_o]),
    "W": np.concatenate([w_s, w_o]),
    "Object": objects,
    "Brix": np.concatenate([brix_s, brix_other])
})

data = data.sample(frac=1, random_state=42).reset_index(drop=True)
data.to_excel("Sugarcane_Data_Template.xlsx", index=False, engine="openpyxl")
print(f"Created Sugarcane_Data_Template.xlsx with {len(data)} samples")
print(f"  Sugarcane: {(data['Object'] == 'Sugarcane').sum()}")
print(f"  Others:    {(data['Object'] != 'Sugarcane').sum()}")

