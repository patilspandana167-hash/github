"""
=============================================================================
  AI-based Sugarcane Quality Assessment & Harvest Advisory System
  ---------------------------------------------------------------------------
  app.py - Real-Time Web Server & Live Sensor Dashboard

  Reads live spectral sensor values from ESP32 (AS7263 NIR sensor) over
  USB serial in the background with high-frequency non-blocking streaming (5Hz+),
  evaluates AI classification & Brix regression in real time, and renders
  live metrics and harvest advisory on a dashboard.
=============================================================================
"""

import os
import sys
import time
import re
import json
import threading
import datetime
import collections
import pandas as pd
import joblib
import warnings
from flask import Flask, render_template, jsonify, request

warnings.filterwarnings("ignore")

app = Flask(__name__)

# =============================================================================
#  CONFIGURATION & CONSTANTS
# =============================================================================
DEFAULT_PORT = "AUTO"       # "AUTO" or specific COM port (e.g. "COM5")
DEFAULT_BAUD = 115200       # Standard baud rate for ESP32
TIMEOUT = 0.05              # Low-latency serial read timeout (50ms)

current_serial_config = {
    "port": DEFAULT_PORT,
    "baud_rate": DEFAULT_BAUD
}

# =============================================================================
#  LOAD AI MODELS
# =============================================================================
models_loaded = False
classifier = None
brix_model = None

def load_models():
    global models_loaded, classifier, brix_model
    try:
        classifier = joblib.load("Sugarcane_Model.pkl")
        brix_model = joblib.load("Brix_Model.pkl")
        models_loaded = True
        print("[OK] Machine Learning Models (Sugarcane_Model.pkl, Brix_Model.pkl) loaded successfully.")
    except Exception as e:
        models_loaded = False
        print(f"[ERROR] Failed to load ML models: {e}")

load_models()

# =============================================================================
#  GLOBAL STATE
# =============================================================================
state_lock = threading.Lock()

latest_data = {
    "connected": False,
    "active_port": None,
    "configured_port": DEFAULT_PORT,
    "baud_rate": DEFAULT_BAUD,
    "status_message": "Scanning for ESP32 / USB Serial device...",
    "device_description": None,
    "last_updated": None,
    "last_raw_line": None,
    "sensor_values": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],  # [R, S, T, U, V, W]
    "is_sugarcane": False,
    "brix": 0.0,
    "recommendation": "Waiting for sensor data...",
    "status_code": "WAITING",  # READY, NEARLY_READY, NOT_READY, NOT_SUGARCANE, NO_SAMPLE, WAITING, ERROR
    "reading_rate": 0.0,       # Live Hz
    "total_readings": 0,
    "history": [],
    "raw_logs": []
}

reconnect_event = threading.Event()
recent_read_timestamps = collections.deque(maxlen=20)


# =============================================================================
#  UNIVERSAL SENSOR LINE PARSER
# =============================================================================
def parse_sensor_line(line: str):
    """
    Robust multi-format parser for AS7263 spectral sensor readings.
    Supports:
      1. Plain CSV: "41.13, 7.25, 3.16, 1.63, 1.68, 1.09"
      2. SparkFun AS7263 format: "Reading: R[41.13] S[7.25] T[3.16] U[1.63] V[1.68] W[1.09]"
      3. Key-Value / Labeled: "R: 41.13, S: 7.25, T: 3.16, U: 1.63, V: 1.68, W: 1.09"
      4. Space / Tab delimited: "41.13  7.25  3.16  1.63  1.68  1.09"
      5. JSON format: {"R": 41.13, "S": 7.25, "T": 3.16, "U": 1.63, "V": 1.68, "W": 1.09}
      6. Any arbitrary text containing 6 floating point values in order.
    """
    if not line:
        return None
    line = line.strip()
    if not line:
        return None

    # 1. JSON format
    if line.startswith("{") and line.endswith("}"):
        try:
            data = json.loads(line)
            keys = ["R", "S", "T", "U", "V", "W"]
            data_upper = {str(k).upper(): v for k, v in data.items()}
            if all(k in data_upper for k in keys):
                return [float(data_upper[k]) for k in keys]
        except Exception:
            pass

    # 2. Labeled pattern with R, S, T, U, V, W
    labeled_match = re.search(
        r"R[^\d\-+.]*[:=\[]?\s*([-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)[^\w]*"
        r"S[^\d\-+.]*[:=\[]?\s*([-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)[^\w]*"
        r"T[^\d\-+.]*[:=\[]?\s*([-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)[^\w]*"
        r"U[^\d\-+.]*[:=\[]?\s*([-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)[^\w]*"
        r"V[^\d\-+.]*[:=\[]?\s*([-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)[^\w]*"
        r"W[^\d\-+.]*[:=\[]?\s*([-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)",
        line,
        re.IGNORECASE
    )
    if labeled_match:
        try:
            return [float(v) for v in labeled_match.groups()]
        except ValueError:
            pass

    # 3. Comma, semicolon, or pipe delimited
    cleaned = re.sub(r"[;\s|]+", ",", line)
    parts = [p.strip() for p in cleaned.split(",") if p.strip()]
    if len(parts) == 6:
        try:
            return [float(p) for p in parts]
        except ValueError:
            pass

    # 4. Fallback: Extract all floating-point numbers from the line
    numbers = re.findall(r"[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?", line)
    valid_nums = []
    for n in numbers:
        try:
            valid_nums.append(float(n))
        except ValueError:
            pass

    if len(valid_nums) >= 6:
        return valid_nums[:6]

    return None


# =============================================================================
#  AI PREDICTION ENGINE
# =============================================================================
# Idle threshold: only trigger "NO_SAMPLE" if sensor is completely dark or zero
MIN_IDLE_SUM_THRESHOLD = 0.5


def process_prediction(values):
    """
    Evaluates spectral values [R, S, T, U, V, W] using trained multi-scale models.
    Dynamically returns:
      - is_sugarcane (bool)
      - brix (°Bx)
      - recommendation (string)
      - status_code ("READY", "NEARLY_READY", "NOT_READY", "NOT_SUGARCANE", "NO_SAMPLE", "ERROR")
    """
    if not models_loaded or classifier is None or brix_model is None:
        load_models()
        if not models_loaded:
            return {
                "sensor_values": values,
                "is_sugarcane": False,
                "brix": 0.0,
                "recommendation": "Error: ML Models not loaded",
                "status_code": "ERROR"
            }

    # 1. Optical dark / sensor idle check
    total_energy = sum(values)
    if total_energy < MIN_IDLE_SUM_THRESHOLD:
        return {
            "sensor_values": values,
            "is_sugarcane": False,
            "brix": 0.0,
            "recommendation": "SAMPLE REMOVED - Place Sugarcane on Sensor",
            "status_code": "NO_SAMPLE"
        }

    # 2. Run multi-scale Random Forest Classifier
    sample = pd.DataFrame([values], columns=["R", "S", "T", "U", "V", "W"])
    is_sugarcane = int(classifier.predict(sample.values)[0]) == 1

    if is_sugarcane:
        # Run Brix Regressor
        raw_brix = float(brix_model.predict(sample.values)[0])
        brix = round(max(0.0, min(25.0, raw_brix)), 2)

        if brix >= 18.0:
            recommendation = "READY FOR HARVEST"
            status_code = "READY"
        elif brix >= 16.0:
            recommendation = "NEARLY READY FOR HARVEST"
            status_code = "NEARLY_READY"
        else:
            recommendation = "NOT READY FOR HARVEST"
            status_code = "NOT_READY"
    else:
        brix = 0.0
        recommendation = "NOT SUGARCANE"
        status_code = "NOT_SUGARCANE"

    return {
        "sensor_values": values,
        "is_sugarcane": is_sugarcane,
        "brix": brix,
        "recommendation": recommendation,
        "status_code": status_code
    }


# =============================================================================
#  SERIAL PORT DISCOVERY & HELPER
# =============================================================================
def scan_serial_ports():
    """Scan and categorize all available COM ports on the system."""
    try:
        import serial.tools.list_ports
        ports = list(serial.tools.list_ports.comports())
    except ImportError:
        return []

    port_list = []
    for p in ports:
        desc = (p.description or "").lower()
        hwid = (p.hwid or "").lower()

        # Identify common USB-to-UART bridge chips and dev boards
        is_uart = any(k in desc or k in hwid for k in [
            "cp210", "ch340", "ch910", "ftdi", "usb serial", "usb-serial",
            "esp32", "arduino", "silicon labs", "wch", "prolific", "uart", "cdc"
        ])
        is_bluetooth = "bluetooth" in desc or "bthenum" in hwid

        port_list.append({
            "device": p.device,
            "description": p.description or p.device,
            "hwid": p.hwid or "",
            "is_uart": is_uart,
            "is_bluetooth": is_bluetooth
        })

    return port_list


def pick_target_port(preferred_port, available_ports):
    """Select the best port based on user preference or auto-detection."""
    if not available_ports:
        return None, None

    # 1. Exact user preference (if not "AUTO")
    if preferred_port and preferred_port.upper() != "AUTO":
        for p in available_ports:
            if p["device"].upper() == preferred_port.upper():
                return p["device"], p["description"]
        return None, None

    # 2. Auto-detection: prioritize recognized USB-UART bridges (CP210x, CH340, etc.)
    for p in available_ports:
        if p["is_uart"] and not p["is_bluetooth"]:
            return p["device"], p["description"]

    # 3. Non-bluetooth serial port
    for p in available_ports:
        if not p["is_bluetooth"]:
            return p["device"], p["description"]

    # 4. Fallback to first available port
    return available_ports[0]["device"], available_ports[0]["description"]


# =============================================================================
#  BACKGROUND SERIAL WORKER THREAD
# =============================================================================
def serial_background_worker():
    """Ultra-low latency background worker thread that reads ESP32 serial continuously."""
    global latest_data

    try:
        import serial
    except ImportError:
        with state_lock:
            latest_data["status_message"] = "Error: pyserial library is not installed."
        return

    first_permission_warning = True

    while True:
        reconnect_event.clear()

        with state_lock:
            target_pref = current_serial_config["port"]
            baud = current_serial_config["baud_rate"]
            latest_data["configured_port"] = target_pref
            latest_data["baud_rate"] = baud

        ports = scan_serial_ports()
        target_port, port_desc = pick_target_port(target_pref, ports)

        if not target_port:
            with state_lock:
                latest_data["connected"] = False
                latest_data["active_port"] = None
                latest_data["reading_rate"] = 0.0
                if target_pref != "AUTO":
                    latest_data["status_message"] = f"Port {target_pref} not detected. Connect USB cable or switch to Auto-Detect."
                else:
                    latest_data["status_message"] = "No ESP32 serial device detected. Please connect USB cable."
            time.sleep(1.0)
            continue

        ser = None
        try:
            ser = serial.Serial(target_port, baud, timeout=TIMEOUT)

            # Avoid resetting or holding ESP32 in bootloader mode
            try:
                ser.dtr = False
                ser.rts = False
            except Exception:
                pass

            with state_lock:
                latest_data["connected"] = True
                latest_data["active_port"] = target_port
                latest_data["device_description"] = port_desc
                latest_data["status_message"] = f"Connected to {target_port} ({port_desc}) @ {baud} baud"

            first_permission_warning = True
            print(f"[SERIAL] Successfully opened {target_port} @ {baud} baud (Streaming Active)")

            try:
                ser.reset_input_buffer()
            except Exception:
                pass

            last_reading_time = time.time()

            while not reconnect_event.is_set():
                raw_bytes = ser.readline()
                if not raw_bytes:
                    continue

                try:
                    line = raw_bytes.decode("utf-8", errors="replace").strip()
                except Exception:
                    continue

                if not line:
                    continue

                now = time.time()
                recent_read_timestamps.append(now)

                # Compute instantaneous reading frequency (Hz)
                if len(recent_read_timestamps) >= 2:
                    dt = recent_read_timestamps[-1] - recent_read_timestamps[0]
                    hz = round((len(recent_read_timestamps) - 1) / dt, 1) if dt > 0 else 0.0
                else:
                    hz = 1.0

                timestamp = datetime.datetime.now().strftime("%H:%M:%S")

                # Parse spectral sensor values
                values = parse_sensor_line(line)

                with state_lock:
                    latest_data["last_raw_line"] = line
                    latest_data["total_readings"] += 1
                    latest_data["reading_rate"] = hz

                    log_item = {"time": timestamp, "text": line}
                    latest_data["raw_logs"].insert(0, log_item)
                    latest_data["raw_logs"] = latest_data["raw_logs"][:30]

                    if values is not None:
                        pred = process_prediction(values)
                        latest_data.update(pred)
                        latest_data["last_updated"] = timestamp

                        history_entry = {
                            "time": timestamp,
                            "values": values,
                            "recommendation": pred["recommendation"],
                            "brix": pred["brix"],
                            "status_code": pred["status_code"]
                        }
                        latest_data["history"].insert(0, history_entry)
                        latest_data["history"] = latest_data["history"][:30]

        except serial.SerialException as e:
            err_str = str(e)
            with state_lock:
                latest_data["connected"] = False
                latest_data["active_port"] = None
                latest_data["reading_rate"] = 0.0
                if "PermissionError" in err_str or "Access is denied" in err_str:
                    if first_permission_warning:
                        latest_data["status_message"] = f"Port {target_port} is busy! Please close Arduino IDE Serial Monitor."
                        first_permission_warning = False
                    else:
                        latest_data["status_message"] = f"Waiting for {target_port}... (Close Arduino IDE Serial Monitor)"
                else:
                    latest_data["status_message"] = f"Serial error on {target_port}: {err_str}"
            time.sleep(1.0)
        except Exception as e:
            with state_lock:
                latest_data["connected"] = False
                latest_data["status_message"] = f"Connection error: {e}"
            time.sleep(1.0)
        finally:
            if ser and ser.is_open:
                try:
                    ser.close()
                except Exception:
                    pass


# Start background serial worker thread
worker_thread = threading.Thread(target=serial_background_worker, daemon=True)
worker_thread.start()


# =============================================================================
#  FLASK HTTP ROUTES & API
# =============================================================================
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/live")
def get_live_data():
    with state_lock:
        return jsonify(latest_data)


@app.route("/api/ports")
def get_available_ports():
    """Return all detected serial COM ports on the system."""
    ports = scan_serial_ports()
    with state_lock:
        configured = current_serial_config["port"]
        baud = current_serial_config["baud_rate"]
        active = latest_data.get("active_port")
        connected = latest_data.get("connected")

    return jsonify({
        "ports": ports,
        "configured_port": configured,
        "active_port": active,
        "baud_rate": baud,
        "connected": connected
    })


@app.route("/api/config_serial", methods=["POST"])
def configure_serial():
    """Update target COM port and baud rate, triggering reconnection."""
    data = request.get_json() or {}
    new_port = data.get("port", "AUTO").strip()
    try:
        new_baud = int(data.get("baud_rate", 115200))
    except (ValueError, TypeError):
        new_baud = 115200

    with state_lock:
        current_serial_config["port"] = new_port
        current_serial_config["baud_rate"] = new_baud
        latest_data["configured_port"] = new_port
        latest_data["baud_rate"] = new_baud
        latest_data["status_message"] = f"Switching to {new_port} @ {new_baud} baud..."

    reconnect_event.set()
    return jsonify({
        "success": True,
        "message": f"Configured to {new_port} @ {new_baud} baud.",
        "config": current_serial_config
    })


@app.route("/api/reconnect", methods=["POST"])
def trigger_reconnect():
    """Force an immediate scan and reconnection cycle."""
    with state_lock:
        latest_data["status_message"] = "Reconnecting to serial port..."
    reconnect_event.set()
    return jsonify({"success": True, "message": "Reconnection triggered."})


@app.route("/api/test_sample", methods=["POST"])
def inject_test_sample():
    """Endpoint allowing manual sample injection from the web UI for testing."""
    data = request.get_json() or {}
    sample_values = data.get("values")

    if not sample_values or len(sample_values) != 6:
        return jsonify({"success": False, "error": "Must provide 6 values: [R, S, T, U, V, W]"}), 400

    try:
        values = [float(v) for v in sample_values]
    except ValueError:
        return jsonify({"success": False, "error": "Invalid numbers in sample"}), 400

    pred = process_prediction(values)
    timestamp = datetime.datetime.now().strftime("%H:%M:%S")

    with state_lock:
        latest_data.update(pred)
        latest_data["last_updated"] = timestamp
        latest_data["total_readings"] += 1
        latest_data["history"].insert(0, {
            "time": timestamp,
            "values": values,
            "recommendation": pred["recommendation"],
            "brix": pred["brix"],
            "status_code": pred["status_code"]
        })
        latest_data["history"] = latest_data["history"][:30]

    return jsonify({"success": True, "data": latest_data})


if __name__ == "__main__":
    print("\n=================================================================")
    print("  SUGARCANE AI QUALITY ASSESSMENT SYSTEM - WEB DASHBOARD ONLINE ")
    print("=================================================================")
    print("  Web Dashboard: http://127.0.0.1:5000")
    print("  Serial Mode:   AUTO-DETECT (115200 baud, 50ms Low-Latency)")
    print("=================================================================\n")
    app.run(host="0.0.0.0", port=5000, debug=False)
