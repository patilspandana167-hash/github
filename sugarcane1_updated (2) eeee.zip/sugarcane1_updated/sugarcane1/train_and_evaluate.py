"""
=============================================================================
  AI-based Sugarcane Quality Assessment & Harvest Advisory System
  ---------------------------------------------------------------------------
  train_and_evaluate.py

  Trains robust multi-scale Random Forest models:
    1. Sugarcane_Model.pkl: Object Classifier (Sugarcane vs Non-Sugarcane/Air/Other)
    2. Brix_Model.pkl: Sugar Content Regressor (Brix Index 4.0 - 24.0 °Bx)

  Supports all AS7263 NIR sensor operational modes:
    - Raw integration counts (e.g. 1000 - 5000)
    - Calibrated spectral flux (e.g. 0.5 - 50.0 uW/cm²)
    - Standard spectral reflectance signatures
=============================================================================
"""

import os
import sys
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    mean_absolute_error,
    mean_squared_error,
    r2_score,
)
import joblib
import warnings

warnings.filterwarnings("ignore")

print("=" * 65)
print("  SUGARCANE QUALITY ASSESSMENT - MULTI-SCALE MODEL TRAINING")
print("=" * 65)
print("\n[1/7] Loading primary dataset...")

dataset_file = None
if os.path.exists("Sugarcane_NIR_Brix_Dataset1 - Copy.xlsx"):
    dataset_file = "Sugarcane_NIR_Brix_Dataset1 - Copy.xlsx"
elif os.path.exists("Sugarcane_Data_Template.xlsx"):
    dataset_file = "Sugarcane_Data_Template.xlsx"
else:
    raise FileNotFoundError("Neither dataset file was found.")

data_orig = pd.read_excel(dataset_file, engine="openpyxl")

# Standardize column naming
if "NIR_610nm" in data_orig.columns:
    data_orig = data_orig.rename(columns={
        "NIR_610nm": "R",
        "NIR_680nm": "S",
        "NIR_730nm": "T",
        "NIR_760nm": "U",
        "NIR_810nm": "V",
        "NIR_860nm": "W",
        "Reference_Brix": "Brix"
    })
    data_orig["Object"] = "Sugarcane"

feature_cols = ["R", "S", "T", "U", "V", "W"]

for col in feature_cols:
    data_orig[col] = pd.to_numeric(data_orig[col], errors="coerce")
data_orig["Brix"] = pd.to_numeric(data_orig["Brix"], errors="coerce")
data_orig.dropna(subset=feature_cols, inplace=True)

print(f"       Primary dataset loaded: {len(data_orig)} rows.")

# Load template samples if present for additional variety
if os.path.exists("Sugarcane_Data_Template.xlsx") and dataset_file != "Sugarcane_Data_Template.xlsx":
    try:
        df_tmpl = pd.read_excel("Sugarcane_Data_Template.xlsx", engine="openpyxl")
        for col in feature_cols:
            df_tmpl[col] = pd.to_numeric(df_tmpl[col], errors="coerce")
        df_tmpl["Brix"] = pd.to_numeric(df_tmpl["Brix"], errors="coerce")
        df_tmpl.dropna(subset=feature_cols, inplace=True)
        print(f"       Template dataset loaded: {len(df_tmpl)} rows.")
    except Exception:
        df_tmpl = None
else:
    df_tmpl = None

print("\n[2/7] Generating multi-scale spectral profiles & negative materials...")
np.random.seed(42)

# Multi-scale factors spanning raw counts (16x), calibrated floats (1x), and low-power units (0.1x - 0.01x)
scales = [0.01, 0.05, 0.1, 0.2, 0.5, 0.8, 1.0, 1.5, 2.0, 4.0, 8.0, 12.0, 16.0, 20.0, 25.0]
brix_multipliers = [0.70, 0.85, 1.00, 1.15, 1.30, 1.45, 1.60, 1.80, 2.00, 2.20]

pos_rows = []

# Augment from primary sugarcane dataset
for _, row in data_orig.iterrows():
    base_r, base_s, base_t = row["R"], row["S"], row["T"]
    base_u, base_v, base_w = row["U"], row["V"], row["W"]
    base_brix = row["Brix"] if not np.isnan(row["Brix"]) else 12.0

    for sc in scales:
        for bm in brix_multipliers:
            # Add slight realistic optical noise
            noise = np.random.normal(1.0, 0.025, 6)
            # Physical NIR sucrose absorption response
            sugar_shift = (bm - 1.0) * 0.08
            r_val = max(0.01, base_r * sc * noise[0] * (1.0 + sugar_shift * 0.5))
            s_val = max(0.01, base_s * sc * noise[1] * (1.0 + sugar_shift * 0.4))
            t_val = max(0.01, base_t * sc * noise[2] * (1.0 + sugar_shift * 1.0))
            u_val = max(0.01, base_u * sc * noise[3] * (1.0 + sugar_shift * 0.8))
            v_val = max(0.01, base_v * sc * noise[4] * (1.0 + sugar_shift * 1.2))
            w_val = max(0.01, base_w * sc * noise[5] * (1.0 + sugar_shift * 1.5))

            target_brix = min(24.0, max(4.0, base_brix * bm))

            pos_rows.append({
                "R": r_val, "S": s_val, "T": t_val,
                "U": u_val, "V": v_val, "W": w_val,
                "Object": "Sugarcane",
                "Object_Encoded": 1,
                "Brix": target_brix
            })

# Augment from template if available
if df_tmpl is not None:
    sugarcane_tmpl = df_tmpl[df_tmpl["Object"].astype(str).str.lower() == "sugarcane"]
    for _, row in sugarcane_tmpl.iterrows():
        base_r, base_s, base_t = row["R"], row["S"], row["T"]
        base_u, base_v, base_w = row["U"], row["V"], row["W"]
        base_brix = row["Brix"] if not np.isnan(row["Brix"]) else 16.0
        for sc in [0.5, 1.0, 2.0, 5.0, 10.0]:
            noise = np.random.normal(1.0, 0.02, 6)
            pos_rows.append({
                "R": max(0.01, base_r * sc * noise[0]),
                "S": max(0.01, base_s * sc * noise[1]),
                "T": max(0.01, base_t * sc * noise[2]),
                "U": max(0.01, base_u * sc * noise[3]),
                "V": max(0.01, base_v * sc * noise[4]),
                "W": max(0.01, base_w * sc * noise[5]),
                "Object": "Sugarcane",
                "Object_Encoded": 1,
                "Brix": base_brix
            })

# Comprehensive Negative Samples (Non-sugarcane across all light scales)
neg_rows = []

# 1. Dark / Ambient Air (Near zero)
for _ in range(400):
    val = np.random.uniform(0.0, 0.35, 6)
    neg_rows.append({
        "R": val[0], "S": val[1], "T": val[2],
        "U": val[3], "V": val[4], "W": val[5],
        "Object": "Air", "Object_Encoded": 0, "Brix": np.nan
    })

# 2. Flat / Ambient diffuse light (all channels similar intensity)
for _ in range(800):
    sc = np.random.choice(scales)
    base = np.random.uniform(5.0, 80.0) * sc
    noise = np.random.normal(1.0, 0.06, 6)
    neg_rows.append({
        "R": max(0.01, base * noise[0]),
        "S": max(0.01, base * noise[1]),
        "T": max(0.01, base * noise[2]),
        "U": max(0.01, base * noise[3]),
        "V": max(0.01, base * noise[4]),
        "W": max(0.01, base * noise[5]),
        "Object": "Ambient_Light", "Object_Encoded": 0, "Brix": np.nan
    })

# 3. Non-Sugarcane Objects (Wood, Plastic, Paper, Green Leaves, Skin, Metal)
for _ in range(1200):
    sc = np.random.choice(scales)
    profile = np.random.choice(["green_leaf", "plastic", "paper", "wood", "metal", "skin"])
    if profile == "green_leaf":
        # Green leaves absorb red (R is low, NIR is high)
        r = np.random.uniform(5, 20) * sc
        s = np.random.uniform(10, 30) * sc
        t = np.random.uniform(50, 120) * sc
        u = np.random.uniform(60, 130) * sc
        v = np.random.uniform(60, 140) * sc
        w = np.random.uniform(50, 120) * sc
    elif profile == "plastic":
        # Plastics typically have flat or rising slope in far NIR
        r = np.random.uniform(20, 60) * sc
        s = np.random.uniform(20, 60) * sc
        t = np.random.uniform(20, 60) * sc
        u = np.random.uniform(25, 70) * sc
        v = np.random.uniform(30, 80) * sc
        w = np.random.uniform(35, 90) * sc
    elif profile == "paper":
        # High uniform reflectance across visible and NIR
        base = np.random.uniform(80, 200) * sc
        r = base * np.random.uniform(0.95, 1.05)
        s = base * np.random.uniform(0.95, 1.05)
        t = base * np.random.uniform(0.90, 1.00)
        u = base * np.random.uniform(0.85, 0.95)
        v = base * np.random.uniform(0.85, 0.95)
        w = base * np.random.uniform(0.80, 0.90)
    else:
        # Wood / Skin / Metal (different ratio curves)
        r = np.random.uniform(10, 120) * sc
        s = np.random.uniform(10, 120) * sc
        t = np.random.uniform(10, 120) * sc
        u = np.random.uniform(10, 120) * sc
        v = np.random.uniform(10, 120) * sc
        w = np.random.uniform(10, 120) * sc

    neg_rows.append({
        "R": max(0.01, r), "S": max(0.01, s), "T": max(0.01, t),
        "U": max(0.01, u), "V": max(0.01, v), "W": max(0.01, w),
        "Object": f"NonSugarcane_{profile}", "Object_Encoded": 0, "Brix": np.nan
    })

all_pos_df = pd.DataFrame(pos_rows)
all_neg_df = pd.DataFrame(neg_rows)
dataset = pd.concat([all_pos_df, all_neg_df], ignore_index=True)

print(f"       Total training dataset: {len(dataset)} samples")
print(f"         - Sugarcane samples:     {len(all_pos_df)}")
print(f"         - Non-sugarcane samples: {len(all_neg_df)}")

# =============================================================================
#  3. TRAIN & EVALUATE CLASSIFIER
# =============================================================================
print("\n[3/7] Training Random Forest Classifier (Sugarcane Detection)...")
X_cls = dataset[feature_cols].values
y_cls = dataset["Object_Encoded"].values

X_train_cls, X_test_cls, y_train_cls, y_test_cls = train_test_split(
    X_cls, y_cls, test_size=0.2, random_state=42, stratify=y_cls
)

clf = RandomForestClassifier(n_estimators=120, max_depth=16, random_state=42)
clf.fit(X_train_cls, y_train_cls)

y_pred_cls = clf.predict(X_test_cls)
acc = accuracy_score(y_test_cls, y_pred_cls)
prec = precision_score(y_test_cls, y_pred_cls)
rec = recall_score(y_test_cls, y_pred_cls)
f1 = f1_score(y_test_cls, y_pred_cls)

print("\n[4/7] Classifier Evaluation:")
print(f"   Accuracy  : {acc * 100:.2f}%")
print(f"   Precision : {prec * 100:.2f}%")
print(f"   Recall    : {rec * 100:.2f}%")
print(f"   F1-Score  : {f1 * 100:.2f}%")

# =============================================================================
#  5. TRAIN & EVALUATE BRIX REGRESSOR
# =============================================================================
print("\n[5/7] Training Random Forest Regressor (Brix Index Prediction)...")
sugarcane_only = dataset[dataset["Object_Encoded"] == 1].dropna(subset=["Brix"])

X_reg = sugarcane_only[feature_cols].values
y_reg = sugarcane_only["Brix"].values

X_train_reg, X_test_reg, y_train_reg, y_test_reg = train_test_split(
    X_reg, y_reg, test_size=0.2, random_state=42
)

reg = RandomForestRegressor(n_estimators=120, max_depth=16, random_state=42)
reg.fit(X_train_reg, y_train_reg)

y_pred_reg = reg.predict(X_test_reg)
mae = mean_absolute_error(y_test_reg, y_pred_reg)
rmse = np.sqrt(mean_squared_error(y_test_reg, y_pred_reg))
r2 = r2_score(y_test_reg, y_pred_reg)

print("\n[6/7] Regressor Evaluation:")
print(f"   MAE   : {mae:.3f} °Bx")
print(f"   RMSE  : {rmse:.3f} °Bx")
print(f"   R²    : {r2 * 100:.2f}%")

# =============================================================================
#  7. SAVE PRODUCTION MODELS
# =============================================================================
print("\n[7/7] Retraining on full dataset and saving models...")
final_clf = RandomForestClassifier(n_estimators=120, max_depth=16, random_state=42)
final_clf.fit(X_cls, y_cls)

final_reg = RandomForestRegressor(n_estimators=120, max_depth=16, random_state=42)
final_reg.fit(X_reg, y_reg)

joblib.dump(final_clf, "Sugarcane_Model.pkl")
joblib.dump(final_reg, "Brix_Model.pkl")

print("   [OK] Sugarcane_Model.pkl saved successfully.")
print("   [OK] Brix_Model.pkl saved successfully.")
print("\n=================================================================")
print("  TRAINING COMPLETE! Live models ready for ESP32 real-time stream.")
print("=================================================================\n")
