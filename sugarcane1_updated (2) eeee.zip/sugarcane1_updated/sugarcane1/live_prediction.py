"""
=============================================================================
  AI-based Sugarcane Quality Assessment & Harvest Advisory System
  ---------------------------------------------------------------------------
  live_prediction.py

  Reads live spectral sensor values (R, S, T, U, V, W) from an ESP32
  (AS7263 NIR sensor) via USB serial port in real-time, then:

    1. Detects whether the sample is Sugarcane using Sugarcane_Model.pkl
    2. If sugarcane, predicts Brix value using Brix_Model.pkl
    3. Displays harvest recommendation:
       - Brix >= 18      -> READY FOR HARVEST
       - 16 <= Brix < 18 -> NEARLY READY FOR HARVEST
       - Brix < 16       -> NOT READY FOR HARVEST

  Supports all sensor output formats and scales (raw counts, calibrated floats).
=============================================================================
"""

import sys
import time
import re
import json
import warnings
import pandas as pd
import joblib

warnings.filterwarnings("ignore")

# =============================================================================
#  CONFIGURATION
# =============================================================================
SERIAL_PORT = "AUTO"       # "AUTO" or specific COM port (e.g. "COM5", "COM9")
BAUD_RATE = 115200         # Must match ESP32's Serial.begin() baud rate
TIMEOUT = 0.05             # Serial read timeout in seconds (low-latency)

# =============================================================================
#  LOAD MODELS
# =============================================================================
try:
    classifier = joblib.load("Sugarcane_Model.pkl")
    brix_model = joblib.load("Brix_Model.pkl")
    print("[OK] Sugarcane_Model.pkl and Brix_Model.pkl loaded successfully.")
except Exception as e:
    print(f"[ERROR] Failed to load model files: {e}")
    print("       Ensure both Sugarcane_Model.pkl and Brix_Model.pkl exist in the working directory.")
    sys.exit(1)

# =============================================================================
#  SERIAL PORT SETUP & AUTO-DETECTION
# =============================================================================
try:
    import serial
    import serial.tools.list_ports
except ImportError:
    print("[ERROR] pyserial library is not installed.")
    print("        Install it with: pip install pyserial")
    sys.exit(1)


def get_target_port(preferred):
    """Find available COM port based on preference or intelligent auto-detection."""
    ports = list(serial.tools.list_ports.comports())
    if not ports:
        return None, []

    port_devices = [p.device for p in ports]

    # 1. Exact user preference
    if preferred and preferred.upper() != "AUTO":
        for p in ports:
            if p.device.upper() == preferred.upper():
                return p.device, port_devices

    # 2. Auto-detect recognized USB-to-UART chips (CP210x, CH340, FTDI, etc.)
    for p in ports:
        desc = (p.description or "").lower()
        hwid = (p.hwid or "").lower()
        if any(k in desc or k in hwid for k in ["cp210", "ch340", "ch910", "ftdi", "usb serial", "usb-serial", "esp32", "arduino", "uart"]):
            if "bluetooth" not in desc and "bthenum" not in hwid:
                return p.device, port_devices

    # 3. First non-Bluetooth serial port
    for p in ports:
        desc = (p.description or "").lower()
        hwid = (p.hwid or "").lower()
        if "bluetooth" not in desc and "bthenum" not in hwid:
            return p.device, port_devices

    return ports[0].device, port_devices


# =============================================================================
#  UNIVERSAL SENSOR LINE PARSER
# =============================================================================
def parse_sensor_line(line: str):
    """Parse various line formats into R, S, T, U, V, W float values."""
    if not line:
        return None
    line = line.strip()
    if not line:
        return None

    # JSON format
    if line.startswith("{") and line.endswith("}"):
        try:
            data = json.loads(line)
            keys = ["R", "S", "T", "U", "V", "W"]
            data_upper = {str(k).upper(): v for k, v in data.items()}
            if all(k in data_upper for k in keys):
                return [float(data_upper[k]) for k in keys]
        except Exception:
            pass

    # Labeled pattern with R, S, T, U, V, W
    labeled_match = re.search(
        r"R[^\d\-+.]*[:=\[]?\s*([-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)[^\w]*"
        r"S[^\d\-+.]*[:=\[]?\s*([-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)[^\w]*"
        r"T[^\d\-+.]*[:=\[]?\s*([-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)[^\w]*"
        r"U[^\d\-+.]*[:=\[]?\s*([-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)[^\w]*"
        r"V[^\d\-+.]*[:=\[]?\s*([-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)[^\w]*"
        r"W[^\d\-+.]*[:=\[]?\s*([-+]?\d*\.?\d+(?:[eE][-+]?\d+)?)",
        line,
        re.IGNORECASE
    )
    if labeled_match:
        try:
            return [float(v) for v in labeled_match.groups()]
        except ValueError:
            pass

    # Comma or semicolon delimited
    cleaned = re.sub(r"[;\s|]+", ",", line)
    parts = [p.strip() for p in cleaned.split(",") if p.strip()]
    if len(parts) == 6:
        try:
            return [float(p) for p in parts]
        except ValueError:
            pass

    # Fallback: find all float numbers
    numbers = re.findall(r"[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?", line)
    valid_nums = []
    for n in numbers:
        try:
            valid_nums.append(float(n))
        except ValueError:
            pass

    if len(valid_nums) >= 6:
        return valid_nums[:6]

    return None


MIN_IDLE_SUM_THRESHOLD = 0.5


def run_prediction(values):
    """
    Run optical threshold check, classifier, and Brix regression models.
    Returns: (recommendation, brix, status_code)
    """
    # 1. Dark / Idle sensor check
    total_energy = sum(values)
    if total_energy < MIN_IDLE_SUM_THRESHOLD:
        return "SAMPLE REMOVED - Place Sugarcane on Sensor", 0.0, "NO_SAMPLE"

    # 2. Run AI Classifier (Sugarcane vs Non-Sugarcane)
    sample = pd.DataFrame([values], columns=["R", "S", "T", "U", "V", "W"])
    result = classifier.predict(sample.values)[0]
    brix = 0.0

    if result == 1:
        raw_brix = float(brix_model.predict(sample.values)[0])
        brix = round(max(0.0, min(25.0, raw_brix)), 2)
        if brix >= 18.0:
            recommendation = "READY FOR HARVEST"
            status_code = "READY"
        elif brix >= 16.0:
            recommendation = "NEARLY READY FOR HARVEST"
            status_code = "NEARLY_READY"
        else:
            recommendation = "NOT READY FOR HARVEST"
            status_code = "NOT_READY"
    else:
        recommendation = "NOT SUGARCANE"
        status_code = "NOT_SUGARCANE"

    return recommendation, brix, status_code


def connect_serial_with_retry(preferred_port, baud_rate, timeout):
    """Attempt to connect to ESP32 serial port, retrying automatically."""
    first_attempt = True
    while True:
        port_to_use, available_ports = get_target_port(preferred_port)

        if not port_to_use:
            print("\r[WAITING] No USB serial port detected. Please plug in your ESP32 with a DATA USB cable...", end="", flush=True)
            time.sleep(1.5)
            continue

        try:
            ser = serial.Serial(port_to_use, baud_rate, timeout=timeout)
            try:
                ser.dtr = False
                ser.rts = False
            except Exception:
                pass

            print(f"\n==========================================================")
            print(f"[OK] CONNECTED TO ESP32 ON {port_to_use} @ {baud_rate} BAUD")
            print(f"==========================================================")
            print("[INFO] Receiving live spectral sensor data from ESP32...")
            print("[INFO] Press Ctrl+C to exit.\n")
            return ser
        except serial.SerialException as e:
            err_str = str(e)
            if "PermissionError" in err_str or "Access is denied" in err_str:
                if first_attempt:
                    print("\n==========================================================")
                    print(f"[ACTION REQUIRED] Port {port_to_use} is busy (e.g., opened in Arduino IDE).")
                    print("--> Please CLOSE the Serial Monitor in Arduino IDE.")
                    print("--> Connection will automatically succeed once closed!")
                    print("==========================================================")
                    first_attempt = False
                else:
                    print("\r[WAITING] Retrying connection... (Close Serial Monitor in Arduino IDE)", end="", flush=True)
            else:
                print(f"\n[ERROR] Could not open {port_to_use}: {e}")
                if available_ports:
                    print(f"        Available COM ports: {', '.join(available_ports)}")
            time.sleep(1.5)


def main():
    ser = connect_serial_with_retry(SERIAL_PORT, BAUD_RATE, TIMEOUT)

    try:
        while True:
            raw_bytes = ser.readline()
            if not raw_bytes:
                continue

            try:
                line = raw_bytes.decode("utf-8", errors="replace").strip()
            except Exception:
                continue

            if not line:
                continue

            values = parse_sensor_line(line)
            if values is None:
                continue

            # Run AI model on received ESP32 readings
            rec, brix, status_code = run_prediction(values)
            ch_str = f"R={values[0]:.2f}, S={values[1]:.2f}, T={values[2]:.2f}, U={values[3]:.2f}, V={values[4]:.2f}, W={values[5]:.2f}"

            if status_code == "NO_SAMPLE":
                print(f"[LIVE READING] [{ch_str}] --> ⚠️  {rec}")
            elif status_code == "NOT_SUGARCANE":
                print(f"[LIVE READING] [{ch_str}] --> ❌ NOT SUGARCANE (Non-Sugarcane Material)")
            else:
                print(f"[LIVE READING] [{ch_str}] | Brix: {brix:.2f} °Bx --> {rec}")

    except KeyboardInterrupt:
        print("\n[INFO] Exiting live prediction.")
    except serial.SerialException as e:
        print(f"\n[ERROR] Serial connection lost: {e}")
    except Exception as e:
        print(f"\n[ERROR] Unexpected error: {e}")
    finally:
        if ser and ser.is_open:
            ser.close()


if __name__ == "__main__":
    main()
